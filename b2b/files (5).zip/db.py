"""
Sentinel Radar — Data Store
==============================
SQLite instead of Postgres/Timescale — this is the right call for a single
operator running one process on one machine. It's a single file, needs zero
setup, and still gives us real historical time-series to compute trends
against. If this ever needs to serve multiple concurrent writers or scale
past one box, that's the trigger to migrate to Postgres — not before.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Iterator, Optional

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS companies (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL,
    domain          TEXT NOT NULL UNIQUE,
    sector          TEXT NOT NULL,
    country         TEXT NOT NULL,
    discovery_source TEXT NOT NULL,        -- which search query found it
    status          TEXT NOT NULL DEFAULT 'active', -- active | dead | unreachable
    first_discovered_at TEXT NOT NULL,
    last_crawled_at TEXT
);

CREATE TABLE IF NOT EXISTS tracked_pages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    url             TEXT NOT NULL,
    page_type       TEXT NOT NULL DEFAULT 'pricing', -- pricing | homepage
    UNIQUE(company_id, url)
);

CREATE TABLE IF NOT EXISTS snapshots (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tracked_page_id INTEGER NOT NULL REFERENCES tracked_pages(id) ON DELETE CASCADE,
    content_hash    TEXT NOT NULL,
    raw_text        TEXT NOT NULL,
    captured_at     TEXT NOT NULL,
    is_duplicate    INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_snapshots_page_time ON snapshots(tracked_page_id, captured_at DESC);

CREATE TABLE IF NOT EXISTS price_signals (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    snapshot_id     INTEGER NOT NULL REFERENCES snapshots(id) ON DELETE CASCADE,
    raw_text_span   TEXT NOT NULL,
    amount          REAL NOT NULL,
    currency        TEXT NOT NULL,
    captured_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_price_signals_company_time ON price_signals(company_id, captured_at DESC);

CREATE TABLE IF NOT EXISTS events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type      TEXT NOT NULL,   -- new_entrant | price_change | discovery_run | scrape_run | error
    company_id      INTEGER REFERENCES companies(id) ON DELETE SET NULL,
    severity        TEXT NOT NULL DEFAULT 'info', -- info | notable | critical
    message         TEXT NOT NULL,
    magnitude       REAL,             -- e.g. % price change, used to size the timeline tick
    occurred_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_time ON events(occurred_at DESC);

CREATE TABLE IF NOT EXISTS trend_reports (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    sector          TEXT NOT NULL,
    country         TEXT NOT NULL,
    generated_at    TEXT NOT NULL,
    summary_json    TEXT NOT NULL
);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def get_conn() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with get_conn() as conn:
        conn.executescript(SCHEMA)


# ── Companies ────────────────────────────────────────────────────────────

def upsert_company(name: str, domain: str, sector: str, country: str, source: str) -> tuple[int, bool]:
    """Returns (company_id, was_newly_created)."""
    with get_conn() as conn:
        existing = conn.execute("SELECT id FROM companies WHERE domain = ?", (domain,)).fetchone()
        if existing:
            return existing["id"], False
        cur = conn.execute(
            "INSERT INTO companies (name, domain, sector, country, discovery_source, first_discovered_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (name, domain, sector, country, source, now_iso()),
        )
        return cur.lastrowid, True


def list_companies(sector: Optional[str] = None) -> list[sqlite3.Row]:
    with get_conn() as conn:
        if sector:
            return conn.execute(
                "SELECT * FROM companies WHERE sector = ? ORDER BY first_discovered_at DESC", (sector,)
            ).fetchall()
        return conn.execute("SELECT * FROM companies ORDER BY first_discovered_at DESC").fetchall()


def mark_crawled(company_id: int) -> None:
    with get_conn() as conn:
        conn.execute("UPDATE companies SET last_crawled_at = ? WHERE id = ?", (now_iso(), company_id))


# ── Tracked pages ────────────────────────────────────────────────────────

def upsert_tracked_page(company_id: int, url: str, page_type: str = "pricing") -> int:
    with get_conn() as conn:
        existing = conn.execute(
            "SELECT id FROM tracked_pages WHERE company_id = ? AND url = ?", (company_id, url)
        ).fetchone()
        if existing:
            return existing["id"]
        cur = conn.execute(
            "INSERT INTO tracked_pages (company_id, url, page_type) VALUES (?, ?, ?)",
            (company_id, url, page_type),
        )
        return cur.lastrowid


def list_tracked_pages(company_id: int) -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute("SELECT * FROM tracked_pages WHERE company_id = ?", (company_id,)).fetchall()


# ── Snapshots ────────────────────────────────────────────────────────────

def latest_snapshot(tracked_page_id: int) -> Optional[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM snapshots WHERE tracked_page_id = ? ORDER BY captured_at DESC LIMIT 1",
            (tracked_page_id,),
        ).fetchone()


def insert_snapshot(tracked_page_id: int, content_hash: str, raw_text: str, is_duplicate: bool) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO snapshots (tracked_page_id, content_hash, raw_text, captured_at, is_duplicate) "
            "VALUES (?, ?, ?, ?, ?)",
            (tracked_page_id, content_hash, raw_text, now_iso(), int(is_duplicate)),
        )
        return cur.lastrowid


# ── Price signals ────────────────────────────────────────────────────────

def insert_price_signal(company_id: int, snapshot_id: int, raw_text_span: str,
                         amount: float, currency: str) -> None:
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO price_signals (company_id, snapshot_id, raw_text_span, amount, currency, captured_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (company_id, snapshot_id, raw_text_span, amount, currency, now_iso()),
        )


def price_history(company_id: int, limit: int = 200) -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM price_signals WHERE company_id = ? ORDER BY captured_at ASC LIMIT ?",
            (company_id, limit),
        ).fetchall()


def sector_price_series(sector: str) -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            """
            SELECT ps.captured_at, ps.amount, ps.currency, c.name as company_name
            FROM price_signals ps
            JOIN companies c ON c.id = ps.company_id
            WHERE c.sector = ?
            ORDER BY ps.captured_at ASC
            """,
            (sector,),
        ).fetchall()


# ── Events (feeds the "signal timeline" UI element) ─────────────────────

def log_event(event_type: str, message: str, severity: str = "info",
               company_id: Optional[int] = None, magnitude: Optional[float] = None) -> None:
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO events (event_type, company_id, severity, message, magnitude, occurred_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (event_type, company_id, severity, message, magnitude, now_iso()),
        )


def recent_events(limit: int = 100) -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT e.*, c.name as company_name FROM events e "
            "LEFT JOIN companies c ON c.id = e.company_id "
            "ORDER BY e.occurred_at DESC LIMIT ?",
            (limit,),
        ).fetchall()


# ── Trend reports ────────────────────────────────────────────────────────

def insert_trend_report(sector: str, country: str, summary_json: str) -> None:
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO trend_reports (sector, country, generated_at, summary_json) VALUES (?, ?, ?, ?)",
            (sector, country, now_iso(), summary_json),
        )


def latest_trend_report(sector: str) -> Optional[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM trend_reports WHERE sector = ? ORDER BY generated_at DESC LIMIT 1",
            (sector,),
        ).fetchone()
