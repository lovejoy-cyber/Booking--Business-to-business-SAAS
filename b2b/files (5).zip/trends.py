"""
Sentinel Radar — Trend Aggregation
=====================================
This is the piece that actually answers "what's happening in this sector",
not "what changed on one company's page". It rolls up everything discovered
and scraped so far into sector-wide numbers, then (optionally) asks Claude
to narrate those numbers in plain English — never to compute them.

Same anti-hallucination discipline as the enterprise design: every number in
the narrative is handed to the model pre-computed; the model's only job is
phrasing, and it's explicitly told not to introduce any figure that wasn't
given to it.
"""

from __future__ import annotations

import json
import os
import statistics
from collections import defaultdict
from datetime import datetime, timedelta, timezone

import config
import db

log_prefix = "[trends]"


def _parse_iso(ts: str) -> datetime:
    return datetime.fromisoformat(ts)


def compute_sector_snapshot(sector: str, lookback_days: int = 30) -> dict:
    """Pure arithmetic over what's in SQLite — no model involved. This is the
    trustworthy core; the narrative step below is just a plain-English
    restatement of exactly these numbers.
    """
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(days=lookback_days)

    companies = db.list_companies(sector=sector)
    active_companies = [c for c in companies if c["status"] == "active"]

    events = [e for e in db.recent_events(limit=2000) if _parse_iso(e["occurred_at"]) >= cutoff]
    new_entrant_events = [e for e in events if e["event_type"] == "new_entrant"]
    price_change_events = [e for e in events if e["event_type"] == "price_change"]

    series = db.sector_price_series(sector)
    series = [row for row in series if _parse_iso(row["captured_at"]) >= cutoff]

    daily_avgs: dict[str, list[float]] = defaultdict(list)
    for row in series:
        day = row["captured_at"][:10]
        daily_avgs[day].append(row["amount"])

    sorted_days = sorted(daily_avgs.keys())
    daily_series = [
        {"date": day, "avg_price": round(statistics.mean(daily_avgs[day]), 2)}
        for day in sorted_days
    ]

    sector_pct_change = None
    if len(daily_series) >= 2:
        first, last = daily_series[0]["avg_price"], daily_series[-1]["avg_price"]
        if first:
            sector_pct_change = round((last - first) / first * 100, 1)

    top_movers = sorted(
        price_change_events, key=lambda e: abs(e["magnitude"] or 0), reverse=True
    )[:5]

    return {
        "sector": sector,
        "country": config.COUNTRY,
        "generated_at": now.isoformat(),
        "lookback_days": lookback_days,
        "active_company_count": len(active_companies),
        "new_entrants_in_window": len(new_entrant_events),
        "price_changes_in_window": len(price_change_events),
        "sector_avg_price_pct_change": sector_pct_change,
        "daily_avg_price_series": daily_series,
        "top_movers": [
            {
                "company_name": e["company_name"],
                "message": e["message"],
                "magnitude_pct": round((e["magnitude"] or 0) * 100, 1),
                "severity": e["severity"],
            }
            for e in top_movers
        ],
    }


NARRATIVE_SYSTEM_PROMPT = (
    "You write a two-to-three sentence executive summary of a sector trend "
    "report for a market-intelligence dashboard. You are given a JSON object "
    "of PRE-COMPUTED statistics — every number in your summary MUST come "
    "directly from this JSON. Never introduce a number, percentage, or company "
    "name that is not present in the input. If the data is too sparse to say "
    "anything meaningful (e.g. very few companies or events tracked so far), "
    "say exactly that plainly rather than inventing a trend."
)


def generate_narrative(snapshot: dict) -> str:
    """Optional — only runs if ANTHROPIC_API_KEY is set and reachable. The
    dashboard works fine without this; it just shows the raw numbers instead
    of a written summary. Keeping this optional matters given credit/billing
    constraints — the core autonomous system never depends on an LLM call
    succeeding.
    """
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return ""

    try:
        from anthropic import Anthropic
        client = Anthropic()
        response = client.messages.create(
            model=config.ANTHROPIC_MODEL,
            max_tokens=300,
            system=NARRATIVE_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": json.dumps(snapshot)}],
        )
        return "".join(block.text for block in response.content if block.type == "text").strip()
    except Exception as exc:
        print(f"{log_prefix} narrative generation skipped (non-fatal): {exc}")
        return ""


def run_trend_report() -> dict:
    db.init_db()
    snapshot = compute_sector_snapshot(config.SECTOR)
    snapshot["narrative"] = generate_narrative(snapshot)
    db.insert_trend_report(config.SECTOR, config.COUNTRY, json.dumps(snapshot))
    print(f"{log_prefix} report generated: {snapshot['active_company_count']} companies, "
          f"{snapshot['price_changes_in_window']} price changes in window")
    return snapshot


if __name__ == "__main__":
    result = run_trend_report()
    print(json.dumps(result, indent=2))
