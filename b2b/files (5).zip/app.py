"""
Sentinel Radar — Dashboard Backend
=====================================
Small Flask API serving the frontend. Reads only — it never triggers a
scrape or discovery run itself; that's entirely scheduler.py's job, running
as a separate autonomous process. This separation matters: the dashboard
can be closed, refreshed, or crash without affecting the underlying
surveillance loop at all.

Run with:
    python dashboard/app.py
Then open http://localhost:5000
"""

from __future__ import annotations

import json
import os
import sys

from flask import Flask, jsonify, render_template

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
import db

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html", sector=config.SECTOR, country=config.COUNTRY)


@app.route("/api/overview")
def api_overview():
    companies = db.list_companies(sector=config.SECTOR)
    report_row = db.latest_trend_report(config.SECTOR)
    report = json.loads(report_row["summary_json"]) if report_row else None

    return jsonify({
        "sector": config.SECTOR,
        "country": config.COUNTRY,
        "company_count": len(companies),
        "active_count": len([c for c in companies if c["status"] == "active"]),
        "trend_report": report,
    })


@app.route("/api/companies")
def api_companies():
    companies = db.list_companies(sector=config.SECTOR)
    return jsonify([{
        "id": c["id"],
        "name": c["name"],
        "domain": c["domain"],
        "status": c["status"],
        "first_discovered_at": c["first_discovered_at"],
        "last_crawled_at": c["last_crawled_at"],
    } for c in companies])


@app.route("/api/events")
def api_events():
    events = db.recent_events(limit=150)
    return jsonify([{
        "id": e["id"],
        "event_type": e["event_type"],
        "severity": e["severity"],
        "message": e["message"],
        "magnitude": e["magnitude"],
        "company_name": e["company_name"],
        "occurred_at": e["occurred_at"],
    } for e in events])


@app.route("/api/company/<int:company_id>/history")
def api_company_history(company_id: int):
    history = db.price_history(company_id, limit=500)
    return jsonify([{
        "amount": row["amount"],
        "currency": row["currency"],
        "captured_at": row["captured_at"],
        "raw_text_span": row["raw_text_span"],
    } for row in history])


if __name__ == "__main__":
    db.init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
