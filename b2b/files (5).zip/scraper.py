"""
Sentinel Radar — Autonomous Scraper
======================================
Crawls every company discovery.py has found — no manual URL entry anywhere
in this file. For a brand-new company it first finds a likely pricing page
on its own (tries common paths, then falls back to following in-page links
that look pricing-related); for a known company it re-checks the page it
already found.

Heuristic, not schema-based, extraction: unlike the enterprise design (which
assumes a hand-maintained CSS/XPath schema per target), this system has to
handle arbitrary, never-seen-before sites autonomously. So price extraction
here is a regex sweep for currency-tagged numbers near pricing keywords, with
a confidence signal (how close the number sits to a pricing keyword) rather
than a guaranteed-correct field extraction. That's an honest trade-off for
autonomy — flagged clearly in the trend report, never silently presented as
precise as a per-target schema would be.
"""

from __future__ import annotations

import asyncio
import hashlib
import re
import statistics
from typing import Optional
from urllib.parse import urljoin

from bs4 import BeautifulSoup, Comment
from playwright.async_api import async_playwright

import config
import db

log_prefix = "[scraper]"

PRICE_REGEX = re.compile(
    r"(US\$|Z\$|ZWG|ZWL|\$)\s?(\d{1,3}(?:[,.]\d{3})*(?:\.\d{1,2})?)",
    re.IGNORECASE,
)

PRICE_CHANGE_NOTABLE_PCT = 0.05
PRICE_CHANGE_CRITICAL_PCT = 0.15


# ── Text normalization + hashing (same principle as the enterprise worker.py:
#    strip volatile noise before hashing so re-renders don't look like changes) ──

def normalize_text(raw_html: str) -> str:
    soup = BeautifulSoup(raw_html, "lxml")
    for tag in soup(["script", "style", "noscript", "svg", "img"]):
        tag.decompose()
    for comment in soup.find_all(string=lambda s: isinstance(s, Comment)):
        comment.extract()
    text = soup.get_text(separator=" | ")
    return re.sub(r"\s+", " ", text).strip()


def content_hash(normalized_text: str) -> str:
    return hashlib.sha256(normalized_text.encode("utf-8")).hexdigest()


# ── Heuristic price extraction ───────────────────────────────────────────

def extract_price_signals(normalized_text: str) -> list[dict]:
    """Finds currency-tagged numbers and scores each by proximity to a
    pricing keyword. Returns list of {raw_text_span, amount, currency, confidence}.
    """
    signals = []
    lowered = normalized_text.lower()

    for match in PRICE_REGEX.finditer(normalized_text):
        symbol, amount_str = match.group(1), match.group(2)
        try:
            amount = float(amount_str.replace(",", ""))
        except ValueError:
            continue

        start, end = max(0, match.start() - 60), min(len(normalized_text), match.end() + 60)
        context = normalized_text[start:end].strip()

        window_lower = lowered[start:end]
        keyword_hit = any(kw in window_lower for kw in config.PRICING_KEYWORDS)
        confidence = 0.9 if keyword_hit else 0.55

        currency = "USD" if symbol.upper() in ("US$", "$") else symbol.upper()

        signals.append({
            "raw_text_span": context,
            "amount": amount,
            "currency": currency,
            "confidence": confidence,
        })

    return signals


# ── Finding a pricing page on a brand-new, never-seen domain ─────────────

async def _fetch(page, url: str) -> Optional[str]:
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=20_000)
        try:
            await page.wait_for_load_state("networkidle", timeout=8_000)
        except Exception:
            pass
        return await page.content()
    except Exception as exc:
        print(f"{log_prefix} fetch failed for {url}: {exc}")
        return None


async def discover_pricing_page(page, domain: str) -> Optional[str]:
    base = f"https://{domain}"

    for path in config.PRICING_PATH_CANDIDATES:
        candidate_url = urljoin(base, path)
        html = await _fetch(page, candidate_url)
        if not html:
            continue

        text_lower = normalize_text(html).lower()
        keyword_hits = sum(1 for kw in config.PRICING_KEYWORDS if kw in text_lower)
        has_price_number = bool(PRICE_REGEX.search(html))

        if keyword_hits >= 2 and has_price_number:
            print(f"{log_prefix} likely pricing page for {domain}: {candidate_url}")
            return candidate_url

        # Homepage fallback: look for an in-page link whose text/href looks pricing-related
        if path == "/":
            soup = BeautifulSoup(html, "lxml")
            for a in soup.find_all("a", href=True):
                link_text = (a.get_text() or "").lower()
                href = a["href"].lower()
                if any(kw in link_text or kw in href for kw in ["price", "plan", "package", "tariff", "bundle"]):
                    full_url = urljoin(base, a["href"])
                    linked_html = await _fetch(page, full_url)
                    if linked_html and PRICE_REGEX.search(linked_html):
                        print(f"{log_prefix} pricing page via link for {domain}: {full_url}")
                        return full_url

    print(f"{log_prefix} no clear pricing page found for {domain}, defaulting to homepage")
    return base


# ── Per-company crawl ─────────────────────────────────────────────────────

async def crawl_company(browser, company_row) -> None:
    company_id, domain, name = company_row["id"], company_row["domain"], company_row["name"]
    context = await browser.new_context(
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        viewport={"width": 1440, "height": 900},
    )
    page = await context.new_page()

    tracked = db.list_tracked_pages(company_id)
    if not tracked:
        url = await discover_pricing_page(page, domain)
        if not url:
            await context.close()
            return
        tracked_page_id = db.upsert_tracked_page(company_id, url, page_type="pricing")
    else:
        tracked_page_id = tracked[0]["id"]
        url = tracked[0]["url"]

    html = await _fetch(page, url)
    await context.close()

    if not html:
        db.log_event("error", f"Failed to fetch {url}", severity="info", company_id=company_id)
        return

    normalized = normalize_text(html)
    new_hash = content_hash(normalized)
    previous = db.latest_snapshot(tracked_page_id)
    is_duplicate = previous is not None and previous["content_hash"] == new_hash

    snapshot_id = db.insert_snapshot(tracked_page_id, new_hash, normalized, is_duplicate)
    db.mark_crawled(company_id)

    if is_duplicate:
        print(f"{log_prefix} {name}: no change")
        return

    signals = extract_price_signals(normalized)
    for sig in signals:
        db.insert_price_signal(company_id, snapshot_id, sig["raw_text_span"], sig["amount"], sig["currency"])

    _check_for_price_change(company_id, name, signals)
    print(f"{log_prefix} {name}: page changed, {len(signals)} price signals extracted")


def _check_for_price_change(company_id: int, name: str, new_signals: list[dict]) -> None:
    """Compares the average of newly-extracted amounts against the company's
    prior average, on this same page, and logs an event sized by magnitude.
    This is intentionally simple (average-vs-average, not exact plan-to-plan
    matching) — matching arbitrary sites' unlabeled prices exactly is a much
    harder problem than this MVP scope allows; the honest output here is
    "pricing on this page moved by roughly X%", not a guaranteed per-tier diff.
    """
    if not new_signals:
        return

    history = db.price_history(company_id, limit=500)
    if len(history) < len(new_signals) + 1:
        return  # not enough prior history to compare against yet

    prior_amounts = [row["amount"] for row in history[:-len(new_signals)]]
    if not prior_amounts:
        return

    prior_avg = statistics.mean(prior_amounts[-10:])  # trailing window, not full history
    new_avg = statistics.mean(s["amount"] for s in new_signals)

    if prior_avg == 0:
        return

    pct_change = (new_avg - prior_avg) / prior_avg

    if abs(pct_change) >= PRICE_CHANGE_CRITICAL_PCT:
        severity = "critical"
    elif abs(pct_change) >= PRICE_CHANGE_NOTABLE_PCT:
        severity = "notable"
    else:
        return  # within normal noise band, not worth an event

    direction = "up" if pct_change > 0 else "down"
    db.log_event(
        event_type="price_change",
        company_id=company_id,
        severity=severity,
        message=f"{name}: average detected price moved {direction} {abs(pct_change) * 100:.1f}%",
        magnitude=pct_change,
    )


# ── Entry point ───────────────────────────────────────────────────────────

async def run_scrape_cycle() -> dict:
    db.init_db()
    companies = [c for c in db.list_companies(sector=config.SECTOR) if c["status"] == "active"]
    print(f"{log_prefix} scraping {len(companies)} companies")

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        for company in companies:
            try:
                await crawl_company(browser, company)
            except Exception as exc:
                print(f"{log_prefix} error crawling {company['name']}: {exc}")
                db.log_event("error", f"Crawl error: {exc}", severity="info", company_id=company["id"])
        await browser.close()

    db.log_event("scrape_run", f"Scrape cycle complete: {len(companies)} companies checked")
    return {"companies_checked": len(companies)}


if __name__ == "__main__":
    summary = asyncio.run(run_scrape_cycle())
    print(f"{log_prefix} done: {summary}")
