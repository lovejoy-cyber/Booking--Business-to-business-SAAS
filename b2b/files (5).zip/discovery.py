"""
Sentinel Radar — Discovery Engine
====================================
This is the module that makes the system autonomous: it takes only a
SECTOR + COUNTRY (set in config.py) and finds real company websites on its
own, via search — no one ever types in a competitor's URL.

Uses DuckDuckGo search (via the `ddgs` package) because it needs no API key
and no billing account, which matters for a system meant to run unattended.
If you later want higher-quality/higher-volume discovery, this is the one
function (`run_discovery`) to swap for a paid search API (Google Custom
Search, Bing Search API, SerpAPI) without touching anything downstream.
"""

from __future__ import annotations

import re
import time
from urllib.parse import urlparse

from ddgs import DDGS

import config
import db

log_prefix = "[discovery]"


def _extract_domain(url: str) -> str | None:
    try:
        parsed = urlparse(url)
        domain = parsed.netloc.lower().replace("www.", "")
        return domain or None
    except Exception:
        return None


def _is_blocked_domain(domain: str) -> bool:
    return any(blocked in domain for blocked in config.DOMAIN_BLOCKLIST_SUBSTRINGS)


def _guess_company_name(domain: str) -> str:
    """Best-effort human-readable name from a domain until the scraper reads
    the real <title> from the homepage and we can improve it later."""
    core = domain.split(".")[0]
    return core.replace("-", " ").title()


def discover_candidates(sector: str, country: str) -> list[dict]:
    """Runs every query template in config, collects unique candidate domains.
    Returns a list of {name, domain, source} dicts — NOT yet written to the DB;
    that happens in run_discovery so this function stays easily testable.
    """
    seen_domains: set[str] = set()
    candidates: list[dict] = []

    with DDGS() as ddgs:
        for template in config.DISCOVERY_QUERY_TEMPLATES:
            query = template.format(sector=sector, country=country)
            print(f"{log_prefix} searching: {query!r}")

            try:
                results = list(ddgs.text(query, max_results=15))
            except Exception as exc:
                print(f"{log_prefix} search failed for {query!r}: {exc}")
                continue

            for result in results:
                url = result.get("href") or result.get("url") or ""
                domain = _extract_domain(url)
                if not domain or domain in seen_domains or _is_blocked_domain(domain):
                    continue
                seen_domains.add(domain)
                candidates.append({
                    "name": _guess_company_name(domain),
                    "domain": domain,
                    "source": query,
                })

            time.sleep(1.5)  # be a polite, low-volume caller of a free search service

    print(f"{log_prefix} found {len(candidates)} unique candidate domains")
    return candidates


def run_discovery() -> dict:
    """Entry point called by the scheduler. Finds candidates, writes new ones
    to the DB, logs a `new_entrant` event for each genuinely new company, and
    returns a small summary dict for logging.
    """
    db.init_db()
    candidates = discover_candidates(config.SECTOR, config.COUNTRY)

    new_count = 0
    for candidate in candidates:
        company_id, was_new = db.upsert_company(
            name=candidate["name"],
            domain=candidate["domain"],
            sector=config.SECTOR,
            country=config.COUNTRY,
            source=candidate["source"],
        )
        if was_new:
            new_count += 1
            db.log_event(
                event_type="new_entrant",
                company_id=company_id,
                severity="notable",
                message=f"Discovered new company: {candidate['name']} ({candidate['domain']})",
            )
            print(f"{log_prefix} NEW: {candidate['name']} — {candidate['domain']}")

    db.log_event(
        event_type="discovery_run",
        severity="info",
        message=f"Discovery run complete: {len(candidates)} candidates seen, {new_count} new",
    )

    return {"candidates_seen": len(candidates), "new_companies": new_count}


if __name__ == "__main__":
    summary = run_discovery()
    print(f"{log_prefix} done: {summary}")
