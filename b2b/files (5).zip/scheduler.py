"""
Sentinel Radar — Autonomous Scheduler
========================================
This is the process that makes the whole thing "autonomous" in the sense you
asked for: start it once, leave it running, and it discovers companies,
scrapes them, and rolls up trends entirely on its own cadence. No one ever
triggers a run by hand or pastes in a URL.

Run it with:
    python scheduler.py

Leave this running in a terminal (or as a background service — see README
for the Windows Task Scheduler / `pythonw` notes) while the dashboard
(dashboard/app.py) reads from the same SQLite file to display results.

A lightweight time-check loop is used deliberately instead of APScheduler/
Celery/Temporal — for one process on one machine, that's the honest match
to the actual scale of this system, not the enterprise version.
"""

from __future__ import annotations

import time
import traceback
from datetime import datetime, timezone

import config
import db
import discovery
import scraper
import trends

CHECK_INTERVAL_SECONDS = 5 * 60  # wake up and check "is anything due" every 5 minutes


class JobClock:
    """Tracks when each job last ran so the loop knows what's due, without
    needing a separate scheduling library."""

    def __init__(self) -> None:
        self.last_run: dict[str, float] = {}

    def is_due(self, job_name: str, interval_hours: float) -> bool:
        last = self.last_run.get(job_name)
        if last is None:
            return True
        return (time.time() - last) >= interval_hours * 3600

    def mark_ran(self, job_name: str) -> None:
        self.last_run[job_name] = time.time()


def _safe_run(job_name: str, fn) -> None:
    print(f"\n=== [{datetime.now(timezone.utc).isoformat()}] running {job_name} ===")
    try:
        fn()
    except Exception:
        print(f"[scheduler] {job_name} crashed — logging and continuing, not stopping the loop:")
        traceback.print_exc()
        db.log_event("error", f"{job_name} crashed: see logs", severity="notable")


def main() -> None:
    db.init_db()
    print(f"Sentinel Radar starting — tracking '{config.SECTOR}' in {config.COUNTRY}")
    print(f"Discovery every {config.DISCOVERY_INTERVAL_HOURS}h, "
          f"scraping every {config.SCRAPE_INTERVAL_HOURS}h, "
          f"trend reports every {config.TREND_REPORT_INTERVAL_HOURS}h")
    print("Leave this running. Ctrl+C to stop.\n")

    clock = JobClock()

    # Run everything once immediately on startup so there's data to look at
    # right away, rather than waiting for the first interval to elapse.
    _safe_run("discovery", discovery.run_discovery)
    clock.mark_ran("discovery")

    _safe_run("scrape", lambda: __import__("asyncio").run(scraper.run_scrape_cycle()))
    clock.mark_ran("scrape")

    _safe_run("trends", trends.run_trend_report)
    clock.mark_ran("trends")

    while True:
        time.sleep(CHECK_INTERVAL_SECONDS)

        if clock.is_due("discovery", config.DISCOVERY_INTERVAL_HOURS):
            _safe_run("discovery", discovery.run_discovery)
            clock.mark_ran("discovery")

        if clock.is_due("scrape", config.SCRAPE_INTERVAL_HOURS):
            _safe_run("scrape", lambda: __import__("asyncio").run(scraper.run_scrape_cycle()))
            clock.mark_ran("scrape")

        if clock.is_due("trends", config.TREND_REPORT_INTERVAL_HOURS):
            _safe_run("trends", trends.run_trend_report)
            clock.mark_ran("trends")


if __name__ == "__main__":
    main()
