# Sentinel Radar — Autonomous Market Surveillance

Fully autonomous, no-URL-input market intelligence for a sector + country of
your choosing. Set it once in `config.py` (default: telecom & mobile money,
Zimbabwe), start `scheduler.py`, and it discovers companies, tracks their
pricing, and rolls up sector-wide trends entirely on its own — you never
paste in a competitor URL.

## What each file does

| File | Role |
|---|---|
| `config.py` | **Edit this to change what's tracked** — sector, country, search templates, cadence |
| `db.py` | SQLite storage — companies, snapshots, price signals, events, trend reports |
| `discovery.py` | Finds companies automatically via search (no API key needed) |
| `scraper.py` | Crawls discovered companies, finds their pricing pages on its own, extracts prices heuristically |
| `trends.py` | Rolls discovered data up into sector-wide trend numbers + optional AI narrative |
| `scheduler.py` | **The always-on process** — runs discovery/scrape/trend jobs on their own cadence, forever |
| `dashboard/app.py` + `dashboard/templates/index.html` | The live dashboard UI |

## Setup (one time)

```powershell
cd "path\to\this\folder"
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
playwright install chromium
```

Optional — only needed if you want the AI-written executive summary on the
dashboard (everything else works without it):
```powershell
[System.Environment]::SetEnvironmentVariable("ANTHROPIC_API_KEY", "your-key", "User")
```
Close and reopen the terminal after setting this for it to take effect.

## Running it (two processes, both need to stay open)

**Terminal 1 — the autonomous engine** (leave this running, this is the actual system):
```powershell
.\venv\Scripts\Activate.ps1
python scheduler.py
```
On first launch it immediately runs one discovery cycle, one scrape cycle,
and one trend report, then goes quiet and wakes up on its own cadence after
that (defaults: discovery daily, scraping every 6 hours, trend report
daily — all adjustable in `config.py`). Leave the window open; closing it
stops the surveillance loop.

**Terminal 2 — the dashboard** (open a second terminal, don't close the first):
```powershell
.\venv\Scripts\Activate.ps1
python dashboard\app.py
```
Then open **http://localhost:5000** in your browser. It auto-refreshes
every 30 seconds and reads from the same database `scheduler.py` is writing
to — you'll watch it fill in live as cycles complete.

## Keeping it running unattended (beyond a single sitting)

For it to genuinely run "on its own" past the time you have the laptop
open, `scheduler.py` needs to keep running when you're not watching it.
Two realistic options on Windows:

1. **Simplest**: minimize the terminal window instead of closing it, and let
   the laptop stay on / not sleep. Fine for a few days of testing.
2. **More durable**: use Windows Task Scheduler to launch
   `venv\Scripts\pythonw.exe scheduler.py` at logon, which runs it in the
   background with no visible window. Ask me for the exact Task Scheduler
   steps if you want to set this up — it's a five-minute one-time setup.

## Honest limits of this build (read before treating any number as gospel)

- **Discovery quality depends on search results.** It finds what shows up
  for the query templates in `config.py` — it will miss companies that
  don't rank well for those searches, and can occasionally pick up a
  non-company site the blocklist didn't catch. Check the "Tracked
  Companies" list after the first run and prune anything wrong by deleting
  its row from the `companies` table (or ask me to add a quick prune script).
- **Price extraction is heuristic, not schema-based.** Unlike a
  hand-configured per-site scraper, this reads *any* currency-tagged number
  near pricing language on a page — it can occasionally pick up a
  non-price number (e.g. a phone number, a year) that happens to sit near
  those words. The dashboard footer says this deliberately; treat
  sector-level trend direction as signal, individual numbers with some
  skepticism until you've watched it run for a few cycles.
- **No proxy rotation / stealth hardening.** Some sites may block the
  scraper outright (shows up as repeated "fetch failed" in the terminal
  log) — that's expected at this scope; the enterprise version's anti-bot
  stack (Part 1 of the original architecture doc) is what would fix that,
  and is a real next step if a specific target keeps failing.
- **One box, one process.** This is intentionally not the Kafka/Temporal/
  Postgres version — it's sized to actually run, today, on your laptop.

## Natural next steps, in order of value

1. Watch it run for 2–3 days so real trend data accumulates (day one will
   look sparse — that's expected, not broken).
2. Tune `config.py`'s `DISCOVERY_QUERY_TEMPLATES` if it's missing an obvious
   company or picking up junk.
3. If you want it running truly 24/7 past your laptop being open, set up
   the Task Scheduler background launch above.
