"""
Sentinel Radar — Configuration
================================
Change SECTOR / COUNTRY here to point the whole system at a different market.
Everything else (discovery, scraping, trends, dashboard) reads from this file.
"""

# ── What to track ────────────────────────────────────────────────────────
SECTOR = "telecom and mobile money"
COUNTRY = "Zimbabwe"

# Search queries used by discovery.py to find companies automatically.
# {sector} and {country} are filled in from above. Add more templates to
# widen discovery; each one runs as a separate search.
DISCOVERY_QUERY_TEMPLATES = [
    "{sector} companies in {country}",
    "{sector} providers {country} official website",
    "list of {sector} operators in {country}",
    "{sector} pricing plans {country}",
]

# Domains that are never treated as a "company" even if they show up in
# search results (news sites, wikis, aggregators, social platforms).
DOMAIN_BLOCKLIST_SUBSTRINGS = [
    "wikipedia.org", "facebook.com", "twitter.com", "x.com", "linkedin.com",
    "youtube.com", "instagram.com", "reddit.com", "news24.com", "herald.co.zw",
    "newsday.co.zw", "bulawayo24.com", "techzim.co.zw",  # good sources, but not "companies"
    "google.com", "bing.com",
]

# Candidate paths tried on each discovered domain to find a pricing/plans page.
PRICING_PATH_CANDIDATES = [
    "/", "/pricing", "/plans", "/packages", "/tariffs", "/bundles",
    "/products", "/services", "/personal", "/prepaid",
]

# Keywords used to (a) identify likely pricing pages when following links,
# and (b) scope the heuristic price-extraction regex to relevant text blocks.
PRICING_KEYWORDS = [
    "price", "pricing", "plan", "plans", "package", "bundle", "tariff",
    "subscription", "monthly", "data plan", "airtime", "top up",
]

CURRENCY_SYMBOLS = ["$", "US$", "USD", "ZWG", "ZWL", "Z$"]

# ── Scheduling cadence ───────────────────────────────────────────────────
DISCOVERY_INTERVAL_HOURS = 24     # look for new companies once a day
SCRAPE_INTERVAL_HOURS = 6         # re-check known companies 4x/day
TREND_REPORT_INTERVAL_HOURS = 24  # roll up sector trends once a day

# ── Storage ──────────────────────────────────────────────────────────────
DB_PATH = "sentinel_radar.db"

# ── Anthropic (used only by the optional AI narration step in trends.py) ──
ANTHROPIC_MODEL = "claude-sonnet-4-6"
