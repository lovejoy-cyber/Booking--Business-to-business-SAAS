# BookFlow

Online booking and automatic WhatsApp reminders for appointment-based businesses — barbershops first, built to extend to salons, tutors, mechanics, photographers, and repair shops without a rewrite.

> **Status:** this is a working MVP, not a mockup. Every flow described below is implemented end to end: registration → business setup → services & hours → public booking page → real availability/conflict logic → WhatsApp notification queue (with a demo mode that requires no real credentials) → dashboard, calendar, customer management → admin panel.

---

## Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Design](#design)
- [Requirements](#requirements)
- [Installation](#installation)
- [Environment variables](#environment-variables)
- [Database setup & migrations](#database-setup--migrations)
- [Seed data](#seed-data)
- [Development mode (demo mode)](#development-mode-demo-mode)
- [WhatsApp configuration](#whatsapp-configuration)
- [Billing](#billing)
- [Production deployment](#production-deployment)
- [Security considerations](#security-considerations)
- [Testing](#testing)
- [Troubleshooting](#troubleshooting)
- [Production hardening / known limitations](#production-hardening--known-limitations)

---

## Overview

A business owner signs up, adds their services and working hours, and gets a public booking page at `/book/their-slug`. Customers book without creating an account; BookFlow checks real availability (working hours, breaks, existing bookings, service duration) and prevents double-booking. On booking, cancellation, and reschedule, BookFlow queues a WhatsApp message — a confirmation immediately, a reminder 24 hours out, and another the morning of. Everything works in **demo mode** (simulated sends) before a business connects a real WhatsApp Business Cloud API number.

## Architecture

- **Frontend:** Next.js 14 (App Router), TypeScript, Tailwind CSS.
- **Backend:** Next.js Route Handlers (`src/app/api/**`) — no separate backend process.
- **Database:** PostgreSQL via Prisma ORM (`prisma/schema.prisma`).
- **Auth:** email + bcrypt password hash, signed JWT session in an httpOnly cookie (`src/lib/auth.ts`).
- **WhatsApp:** official Cloud API only (`src/lib/whatsapp/client.ts`) — no browser automation, no unofficial APIs.
- **Multi-tenancy:** every business-scoped table has a `businessId`. Authorization is enforced in code at the data-access layer (`src/lib/tenant.ts`), not just in the UI — every API route calls `requireCurrentBusiness()` / `requireBusinessAccess()` before touching business data.

```
src/
  app/
    (auth)/login, (auth)/register       — auth pages
    (dashboard)/dashboard/**            — the business owner's app
    admin/**                            — platform admin (SUPER_ADMIN only)
    book/[slug]/**                      — public customer booking page
    api/**                              — all Route Handlers
  components/
    ui/**                               — Button, Card, Field, Badge, Ticket
    dashboard/**, landing/**            — feature-specific components
  lib/
    booking/availability.ts             — the availability engine
    booking/appointments.ts             — create/cancel/reschedule + notification hooks
    whatsapp/{client,demo,service,templates}.ts
    auth.ts, session.ts, tenant.ts       — auth, session, authorization
    validation.ts                       — all zod schemas
    crypto.ts                           — AES-256-GCM for the WhatsApp token
prisma/
  schema.prisma, seed.ts
tests/
scripts/
  notification-worker.ts                — local dev queue processor
```

### Booking logic

`src/lib/booking/availability.ts` is the single source of truth for "is this slot bookable":

1. Load the business's working hours for that day of week (an employee-specific row overrides the business default).
2. Subtract blocked time (business-wide or employee-specific — breaks, holidays, time off).
3. Subtract existing `PENDING`/`CONFIRMED` appointments for the same **resource** (a specific employee, or — for a solo business with no employees configured — the business as a whole).
4. Generate candidate start times at the business's slot interval, keep only ones where the service fits before closing and after the minimum lead time.

At the moment of booking, `assertSlotStillAvailable()` re-checks the exact same conditions, and `createAppointment()` wraps the final conflict check and insert in one Prisma transaction — so a slot shown as available two minutes ago is rejected if someone else took it in between.

### WhatsApp notification queue

Bookings never call the WhatsApp API synchronously. `enqueueNotification()` writes a `Notification` row (`PENDING`); `processPendingNotifications()` drains it, branching on `business.isDemoMode`:

- **Demo mode:** `src/lib/whatsapp/demo.ts` simulates an instant `DELIVERED` result. Nothing leaves your server.
- **Production:** decrypts the business's stored access token and calls the real Cloud API (`src/lib/whatsapp/client.ts`), using pre-approved message templates. Failures are recorded with an error message and retried up to 5 times; delivery-status webhooks flip `SENT` → `DELIVERED`.

Reminders are scheduled at booking time (`scheduleReminders()` in `appointments.ts`) as future-dated `PENDING` notifications — a 24-hour-before reminder and a same-day reminder — and cancelled/recreated on cancellation/reschedule.

## Design

The visual identity is built around one signature element: **the Ticket** (`src/components/ui/Ticket.tsx`) — a perforated-edge card modeled on the paper queue ticket a barbershop customer takes and the receipt-like confirmation a WhatsApp message delivers. It's reused for the booking confirmation screen, dashboard appointment cards, and landing-page pricing, so "you have an appointment" reads as a tangible object throughout the product rather than a generic card.

Color and type tokens live in `tailwind.config.ts`: pine (brand/trust/confirmed states), brass (CTAs/premium accents), signal green (used only as the "delivered" micro-accent), on a chalk-toned paper background — deliberately not the cream-and-terracotta look common in AI-generated design. Display type is Fraunces, body is Inter, and data (prices, times, ticket codes) is IBM Plex Mono.

## Requirements

- Node.js 18.18+ (Node 20 LTS recommended)
- PostgreSQL 14+
- A WhatsApp Business Cloud API account (only needed to leave demo mode)

## Installation

```bash
git clone <this-repo>
cd bookflow
npm install
cp .env.example .env
# edit .env — at minimum set DATABASE_URL and AUTH_SECRET
npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

Visit `http://localhost:3000`. Log in with the seeded demo account (see [Seed data](#seed-data)), or register a new business.

> **Note on this build environment:** this codebase was written in a sandbox without package-registry network access, so dependencies have not been installed or compiled here — `npm install` has not been run against it yet. The code is complete and internally consistent against each library's documented API, but treat the very first `npm install && npm run build` in your own environment as the real first compile, and fix anything a real toolchain flags (version pin mismatches, etc.) before you consider it production-ready.

## Environment variables

See `.env.example` for the full list with descriptions. Required to boot:

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | Postgres connection string |
| `AUTH_SECRET` | Signs session JWTs — 32+ random characters |
| `WHATSAPP_TOKEN_ENCRYPTION_KEY` | Encrypts stored WhatsApp access tokens at rest |
| `CRON_SECRET` | Required header for `POST /api/notifications/process` |

Required only once a business leaves demo mode:

| Variable | Purpose |
|---|---|
| `WHATSAPP_APP_SECRET` | Verifies webhook signatures from Meta |
| `WHATSAPP_WEBHOOK_VERIFY_TOKEN` | The token you enter in Meta's webhook setup screen |
| `STRIPE_SECRET_KEY` | Stripe API key |
| `STRIPE_WEBHOOK_SECRET` | Verifies Stripe webhook signatures |
| `STRIPE_PRICE_STARTER` / `_PROFESSIONAL` / `_BUSINESS` | Stripe Price IDs for each paid plan |

Never commit `.env` — it's already in `.gitignore`.

## Database setup & migrations

```bash
npx prisma migrate dev --name <description>   # create + apply a migration locally
npx prisma migrate deploy                     # apply pending migrations in production
npx prisma studio                             # browse data in a GUI
npx prisma generate                           # regenerate the client (runs automatically on install)
```

## Seed data

```bash
npm run db:seed
```

Creates:
- A business, **Elite Cuts** (`/book/elite-cuts`), with realistic working hours and three services (Haircut $10/30min, Haircut + Beard $15/45min, Full Service $25/60min).
- Owner login: `demo@bookflow.app` / `Demo1234!`
- Platform admin login: `admin@bookflow.app` / `Admin1234!` (visit `/admin`)
- Four sample customers and seven appointments spanning completed, cancelled, no-show, and upcoming — so the dashboard, calendar, and analytics aren't empty on first look.

The seed is idempotent (`upsert`) — safe to re-run.

## Development mode (demo mode)

Every new business starts with `isDemoMode = true`. In demo mode:
- Bookings, cancellations, and rescheduling all work exactly like production.
- WhatsApp messages are queued exactly like production, but "sent" by `src/lib/whatsapp/demo.ts`, which never calls a real API — they're marked `DELIVERED` immediately.
- The dashboard's **Notifications** page shows exactly what would have been sent, tagged **Demo**.

A business leaves demo mode automatically the moment its owner saves valid credentials in **Settings → WhatsApp**, and returns to demo mode if they disconnect. Demo mode is never silently used in place of a real send once credentials are configured — `processPendingNotifications()` branches strictly on `business.isDemoMode`.

To actually see queued notifications flip from `PENDING` to `SENT`/`DELIVERED` during local development, run the worker alongside `npm run dev`:

```bash
npm run notifications:worker
```

## WhatsApp configuration

1. Create a Meta Business app with the WhatsApp product, following [Meta's Cloud API quickstart](https://developers.facebook.com/docs/whatsapp/cloud-api/get-started).
2. In **Settings → WhatsApp** in BookFlow, enter the **Phone Number ID**, **WhatsApp Business Account ID**, and a **permanent access token**. This encrypts and stores the token (`WHATSAPP_TOKEN_ENCRYPTION_KEY`) and flips the business out of demo mode.
3. In Meta's dashboard, point the webhook at `https://your-domain.com/api/webhooks/whatsapp`, using the same value you set as `WHATSAPP_WEBHOOK_VERIFY_TOKEN`.
4. Submit the five message templates BookFlow expects for approval in Meta Business Manager (names in `src/lib/whatsapp/templates.ts` → `WHATSAPP_TEMPLATE_NAMES`): booking confirmation, 24-hour reminder, same-day reminder, cancellation, reschedule. Outside Meta's 24-hour customer-service window, only approved templates can be sent — this is a WhatsApp platform rule, not a BookFlow limitation.
5. Set up a scheduled job to call `POST /api/notifications/process` every 1–2 minutes with header `X-Cron-Secret: <your CRON_SECRET>` (e.g. Vercel Cron, a GitHub Actions schedule, or any external cron hitting your deployed URL).

## Billing

BookFlow's paid plans run on Stripe Checkout + the Billing Portal — no custom payment UI to build or maintain.

1. In the Stripe Dashboard, create one **Product** with a **recurring Price** for each paid plan (Starter, Professional, Business) — amounts in `src/lib/billing/plans.ts` are illustrative ($19/$39/$79 per month); set them to match whatever the business actually charges.
2. Copy each Price's ID (`price_...`) into `STRIPE_PRICE_STARTER`, `STRIPE_PRICE_PROFESSIONAL`, `STRIPE_PRICE_BUSINESS`.
3. Set `STRIPE_SECRET_KEY` from the Dashboard's API keys page.
4. Add a webhook endpoint pointing at `https://your-domain.com/api/webhooks/stripe`, subscribed to at least: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.payment_failed`. Copy its signing secret into `STRIPE_WEBHOOK_SECRET`.
5. From **Settings → Billing** in the app, an owner clicks **Upgrade** on a plan, which creates a Checkout Session (`POST /api/billing/checkout`) and redirects to Stripe-hosted checkout. On success, the webhook applies the new plan/status — the UI never trusts the checkout redirect itself, only the webhook.
6. **Manage billing & invoices** opens the Stripe Billing Portal (`POST /api/billing/portal`) for card updates, invoice history, and self-service cancellation.

Limits are enforced where it actually matters, not just displayed: `enforceAppointmentLimit()` runs inside `createAppointment()` before every booking (public and dashboard-originated), and `enforceStaffLimit()` runs before every new staff member is added — both throw a clear, actionable `AppError` rather than silently allowing overage. A cancelled subscription blocks new bookings outright regardless of remaining quota.

## Production deployment

Any Node.js host works. A straightforward path:

1. **Database:** provision Postgres (Supabase, Neon, Railway, RDS).
2. **App:** deploy to Vercel, Railway, or a Docker host running `npm run build && npm run start`.
3. Set all environment variables from `.env.example` in your host's dashboard.
4. Run `npx prisma migrate deploy` against the production database (a one-off release step, or a `postinstall`/release-phase command depending on host).
5. Schedule `POST /api/notifications/process` (see above) — without this, notifications will queue but never send in production.
6. Point your WhatsApp webhook at the deployed URL (see above).
7. Optionally run `npm run db:seed` once, then change the seeded passwords immediately, or skip seeding entirely in production.

## Security considerations

- **Passwords:** bcrypt, cost factor 12 (`src/lib/auth.ts`).
- **Sessions:** signed JWT (HS256) in an httpOnly, `SameSite=Lax`, `Secure`-in-production cookie. No session state is trusted from the client beyond that signed token.
- **Tenant isolation:** enforced server-side on every business-scoped query via `requireBusinessAccess`/`requireCurrentBusiness` (`src/lib/tenant.ts`) — not just hidden in the UI.
- **Secrets:** WhatsApp access tokens are AES-256-GCM encrypted at rest (`src/lib/crypto.ts`) and are never returned to the frontend, logged, or included in audit-log metadata.
- **Webhook verification:** the WhatsApp webhook validates Meta's `X-Hub-Signature-256` against `WHATSAPP_APP_SECRET` before trusting any payload.
- **Rate limiting:** in-memory sliding-window limiter (`src/lib/rateLimit.ts`) on register, login (by IP and by email separately), and the public availability/booking endpoints. This is intentionally simple for a single-instance MVP — swap for a shared store (e.g. Upstash Redis) behind the same function signature before scaling horizontally.
- **Input validation:** every API route validates its body/query with zod (`src/lib/validation.ts`) before touching the database.
- **SQL injection:** all queries go through Prisma's parameterized query builder — no raw string-interpolated SQL anywhere in the codebase.
- **XSS:** React escapes all rendered content by default; nothing in the app uses `dangerouslySetInnerHTML`.
- **Errors:** `src/lib/errors.ts` ensures only deliberately-thrown `AppError`s (or zod validation errors) leak a message to the client — anything else is logged server-side and replaced with a generic message. No stack traces ever reach the browser.
- **Audit logging:** sensitive actions (cancellations, reschedules, settings changes, WhatsApp credential updates, admin actions) are recorded in `AuditLog` via `src/lib/audit.ts`, without ever including the credential value itself.
- **Admin panel:** gated by `platformRole = SUPER_ADMIN`, checked server-side in `src/app/admin/layout.tsx`; admin API responses use explicit Prisma `select` allow-lists that never include password hashes or WhatsApp tokens.

## Testing

```bash
npm test          # run once
npm run test:watch
```

Tests in `tests/` are **integration tests against a real Postgres database** — point `DATABASE_URL` at a disposable database before running (the test setup truncates business-scoped tables before every test; never point this at production data).

Coverage:
- `auth.test.ts` — password hashing/verification, session token signing/verification, tampered-token rejection.
- `tenant-isolation.test.ts` — cross-business access is rejected, role-based authorization (`EMPLOYEE` can't do `OWNER`-only actions), query-level scoping.
- `availability.test.ts` — the `overlaps()` interval-math primitive, working-hours-aware slot generation, exclusion of slots that conflict with existing appointments, closed-day handling, and the write-time re-validation used to prevent race conditions.
- `appointments.test.ts` — appointment creation (incl. new-customer upsert + confirmation notification), **double-booking prevention**, adjacent (non-overlapping) bookings being allowed, working-hours rejection, cancellation (incl. re-opening the freed slot and queuing a cancellation notification), rejecting a double-cancel, and rescheduling (incl. rejecting a reschedule into an already-taken slot).
- `validation.test.ts` — invalid input rejection across the phone-number, registration, service, and public-booking schemas.

## Troubleshooting

- **"AUTH_SECRET is missing or too short"** — set a 32+ character random value in `.env`.
- **Prisma can't connect** — confirm `DATABASE_URL`, that Postgres is running, and that the database in the URL exists (`createdb bookflow`).
- **Booking page shows "We couldn't find that business"** — check the slug in the URL matches a business's `slug` column exactly (case-sensitive).
- **WhatsApp messages stuck in `PENDING`** — nothing is draining the queue. Run `npm run notifications:worker` locally, or confirm your production cron is calling `/api/notifications/process` with the correct `X-Cron-Secret`.
- **WhatsApp messages `FAILED`** — check the `errorMessage` on the Notifications page; usually an unapproved template, an expired token, or an incorrectly formatted phone number.
- **"That time was just booked" errors under normal use** — this is the double-booking guard working as intended; if it fires constantly under light load, check for clock drift between your app server and database.

## Production hardening / known limitations

Documented honestly rather than hidden:

- **Booking race condition:** `createAppointment()` re-checks for conflicts inside a transaction immediately before inserting, which narrows the race window between two simultaneous bookings for the same slot to a few milliseconds — but Prisma migrations don't natively support a Postgres `EXCLUDE ... USING gist` constraint, so this is a strong mitigation, not a hard database-level guarantee. For very high-concurrency deployments, add a raw-SQL migration creating an exclusion constraint on `(businessId, employeeId, tsrange(startsAt, endsAt))` using the `btree_gist` extension.
- **Rate limiting is in-memory and per-instance.** Fine for one server; swap for Redis-backed limiting before running multiple instances behind a load balancer.
- **Billing is wired to Stripe.** Checkout Sessions (`POST /api/billing/checkout`) create a subscription for a chosen plan; the webhook (`POST /api/webhooks/stripe`, signature-verified) syncs plan/status back onto the `Subscription` row on `checkout.session.completed`, `customer.subscription.updated/deleted`, and `invoice.payment_failed`. Appointment and staff limits (`src/lib/billing/subscription.ts`) are enforced server-side on every booking and every staff-add — not just shown in the UI. See **WhatsApp configuration** below for the equivalent webhook setup pattern; Stripe's is analogous: point `STRIPE_WEBHOOK_SECRET` at a webhook endpoint targeting `/api/webhooks/stripe`, and create one Stripe Price per paid plan, pasting the IDs into `STRIPE_PRICE_STARTER`/`_PROFESSIONAL`/`_BUSINESS`.
- **Notification delivery requires an external scheduler.** BookFlow does not run its own background worker in production — see [WhatsApp configuration](#whatsapp-configuration) step 5.
