import { describe, it, expect, beforeEach } from "vitest";
import { db } from "@/lib/db";
import { hashPassword } from "@/lib/auth";
import { checkBusinessAccess } from "@/lib/tenant";
import { AppError } from "@/lib/errors";

describe("tenant isolation — checkBusinessAccess()", () => {
  let businessA: { id: string };
  let businessB: { id: string };
  let ownerA: { id: string };

  beforeEach(async () => {
    const passwordHash = await hashPassword("Password123!");
    ownerA = await db.user.create({ data: { name: "Owner A", email: `a-${Date.now()}@example.com`, passwordHash } });
    const ownerB = await db.user.create({ data: { name: "Owner B", email: `b-${Date.now()}@example.com`, passwordHash } });

    businessA = await db.business.create({ data: { name: "Shop A", slug: `shop-a-${Date.now()}` } });
    businessB = await db.business.create({ data: { name: "Shop B", slug: `shop-b-${Date.now()}` } });

    await db.businessMember.create({ data: { businessId: businessA.id, userId: ownerA.id, role: "OWNER" } });
    await db.businessMember.create({ data: { businessId: businessB.id, userId: ownerB.id, role: "OWNER" } });
  });

  it("grants access to a business the user is a member of", async () => {
    const ctx = await checkBusinessAccess(ownerA.id, businessA.id);
    expect(ctx.businessId).toBe(businessA.id);
    expect(ctx.role).toBe("OWNER");
  });

  it("rejects access to a business the user is NOT a member of", async () => {
    await expect(checkBusinessAccess(ownerA.id, businessB.id)).rejects.toThrow(AppError);
  });

  it("rejects an EMPLOYEE attempting an OWNER-only action", async () => {
    const passwordHash = await hashPassword("Password123!");
    const employee = await db.user.create({ data: { name: "Employee", email: `emp-${Date.now()}@example.com`, passwordHash } });
    await db.businessMember.create({ data: { businessId: businessA.id, userId: employee.id, role: "EMPLOYEE" } });

    await expect(checkBusinessAccess(employee.id, businessA.id, "OWNER")).rejects.toThrow(AppError);
    // But an ordinary EMPLOYEE-level action should still succeed for them.
    const ctx = await checkBusinessAccess(employee.id, businessA.id, "EMPLOYEE");
    expect(ctx.role).toBe("EMPLOYEE");
  });

  it("a business's customers and appointments never appear in another business's query results", async () => {
    const customerA = await db.customer.create({ data: { businessId: businessA.id, name: "Customer A", whatsappE164: "+15551110000" } });
    await db.customer.create({ data: { businessId: businessB.id, name: "Customer B", whatsappE164: "+15551110001" } });

    const businessAsCustomers = await db.customer.findMany({ where: { businessId: businessA.id } });
    expect(businessAsCustomers.map((c) => c.id)).toEqual([customerA.id]);
  });
});
