import { beforeEach, afterAll } from "vitest";
import { db } from "@/lib/db";

/**
 * Integration tests run against a real Postgres database — set TEST_DATABASE_URL
 * (or reuse DATABASE_URL) to a disposable database before running `npm test`.
 * Never point this at production data: this truncates business-scoped tables
 * before every test.
 */
beforeEach(async () => {
  await db.$transaction([
    db.notification.deleteMany(),
    db.appointment.deleteMany(),
    db.blockedTime.deleteMany(),
    db.workingHour.deleteMany(),
    db.customer.deleteMany(),
    db.service.deleteMany(),
    db.employee.deleteMany(),
    db.whatsAppConfiguration.deleteMany(),
    db.subscription.deleteMany(),
    db.auditLog.deleteMany(),
    db.businessMember.deleteMany(),
    db.business.deleteMany(),
    db.user.deleteMany(),
  ]);
});

afterAll(async () => {
  await db.$disconnect();
});
