import { describe, it, expect, beforeEach } from "vitest";
import { db } from "@/lib/db";
import { createAppointment, cancelAppointment, rescheduleAppointment } from "@/lib/booking/appointments";
import { AppError } from "@/lib/errors";
import type { Business } from "@prisma/client";

function nextWeekdayAt(target: number, hour: number): Date {
  const d = new Date();
  const diff = (target + 7 - d.getDay()) % 7 || 7;
  d.setDate(d.getDate() + diff);
  d.setUTCHours(hour, 0, 0, 0);
  return d;
}

describe("createAppointment()", () => {
  let business: Business;
  let serviceId: string;

  beforeEach(async () => {
    business = await db.business.create({
      data: { name: "Test Barber", slug: `test-barber-${Date.now()}`, timezone: "UTC", minLeadTimeMinutes: 0, maxAdvanceBookingDays: 90 },
    });
    const service = await db.service.create({ data: { businessId: business.id, name: "Haircut", priceCents: 1000, durationMinutes: 30 } });
    serviceId = service.id;
    await db.workingHour.create({
      data: { businessId: business.id, employeeId: null, dayOfWeek: 1, startTime: "09:00", endTime: "17:00", isClosed: false },
    });
  });

  it("creates an appointment, a new customer, and a booking confirmation notification", async () => {
    const startsAt = nextWeekdayAt(1, 10);
    const appointment = await createAppointment({
      business,
      serviceId,
      startsAt,
      customer: { name: "New Customer", whatsappE164: "+15550001111" },
    });

    expect(appointment.status).toBe("CONFIRMED");

    const customer = await db.customer.findUnique({ where: { id: appointment.customerId } });
    expect(customer?.name).toBe("New Customer");

    const notifications = await db.notification.findMany({ where: { appointmentId: appointment.id } });
    expect(notifications.some((n) => n.type === "BOOKING_CONFIRMATION")).toBe(true);
  });

  it("rejects a second booking that overlaps an existing one (double-booking prevention)", async () => {
    const startsAt = nextWeekdayAt(1, 10);

    await createAppointment({ business, serviceId, startsAt, customer: { name: "First", whatsappE164: "+15550002222" } });

    await expect(
      createAppointment({ business, serviceId, startsAt, customer: { name: "Second", whatsappE164: "+15550003333" } })
    ).rejects.toThrow(AppError);
  });

  it("allows back-to-back bookings that do not actually overlap", async () => {
    const first = nextWeekdayAt(1, 10);
    const second = new Date(first.getTime() + 30 * 60_000); // exactly when the first ends

    await createAppointment({ business, serviceId, startsAt: first, customer: { name: "First", whatsappE164: "+15550004444" } });
    const appointment = await createAppointment({
      business,
      serviceId,
      startsAt: second,
      customer: { name: "Second", whatsappE164: "+15550005555" },
    });

    expect(appointment.status).toBe("CONFIRMED");
  });

  it("rejects a booking outside working hours", async () => {
    const outsideHours = nextWeekdayAt(1, 20); // 20:00, business closes at 17:00
    await expect(
      createAppointment({ business, serviceId, startsAt: outsideHours, customer: { name: "Late", whatsappE164: "+15550006666" } })
    ).rejects.toThrow(AppError);
  });

  it("rejects an unknown service id", async () => {
    await expect(
      createAppointment({
        business,
        serviceId: "does-not-exist",
        startsAt: nextWeekdayAt(1, 10),
        customer: { name: "Someone", whatsappE164: "+15550007777" },
      })
    ).rejects.toThrow(AppError);
  });
});

describe("cancelAppointment() and rescheduleAppointment()", () => {
  let business: Business;
  let serviceId: string;

  beforeEach(async () => {
    business = await db.business.create({
      data: { name: "Test Barber", slug: `test-barber-${Date.now()}`, timezone: "UTC", minLeadTimeMinutes: 0, maxAdvanceBookingDays: 90 },
    });
    const service = await db.service.create({ data: { businessId: business.id, name: "Haircut", priceCents: 1000, durationMinutes: 30 } });
    serviceId = service.id;
    await db.workingHour.create({
      data: { businessId: business.id, employeeId: null, dayOfWeek: 1, startTime: "09:00", endTime: "17:00", isClosed: false },
    });
  });

  it("cancels an appointment, frees the slot, and queues a cancellation notification", async () => {
    const startsAt = nextWeekdayAt(1, 10);
    const appointment = await createAppointment({ business, serviceId, startsAt, customer: { name: "A", whatsappE164: "+15550008888" } });

    const cancelled = await cancelAppointment({ business, appointmentId: appointment.id, reason: "Customer requested" });
    expect(cancelled.status).toBe("CANCELLED");

    // The freed slot should now be bookable again.
    const rebooked = await createAppointment({ business, serviceId, startsAt, customer: { name: "B", whatsappE164: "+15550009999" } });
    expect(rebooked.status).toBe("CONFIRMED");

    const notifications = await db.notification.findMany({ where: { appointmentId: appointment.id } });
    expect(notifications.some((n) => n.type === "CANCELLATION")).toBe(true);
  });

  it("rejects cancelling an appointment twice", async () => {
    const startsAt = nextWeekdayAt(1, 10);
    const appointment = await createAppointment({ business, serviceId, startsAt, customer: { name: "A", whatsappE164: "+15550011111" } });
    await cancelAppointment({ business, appointmentId: appointment.id });

    await expect(cancelAppointment({ business, appointmentId: appointment.id })).rejects.toThrow(AppError);
  });

  it("reschedules to a free slot and rejects rescheduling into a taken one", async () => {
    const slotA = nextWeekdayAt(1, 10);
    const slotB = nextWeekdayAt(1, 11);

    const appointmentA = await createAppointment({ business, serviceId, startsAt: slotA, customer: { name: "A", whatsappE164: "+15550022222" } });
    await createAppointment({ business, serviceId, startsAt: slotB, customer: { name: "B", whatsappE164: "+15550033333" } });

    await expect(rescheduleAppointment({ business, appointmentId: appointmentA.id, startsAt: slotB })).rejects.toThrow(AppError);

    const freeSlot = nextWeekdayAt(1, 14);
    const rescheduled = await rescheduleAppointment({ business, appointmentId: appointmentA.id, startsAt: freeSlot });
    expect(rescheduled.startsAt.toISOString()).toBe(freeSlot.toISOString());

    const notifications = await db.notification.findMany({ where: { appointmentId: appointmentA.id } });
    expect(notifications.some((n) => n.type === "RESCHEDULE")).toBe(true);
  });
});
