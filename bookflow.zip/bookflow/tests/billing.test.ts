import { describe, it, expect, beforeEach } from "vitest";
import { db } from "@/lib/db";
import { createAppointment } from "@/lib/booking/appointments";
import { enforceStaffLimit, getUsageSummary } from "@/lib/billing/subscription";
import { PLANS } from "@/lib/billing/plans";
import { AppError } from "@/lib/errors";
import type { Business } from "@prisma/client";

function nextWeekdayAt(target: number, hour: number): Date {
  const d = new Date();
  const diff = (target + 7 - d.getDay()) % 7 || 7;
  d.setDate(d.getDate() + diff);
  d.setUTCHours(hour, 0, 0, 0);
  return d;
}

describe("appointment limit enforcement", () => {
  let business: Business;
  let serviceId: string;

  beforeEach(async () => {
    business = await db.business.create({
      data: { name: "Test Barber", slug: `test-barber-${Date.now()}`, timezone: "UTC", minLeadTimeMinutes: 0, maxAdvanceBookingDays: 90 },
    });
    const service = await db.service.create({ data: { businessId: business.id, name: "Haircut", priceCents: 1000, durationMinutes: 15 } });
    serviceId = service.id;
    await db.workingHour.create({
      data: { businessId: business.id, employeeId: null, dayOfWeek: 1, startTime: "09:00", endTime: "20:00", isClosed: false },
    });
  });

  it("blocks a new booking once the plan's appointment limit is reached", async () => {
    await db.subscription.create({
      data: { businessId: business.id, plan: "FREE_TRIAL", status: "TRIALING", appointmentLimit: 2, staffLimit: 1 },
    });

    await createAppointment({ business, serviceId, startsAt: nextWeekdayAt(1, 9), customer: { name: "A", whatsappE164: "+15559990001" } });
    await createAppointment({ business, serviceId, startsAt: nextWeekdayAt(1, 10), customer: { name: "B", whatsappE164: "+15559990002" } });

    await expect(
      createAppointment({ business, serviceId, startsAt: nextWeekdayAt(1, 11), customer: { name: "C", whatsappE164: "+15559990003" } })
    ).rejects.toThrow(AppError);
  });

  it("never blocks a business on an unlimited (-1) plan", async () => {
    await db.subscription.create({
      data: { businessId: business.id, plan: "BUSINESS", status: "ACTIVE", appointmentLimit: -1, staffLimit: -1 },
    });

    for (let i = 0; i < 5; i++) {
      await createAppointment({ business, serviceId, startsAt: nextWeekdayAt(1, 9 + i), customer: { name: `C${i}`, whatsappE164: `+1555999${1000 + i}` } });
    }

    const summary = await getUsageSummary(business.id);
    expect(summary.appointmentsUsed).toBe(5);
    expect(summary.isOverLimit).toBe(false);
    expect(summary.appointmentsRemaining).toBeNull();
  });

  it("blocks all bookings once a subscription is CANCELLED, regardless of usage", async () => {
    await db.subscription.create({
      data: { businessId: business.id, plan: "STARTER", status: "CANCELLED", appointmentLimit: 100, staffLimit: 1 },
    });

    await expect(
      createAppointment({ business, serviceId, startsAt: nextWeekdayAt(1, 9), customer: { name: "A", whatsappE164: "+15559990099" } })
    ).rejects.toThrow(AppError);
  });
});

describe("staff limit enforcement", () => {
  it("blocks adding staff beyond the plan's staffLimit", async () => {
    const business = await db.business.create({ data: { name: "Test Barber", slug: `test-barber-${Date.now()}` } });
    await db.subscription.create({
      data: { businessId: business.id, plan: "FREE_TRIAL", status: "TRIALING", appointmentLimit: 30, staffLimit: 1 },
    });
    await db.employee.create({ data: { businessId: business.id, name: "First Barber" } });

    await expect(enforceStaffLimit(business.id)).rejects.toThrow(AppError);
  });

  it("allows unlimited staff on a plan with staffLimit -1", async () => {
    const business = await db.business.create({ data: { name: "Test Barber", slug: `test-barber-${Date.now()}` } });
    await db.subscription.create({
      data: { businessId: business.id, plan: "BUSINESS", status: "ACTIVE", appointmentLimit: -1, staffLimit: -1 },
    });
    for (let i = 0; i < 10; i++) {
      await db.employee.create({ data: { businessId: business.id, name: `Barber ${i}` } });
    }
    await expect(enforceStaffLimit(business.id)).resolves.toBeUndefined();
  });
});

describe("PLANS catalog", () => {
  it("keeps FREE_TRIAL free and every paid plan priced above zero", () => {
    expect(PLANS.FREE_TRIAL.priceCents).toBe(0);
    expect(PLANS.STARTER.priceCents).toBeGreaterThan(0);
    expect(PLANS.PROFESSIONAL.priceCents).toBeGreaterThan(PLANS.STARTER.priceCents);
    expect(PLANS.BUSINESS.priceCents).toBeGreaterThan(PLANS.PROFESSIONAL.priceCents);
  });
});
