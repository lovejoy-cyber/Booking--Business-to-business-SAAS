import { describe, it, expect, beforeEach } from "vitest";
import { db } from "@/lib/db";
import { overlaps, getAvailableSlots, assertSlotStillAvailable } from "@/lib/booking/availability";
import { AppError } from "@/lib/errors";

describe("overlaps()", () => {
  it("detects overlapping intervals", () => {
    const a = { start: new Date("2026-01-01T10:00:00Z"), end: new Date("2026-01-01T10:30:00Z") };
    const b = { start: new Date("2026-01-01T10:15:00Z"), end: new Date("2026-01-01T10:45:00Z") };
    expect(overlaps(a, b)).toBe(true);
  });

  it("does not flag adjacent (touching) intervals as overlapping", () => {
    const a = { start: new Date("2026-01-01T10:00:00Z"), end: new Date("2026-01-01T10:30:00Z") };
    const b = { start: new Date("2026-01-01T10:30:00Z"), end: new Date("2026-01-01T11:00:00Z") };
    expect(overlaps(a, b)).toBe(false);
  });

  it("does not flag disjoint intervals as overlapping", () => {
    const a = { start: new Date("2026-01-01T09:00:00Z"), end: new Date("2026-01-01T09:30:00Z") };
    const b = { start: new Date("2026-01-01T10:00:00Z"), end: new Date("2026-01-01T10:30:00Z") };
    expect(overlaps(a, b)).toBe(false);
  });
});

// Next Monday relative to "now", so tests stay valid regardless of when they run.
function nextWeekday(target: number): string {
  const d = new Date();
  const diff = (target + 7 - d.getDay()) % 7 || 7;
  d.setDate(d.getDate() + diff);
  return d.toISOString().slice(0, 10);
}

describe("getAvailableSlots()", () => {
  let businessId: string;
  let serviceId: string;

  beforeEach(async () => {
    const business = await db.business.create({
      data: { name: "Test Barber", slug: `test-barber-${Date.now()}`, timezone: "UTC", minLeadTimeMinutes: 0 },
    });
    businessId = business.id;

    const service = await db.service.create({
      data: { businessId, name: "Haircut", priceCents: 1000, durationMinutes: 30 },
    });
    serviceId = service.id;

    // Monday 09:00-11:00 only, for a tight, easy-to-reason-about test window.
    await db.workingHour.create({
      data: { businessId, employeeId: null, dayOfWeek: 1, startTime: "09:00", endTime: "11:00", isClosed: false },
    });
  });

  it("returns slots within working hours, respecting service duration", async () => {
    const monday = nextWeekday(1);
    const slots = await getAvailableSlots({ businessId, serviceId, date: monday });
    expect(slots.length).toBeGreaterThan(0);
    // A 30-minute service in a 2-hour window at 15-minute steps should never
    // offer a slot that would run past 11:00.
    for (const slot of slots) {
      const end = new Date(new Date(slot).getTime() + 30 * 60_000);
      expect(end.getUTCHours()).toBeLessThanOrEqual(11);
    }
  });

  it("excludes slots that conflict with an existing appointment", async () => {
    const monday = nextWeekday(1);
    const customer = await db.customer.create({ data: { businessId, name: "Test Customer", whatsappE164: "+15550000000" } });
    const startsAt = new Date(`${monday}T09:30:00Z`);
    const endsAt = new Date(`${monday}T10:00:00Z`);
    await db.appointment.create({
      data: { businessId, customerId: customer.id, serviceId, startsAt, endsAt, status: "CONFIRMED", priceCents: 1000 },
    });

    const slots = await getAvailableSlots({ businessId, serviceId, date: monday });
    expect(slots).not.toContain(startsAt.toISOString());
  });

  it("returns no slots on a day the business is closed", async () => {
    const sunday = nextWeekday(0);
    const slots = await getAvailableSlots({ businessId, serviceId, date: sunday });
    expect(slots).toEqual([]);
  });
});

describe("assertSlotStillAvailable()", () => {
  it("throws a conflict error when the slot has just been booked", async () => {
    const business = await db.business.create({ data: { name: "Test Barber 2", slug: `test-barber-2-${Date.now()}`, timezone: "UTC" } });
    const service = await db.service.create({ data: { businessId: business.id, name: "Haircut", priceCents: 1000, durationMinutes: 30 } });
    const customer = await db.customer.create({ data: { businessId: business.id, name: "Existing Customer", whatsappE164: "+15550000001" } });

    const startsAt = new Date("2026-03-02T09:00:00Z");
    const endsAt = new Date("2026-03-02T09:30:00Z");
    await db.appointment.create({
      data: { businessId: business.id, customerId: customer.id, serviceId: service.id, startsAt, endsAt, status: "CONFIRMED", priceCents: 1000 },
    });

    await expect(
      assertSlotStillAvailable({ businessId: business.id, serviceId: service.id, startsAt, endsAt })
    ).rejects.toThrow(AppError);
  });
});
