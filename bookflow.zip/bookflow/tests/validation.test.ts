import { describe, it, expect } from "vitest";
import { e164Phone, registerSchema, serviceSchema, publicBookingSchema } from "@/lib/validation";

describe("e164Phone", () => {
  it("accepts valid E.164 numbers", () => {
    expect(e164Phone.safeParse("+15551234567").success).toBe(true);
    expect(e164Phone.safeParse("+447911123456").success).toBe(true);
  });

  it("rejects numbers without a country code or with invalid formatting", () => {
    expect(e164Phone.safeParse("5551234567").success).toBe(false);
    expect(e164Phone.safeParse("+0551234567").success).toBe(false); // leading 0 country code
    expect(e164Phone.safeParse("not-a-phone").success).toBe(false);
    expect(e164Phone.safeParse("+1 555 123 4567").success).toBe(false); // spaces not allowed
  });
});

describe("registerSchema", () => {
  const valid = {
    name: "Marcus Diallo",
    email: "marcus@example.com",
    password: "supersecure1",
    businessName: "Elite Cuts",
    businessType: "BARBER",
  };

  it("accepts a fully valid payload", () => {
    expect(registerSchema.safeParse(valid).success).toBe(true);
  });

  it("rejects a password shorter than 8 characters", () => {
    expect(registerSchema.safeParse({ ...valid, password: "short" }).success).toBe(false);
  });

  it("rejects an invalid email", () => {
    expect(registerSchema.safeParse({ ...valid, email: "not-an-email" }).success).toBe(false);
  });

  it("rejects an unknown business type", () => {
    expect(registerSchema.safeParse({ ...valid, businessType: "SPACESHIP" }).success).toBe(false);
  });
});

describe("serviceSchema", () => {
  it("rejects a negative price", () => {
    expect(serviceSchema.safeParse({ name: "Haircut", priceCents: -100, durationMinutes: 30 }).success).toBe(false);
  });

  it("rejects a duration under 5 minutes", () => {
    expect(serviceSchema.safeParse({ name: "Haircut", priceCents: 1000, durationMinutes: 1 }).success).toBe(false);
  });

  it("accepts a valid service", () => {
    expect(serviceSchema.safeParse({ name: "Haircut", priceCents: 1000, durationMinutes: 30 }).success).toBe(true);
  });
});

describe("publicBookingSchema", () => {
  it("rejects a booking missing a WhatsApp number", () => {
    const result = publicBookingSchema.safeParse({
      serviceId: "svc_1",
      startsAt: new Date().toISOString(),
      customerName: "Jane",
      whatsappE164: "",
    });
    expect(result.success).toBe(false);
  });

  it("rejects a non-ISO startsAt", () => {
    const result = publicBookingSchema.safeParse({
      serviceId: "svc_1",
      startsAt: "tomorrow at 2pm",
      customerName: "Jane",
      whatsappE164: "+15551234567",
    });
    expect(result.success).toBe(false);
  });
});
