import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // BookFlow token system — see README § Design for the rationale.
        // Pine: brand/trust/confirmed states. Brass: CTAs & premium accents.
        // Signal: sparing "delivered" micro-accent only. Paper: chalk-toned
        // light background (deliberately not cream). Ink: warm charcoal.
        pine: {
          50: "#eaf5f0",
          100: "#cfe8dc",
          200: "#a0d1b9",
          300: "#65b192",
          400: "#3d9074",
          500: "#256e58",
          600: "#1c6b4f",
          700: "#16543f",
          800: "#124331",
          900: "#0e3527",
          950: "#081f17",
        },
        brass: {
          50: "#fbf5ea",
          100: "#f3e2bf",
          200: "#e6c584",
          300: "#d6a955",
          400: "#c08a34",
          500: "#a5732a",
          600: "#875d22",
          700: "#6b491b",
          800: "#513714",
          900: "#3a270e",
        },
        signal: {
          400: "#5fe4a0",
          500: "#35d07f",
          600: "#26ad67",
        },
        paper: {
          DEFAULT: "#eef1f0",
          50: "#f7f8f8",
          100: "#eef1f0",
          200: "#e2e6e4",
          300: "#cfd5d2",
        },
        ink: {
          50: "#f2f3f4",
          100: "#e2e4e6",
          200: "#c3c8cc",
          300: "#9aa1a7",
          400: "#707880",
          500: "#535b63",
          600: "#3f454c",
          700: "#2f343a",
          800: "#23262b",
          900: "#1b1e22",
          950: "#14161a",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "Georgia", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      boxShadow: {
        card: "0 1px 2px 0 rgb(0 0 0 / 0.04), 0 1px 6px -1px rgb(0 0 0 / 0.06)",
        floating: "0 12px 40px -12px rgb(18 80 60 / 0.25)",
      },
      keyframes: {
        "fade-in": { "0%": { opacity: "0", transform: "translateY(4px)" }, "100%": { opacity: "1", transform: "translateY(0)" } },
      },
      animation: {
        "fade-in": "fade-in 0.25s ease-out",
      },
    },
  },
  plugins: [],
};

export default config;
