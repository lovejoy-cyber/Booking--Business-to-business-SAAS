import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";

/**
 * Runs on the Edge runtime, so it can only do a lightweight signature check
 * (no Prisma/DB access here). This is a first line of defense that redirects
 * obviously-unauthenticated visitors away from /dashboard and /admin before
 * a page even renders. The authoritative check — does this user still exist,
 * are they a member of this specific business, do they have the right role —
 * happens in `requireUser` / `requireBusinessAccess` on every server
 * component and API route, which is what actually protects the data.
 */
const SESSION_COOKIE = "bookflow_session";

async function hasValidSession(req: NextRequest): Promise<boolean> {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (!token) return false;
  const secret = process.env.AUTH_SECRET;
  if (!secret) return false;
  try {
    await jwtVerify(token, new TextEncoder().encode(secret));
    return true;
  } catch {
    return false;
  }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const isProtected = pathname.startsWith("/dashboard") || pathname.startsWith("/admin");

  if (isProtected && !(await hasValidSession(req))) {
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/admin/:path*"],
};
