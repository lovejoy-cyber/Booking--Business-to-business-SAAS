import { db } from "@/lib/db";
import { Badge } from "@/components/ui/Badge";

export default async function AdminPage() {
  const [businessCount, userCount, appointmentCount, activeTrials, notificationFailures, businesses] = await Promise.all([
    db.business.count(),
    db.user.count(),
    db.appointment.count(),
    db.subscription.count({ where: { status: "TRIALING" } }),
    db.notification.count({ where: { status: "FAILED" } }),
    db.business.findMany({
      orderBy: { createdAt: "desc" },
      take: 100,
      select: {
        id: true,
        name: true,
        slug: true,
        type: true,
        isDemoMode: true,
        createdAt: true,
        members: { select: { user: { select: { name: true, email: true } }, role: true }, take: 1 },
        subscription: { select: { plan: true, status: true } },
        _count: { select: { appointments: true, customers: true } },
        whatsappConfig: { select: { isConfigured: true } },
      },
    }),
  ]);

  return (
    <div className="space-y-8">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Stat label="Businesses" value={businessCount} />
        <Stat label="Users" value={userCount} />
        <Stat label="Appointments" value={appointmentCount} />
        <Stat label="Active trials" value={activeTrials} />
        <Stat label="Notification failures" value={notificationFailures} tone={notificationFailures > 0 ? "warn" : undefined} />
      </div>

      <div className="overflow-hidden rounded-xl border border-ink-800 bg-ink-900">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-ink-800 text-xs uppercase tracking-wide text-ink-400">
              <th className="px-4 py-3 font-medium">Business</th>
              <th className="px-4 py-3 font-medium">Owner</th>
              <th className="px-4 py-3 font-medium">Plan</th>
              <th className="px-4 py-3 font-medium">Appointments</th>
              <th className="px-4 py-3 font-medium">Customers</th>
              <th className="px-4 py-3 font-medium">WhatsApp</th>
              <th className="px-4 py-3 font-medium">Created</th>
            </tr>
          </thead>
          <tbody>
            {businesses.map((b) => (
              <tr key={b.id} className="border-b border-ink-800/60 text-ink-100">
                <td className="px-4 py-3">
                  <p className="font-medium">{b.name}</p>
                  <p className="text-xs text-ink-500">/{b.slug}</p>
                </td>
                <td className="px-4 py-3 text-ink-300">{b.members[0]?.user.email ?? "—"}</td>
                <td className="px-4 py-3">
                  <Badge tone="ink">{b.subscription?.plan ?? "—"}</Badge>
                </td>
                <td className="px-4 py-3">{b._count.appointments}</td>
                <td className="px-4 py-3">{b._count.customers}</td>
                <td className="px-4 py-3">
                  {b.isDemoMode ? (
                    <Badge tone="brass">Demo</Badge>
                  ) : b.whatsappConfig?.isConfigured ? (
                    <Badge tone="pine">Live</Badge>
                  ) : (
                    <Badge tone="red">Not configured</Badge>
                  )}
                </td>
                <td className="px-4 py-3 text-ink-400">{b.createdAt.toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: number; tone?: "warn" }) {
  return (
    <div className="rounded-xl border border-ink-800 bg-ink-900 p-5">
      <p className="text-xs font-medium uppercase tracking-wide text-ink-500">{label}</p>
      <p className={`mt-2 font-display text-3xl font-semibold ${tone === "warn" && value > 0 ? "text-red-400" : "text-white"}`}>{value}</p>
    </div>
  );
}
