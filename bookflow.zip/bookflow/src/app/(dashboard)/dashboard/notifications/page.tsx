"use client";

import { useEffect, useState } from "react";
import { DeliveryStatusDot } from "@/components/ui/Ticket";
import { Badge } from "@/components/ui/Badge";

interface NotificationRow {
  id: string;
  type: string;
  status: "PENDING" | "SENT" | "DELIVERED" | "FAILED";
  recipientPhone: string;
  message: string;
  isDemo: boolean;
  errorMessage: string | null;
  scheduledFor: string;
  createdAt: string;
  appointment: { customer: { name: string } } | null;
}

const TYPE_LABELS: Record<string, string> = {
  BOOKING_CONFIRMATION: "Confirmation",
  REMINDER_24H: "Reminder (24h)",
  REMINDER_SAME_DAY: "Reminder (same day)",
  CANCELLATION: "Cancellation",
  RESCHEDULE: "Reschedule",
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<NotificationRow[]>([]);
  const [failureCount, setFailureCount] = useState(0);
  const [filter, setFilter] = useState<string>("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const qs = new URLSearchParams(filter ? { status: filter } : {});
    fetch(`/api/notifications?${qs}`)
      .then((r) => r.json())
      .then((d) => {
        setNotifications(d.notifications ?? []);
        setFailureCount(d.failureCount ?? 0);
      })
      .finally(() => setLoading(false));
  }, [filter]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink-900">Notifications</h1>
        <p className="text-sm text-ink-500">Every WhatsApp message BookFlow has queued for your customers.</p>
      </div>

      {failureCount > 0 && (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {failureCount} message{failureCount === 1 ? "" : "s"} failed to send. Check your WhatsApp configuration in Settings.
        </div>
      )}

      <div className="flex gap-2">
        {["", "PENDING", "SENT", "DELIVERED", "FAILED"].map((s) => (
          <button
            key={s || "all"}
            onClick={() => setFilter(s)}
            className={`rounded-full px-3 py-1 text-xs font-medium ${filter === s ? "bg-pine-700 text-white" : "bg-white text-ink-600 border border-ink-200"}`}
          >
            {s || "All"}
          </button>
        ))}
      </div>

      <div className="overflow-hidden rounded-xl border border-ink-100 bg-white shadow-card">
        {loading ? (
          <p className="px-5 py-6 text-sm text-ink-400">Loading…</p>
        ) : notifications.length === 0 ? (
          <p className="px-5 py-6 text-sm text-ink-400">No notifications yet.</p>
        ) : (
          <ul className="divide-y divide-ink-100">
            {notifications.map((n) => (
              <li key={n.id} className="px-5 py-3.5">
                <div className="flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Badge tone="ink">{TYPE_LABELS[n.type] ?? n.type}</Badge>
                      {n.isDemo && <Badge tone="brass">Demo</Badge>}
                    </div>
                    <p className="mt-1 truncate text-sm text-ink-700">{n.message}</p>
                    <p className="mt-0.5 text-xs text-ink-400">
                      {n.appointment?.customer.name ?? "Unknown customer"} · {n.recipientPhone}
                    </p>
                    {n.errorMessage && <p className="mt-0.5 text-xs text-red-600">{n.errorMessage}</p>}
                  </div>
                  <DeliveryStatusDot status={n.status} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
