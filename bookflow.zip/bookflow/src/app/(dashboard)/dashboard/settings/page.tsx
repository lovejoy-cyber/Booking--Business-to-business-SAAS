"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/Button";
import { Input, Label, Select, Textarea, ErrorText } from "@/components/ui/Field";
import { Badge } from "@/components/ui/Badge";
import { formatMoney } from "@/lib/format";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const TABS = ["General", "Working hours", "Staff", "WhatsApp", "Billing"] as const;

interface BusinessData {
  name: string;
  description: string | null;
  address: string | null;
  phone: string | null;
  currency: string;
  timezone: string;
  slotIntervalMinutes: number;
  minLeadTimeMinutes: number;
  maxAdvanceBookingDays: number;
  cancellationPolicy: string | null;
}

export default function SettingsPage() {
  const [tab, setTab] = useState<(typeof TABS)[number]>("General");

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl font-semibold text-ink-900">Business settings</h1>

      <div className="flex gap-1 border-b border-ink-200">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`border-b-2 px-4 py-2 text-sm font-medium ${
              tab === t ? "border-pine-700 text-pine-800" : "border-transparent text-ink-500 hover:text-ink-700"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "General" && <GeneralSettings />}
      {tab === "Working hours" && <WorkingHoursSettings />}
      {tab === "Staff" && <StaffSettings />}
      {tab === "WhatsApp" && <WhatsAppSettings />}
      {tab === "Billing" && <BillingSettings />}
    </div>
  );
}

function GeneralSettings() {
  const [data, setData] = useState<BusinessData | null>(null);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/business")
      .then((r) => r.json())
      .then((d) => setData(d.business));
  }, []);

  if (!data) return <p className="text-sm text-ink-400">Loading…</p>;

  async function onSave() {
    setError(null);
    setSaving(true);
    try {
      const res = await fetch("/api/business/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Could not save settings.");
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save settings.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-xl space-y-4 rounded-xl border border-ink-100 bg-white p-6 shadow-card">
      <div>
        <Label htmlFor="name">Business name</Label>
        <Input id="name" value={data.name} onChange={(e) => setData({ ...data, name: e.target.value })} />
      </div>
      <div>
        <Label hint="optional">Description</Label>
        <Textarea value={data.description ?? ""} onChange={(e) => setData({ ...data, description: e.target.value })} rows={2} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label hint="optional">Address</Label>
          <Input value={data.address ?? ""} onChange={(e) => setData({ ...data, address: e.target.value })} />
        </div>
        <div>
          <Label hint="optional">Phone</Label>
          <Input value={data.phone ?? ""} onChange={(e) => setData({ ...data, phone: e.target.value })} />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label htmlFor="currency">Currency</Label>
          <Input id="currency" maxLength={3} value={data.currency} onChange={(e) => setData({ ...data, currency: e.target.value.toUpperCase() })} />
        </div>
        <div>
          <Label htmlFor="timezone">Timezone (IANA)</Label>
          <Input id="timezone" value={data.timezone} onChange={(e) => setData({ ...data, timezone: e.target.value })} placeholder="America/New_York" />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-3">
        <div>
          <Label hint="minutes">Slot interval</Label>
          <Input type="number" value={data.slotIntervalMinutes} onChange={(e) => setData({ ...data, slotIntervalMinutes: Number(e.target.value) })} />
        </div>
        <div>
          <Label hint="minutes">Min. lead time</Label>
          <Input type="number" value={data.minLeadTimeMinutes} onChange={(e) => setData({ ...data, minLeadTimeMinutes: Number(e.target.value) })} />
        </div>
        <div>
          <Label hint="days">Max. advance booking</Label>
          <Input type="number" value={data.maxAdvanceBookingDays} onChange={(e) => setData({ ...data, maxAdvanceBookingDays: Number(e.target.value) })} />
        </div>
      </div>
      <div>
        <Label hint="shown on the booking page">Cancellation policy</Label>
        <Textarea
          value={data.cancellationPolicy ?? ""}
          onChange={(e) => setData({ ...data, cancellationPolicy: e.target.value })}
          rows={3}
          placeholder="Please give at least 2 hours' notice to cancel or reschedule."
        />
      </div>

      <ErrorText>{error}</ErrorText>
      <div className="flex items-center gap-3 pt-2">
        <Button onClick={onSave} loading={saving} type="button">
          Save changes
        </Button>
        {saved && <span className="text-sm text-pine-700">Saved.</span>}
      </div>
    </div>
  );
}

function WorkingHoursSettings() {
  const [hours, setHours] = useState<Record<number, { startTime: string; endTime: string; isClosed: boolean }>>({});
  const [loading, setLoading] = useState(true);
  const [savingDay, setSavingDay] = useState<number | null>(null);

  useEffect(() => {
    fetch("/api/working-hours")
      .then((r) => r.json())
      .then((d) => {
        const map: typeof hours = {};
        for (const h of d.workingHours ?? []) {
          if (h.employeeId === null) map[h.dayOfWeek] = { startTime: h.startTime, endTime: h.endTime, isClosed: h.isClosed };
        }
        setHours(map);
      })
      .finally(() => setLoading(false));
  }, []);

  async function saveDay(day: number) {
    setSavingDay(day);
    const h = hours[day];
    await fetch("/api/working-hours", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dayOfWeek: day, ...h }),
    });
    setSavingDay(null);
  }

  if (loading) return <p className="text-sm text-ink-400">Loading…</p>;

  return (
    <div className="max-w-xl space-y-3 rounded-xl border border-ink-100 bg-white p-6 shadow-card">
      {DAYS.map((label, day) => {
        const h = hours[day] ?? { startTime: "09:00", endTime: "18:00", isClosed: day === 0 };
        return (
          <div key={day} className="flex items-center gap-3 border-b border-ink-100 pb-3 last:border-0">
            <span className="w-24 text-sm font-medium text-ink-700">{label}</span>
            <label className="flex items-center gap-1.5 text-xs text-ink-500">
              <input
                type="checkbox"
                checked={!h.isClosed}
                onChange={(e) => setHours({ ...hours, [day]: { ...h, isClosed: !e.target.checked } })}
              />
              Open
            </label>
            <Input
              type="time"
              className="w-28"
              value={h.startTime}
              disabled={h.isClosed}
              onChange={(e) => setHours({ ...hours, [day]: { ...h, startTime: e.target.value } })}
            />
            <span className="text-ink-400">–</span>
            <Input
              type="time"
              className="w-28"
              value={h.endTime}
              disabled={h.isClosed}
              onChange={(e) => setHours({ ...hours, [day]: { ...h, endTime: e.target.value } })}
            />
            <Button size="sm" variant="secondary" loading={savingDay === day} onClick={() => saveDay(day)} type="button">
              Save
            </Button>
          </div>
        );
      })}
    </div>
  );
}

function StaffSettings() {
  const [employees, setEmployees] = useState<{ id: string; name: string; isActive: boolean }[]>([]);
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(true);

  function refresh() {
    fetch("/api/employees")
      .then((r) => r.json())
      .then((d) => setEmployees(d.employees ?? []))
      .finally(() => setLoading(false));
  }
  useEffect(refresh, []);

  async function add() {
    if (!name.trim()) return;
    await fetch("/api/employees", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    setName("");
    refresh();
  }

  async function toggle(id: string, isActive: boolean) {
    await fetch(`/api/employees/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !isActive }),
    });
    refresh();
  }

  return (
    <div className="max-w-xl space-y-4 rounded-xl border border-ink-100 bg-white p-6 shadow-card">
      <p className="text-sm text-ink-500">
        Add staff members if more than one person takes appointments. Leave this empty if it's just you — BookFlow treats a
        business with no staff as a single resource.
      </p>
      <div className="flex gap-2">
        <Input placeholder="Staff member name" value={name} onChange={(e) => setName(e.target.value)} />
        <Button onClick={add} type="button">
          Add
        </Button>
      </div>
      {loading ? (
        <p className="text-sm text-ink-400">Loading…</p>
      ) : (
        <ul className="divide-y divide-ink-100">
          {employees.map((e) => (
            <li key={e.id} className="flex items-center justify-between py-2.5">
              <span className="text-sm text-ink-800">{e.name}</span>
              <div className="flex items-center gap-2">
                {!e.isActive && <Badge tone="ink">Inactive</Badge>}
                <Button size="sm" variant="secondary" onClick={() => toggle(e.id, e.isActive)} type="button">
                  {e.isActive ? "Deactivate" : "Activate"}
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function WhatsAppSettings() {
  const [status, setStatus] = useState<{ isConfigured: boolean; isDemoMode: boolean; phoneNumberId: string | null } | null>(null);
  const [phoneNumberId, setPhoneNumberId] = useState("");
  const [wabaId, setWabaId] = useState("");
  const [accessToken, setAccessToken] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  function refresh() {
    fetch("/api/business/whatsapp")
      .then((r) => r.json())
      .then(setStatus);
  }
  useEffect(refresh, []);

  async function connect() {
    setError(null);
    setSaving(true);
    try {
      const res = await fetch("/api/business/whatsapp", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phoneNumberId, wabaId, accessToken }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not save WhatsApp configuration.");
      setAccessToken("");
      refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save WhatsApp configuration.");
    } finally {
      setSaving(false);
    }
  }

  async function disconnect() {
    await fetch("/api/business/whatsapp", { method: "DELETE" });
    refresh();
  }

  return (
    <div id="whatsapp" className="max-w-xl space-y-5 rounded-xl border border-ink-100 bg-white p-6 shadow-card">
      <div className="flex items-center gap-2">
        <span className={`h-2 w-2 rounded-full ${status?.isDemoMode ? "bg-brass-400" : "bg-signal-500"}`} />
        <p className="text-sm font-medium text-ink-800">{status?.isDemoMode ? "Demo mode — messages are simulated" : "Connected — sending real WhatsApp messages"}</p>
      </div>

      <p className="text-sm text-ink-500">
        Connect your WhatsApp Business Cloud API credentials from{" "}
        <a href="https://business.facebook.com" target="_blank" rel="noreferrer" className="text-pine-700 underline">
          Meta Business Manager
        </a>
        . Your access token is encrypted at rest and never shown again after saving.
      </p>

      <div className="space-y-3">
        <div>
          <Label htmlFor="pnid">Phone number ID</Label>
          <Input id="pnid" value={phoneNumberId} onChange={(e) => setPhoneNumberId(e.target.value)} placeholder={status?.phoneNumberId ?? ""} />
        </div>
        <div>
          <Label htmlFor="waba">WhatsApp Business Account ID</Label>
          <Input id="waba" value={wabaId} onChange={(e) => setWabaId(e.target.value)} />
        </div>
        <div>
          <Label htmlFor="token">Access token</Label>
          <Input id="token" type="password" value={accessToken} onChange={(e) => setAccessToken(e.target.value)} />
        </div>
      </div>

      <ErrorText>{error}</ErrorText>

      <div className="flex gap-3">
        <Button onClick={connect} loading={saving} type="button">
          {status?.isConfigured ? "Update credentials" : "Connect WhatsApp"}
        </Button>
        {status?.isConfigured && (
          <Button variant="secondary" onClick={disconnect} type="button">
            Disconnect (back to demo mode)
          </Button>
        )}
      </div>
    </div>
  );
}

interface PlanDef {
  key: string;
  name: string;
  priceCents: number;
  appointmentLimit: number;
  staffLimit: number;
}
interface BillingSummary {
  subscription: {
    plan: string;
    status: string;
    cancelAtPeriodEnd: boolean;
    currentPeriodEndsAt: string | null;
    trialEndsAt: string | null;
    stripeCustomerId: string | null;
  };
  plan: PlanDef;
  appointmentsUsed: number;
  appointmentsRemaining: number | null;
  isOverLimit: boolean;
  plans: Record<string, PlanDef>;
}

const UPGRADE_PLANS = ["STARTER", "PROFESSIONAL", "BUSINESS"] as const;

function BillingSettings() {
  const [summary, setSummary] = useState<BillingSummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);
  const [portalLoading, setPortalLoading] = useState(false);

  function refresh() {
    fetch("/api/billing")
      .then((r) => r.json())
      .then(setSummary);
  }
  useEffect(refresh, []);

  async function upgrade(plan: (typeof UPGRADE_PLANS)[number]) {
    setError(null);
    setLoadingPlan(plan);
    try {
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not start checkout.");
      window.location.href = data.url;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not start checkout.");
      setLoadingPlan(null);
    }
  }

  async function openPortal() {
    setError(null);
    setPortalLoading(true);
    try {
      const res = await fetch("/api/billing/portal", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not open the billing portal.");
      window.location.href = data.url;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not open the billing portal.");
      setPortalLoading(false);
    }
  }

  if (!summary) return <p className="text-sm text-ink-400">Loading…</p>;

  const { subscription, plan, appointmentsUsed, appointmentsRemaining, isOverLimit } = summary;

  return (
    <div className="max-w-xl space-y-6">
      <div className="rounded-xl border border-ink-100 bg-white p-6 shadow-card">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Current plan</p>
            <p className="mt-1 font-display text-2xl font-semibold text-ink-900">{plan.name}</p>
          </div>
          <Badge tone={subscription.status === "ACTIVE" || subscription.status === "TRIALING" ? "pine" : "red"}>
            {subscription.status.replace("_", " ")}
          </Badge>
        </div>

        <div className="mt-4 space-y-1 text-sm text-ink-600">
          <p>
            {appointmentsUsed} appointment{appointmentsUsed === 1 ? "" : "s"} used this period
            {appointmentsRemaining !== null && ` · ${appointmentsRemaining} remaining`}
          </p>
          {subscription.trialEndsAt && subscription.status === "TRIALING" && (
            <p>Trial ends {new Date(subscription.trialEndsAt).toLocaleDateString()}</p>
          )}
          {subscription.cancelAtPeriodEnd && subscription.currentPeriodEndsAt && (
            <p className="text-brass-700">Cancels on {new Date(subscription.currentPeriodEndsAt).toLocaleDateString()}</p>
          )}
        </div>

        {isOverLimit && (
          <div className="mt-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
            You've reached this period's appointment limit — new bookings are paused until you upgrade or the period resets.
          </div>
        )}

        {subscription.stripeCustomerId && (
          <Button variant="secondary" size="sm" className="mt-4" onClick={openPortal} loading={portalLoading} type="button">
            Manage billing & invoices
          </Button>
        )}
      </div>

      <div>
        <p className="mb-3 text-sm font-medium text-ink-700">Upgrade plan</p>
        <div className="grid gap-3 sm:grid-cols-3">
          {UPGRADE_PLANS.map((key) => {
            const p = summary.plans[key];
            const current = subscription.plan === key;
            return (
              <div key={key} className="rounded-xl border border-ink-200 bg-white p-4">
                <p className="font-display text-lg font-semibold text-ink-900">{p.name}</p>
                <p className="mt-1 font-mono text-xl text-ink-800">{formatMoney(p.priceCents)}<span className="text-sm text-ink-400">/mo</span></p>
                <p className="mt-1 text-xs text-ink-500">
                  {p.appointmentLimit === -1 ? "Unlimited" : p.appointmentLimit} appointments · {p.staffLimit === -1 ? "Unlimited" : p.staffLimit} staff
                </p>
                <Button
                  className="mt-3 w-full"
                  size="sm"
                  variant={current ? "secondary" : "primary"}
                  disabled={current}
                  loading={loadingPlan === key}
                  onClick={() => upgrade(key)}
                  type="button"
                >
                  {current ? "Current plan" : "Upgrade"}
                </Button>
              </div>
            );
          })}
        </div>
      </div>

      <ErrorText>{error}</ErrorText>
    </div>
  );
}
