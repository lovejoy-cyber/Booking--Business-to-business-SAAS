import Link from "next/link";
import { requireCurrentBusiness } from "@/lib/tenant";
import { db } from "@/lib/db";
import { startOfDay, endOfDay, addDays } from "date-fns";
import { zonedTimeToUtc } from "date-fns-tz";
import { Card, CardBody } from "@/components/ui/Card";
import { Badge, statusTone } from "@/components/ui/Badge";
import { QuickActions } from "@/components/dashboard/QuickActions";
import { formatMoney, formatInTz } from "@/lib/format";

export default async function DashboardOverviewPage() {
  const { business } = await requireCurrentBusiness();

  const now = new Date();
  // "Today" is defined in the business's own timezone, not the server's.
  const todayStartLocal = formatInTz(now, business.timezone, "yyyy-MM-dd") + "T00:00:00";
  const todayStart = zonedTimeToUtc(todayStartLocal, business.timezone);
  const todayEnd = addDays(todayStart, 1);

  const [todayAppointments, upcoming, customerCount, last30dAppointments] = await Promise.all([
    db.appointment.findMany({
      where: { businessId: business.id, startsAt: { gte: todayStart, lt: todayEnd } },
      include: { customer: true, service: true },
      orderBy: { startsAt: "asc" },
    }),
    db.appointment.findMany({
      where: { businessId: business.id, startsAt: { gte: todayEnd }, status: { in: ["PENDING", "CONFIRMED"] } },
      include: { customer: true, service: true },
      orderBy: { startsAt: "asc" },
      take: 5,
    }),
    db.customer.count({ where: { businessId: business.id } }),
    db.appointment.findMany({
      where: { businessId: business.id, startsAt: { gte: addDays(now, -30) }, status: { in: ["COMPLETED", "NO_SHOW"] } },
      select: { status: true },
    }),
  ]);

  const confirmed = todayAppointments.filter((a) => a.status === "CONFIRMED").length;
  const pending = todayAppointments.filter((a) => a.status === "PENDING").length;
  const cancelled = todayAppointments.filter((a) => a.status === "CANCELLED").length;
  const noShowToday = todayAppointments.filter((a) => a.status === "NO_SHOW").length;
  const revenueCents = todayAppointments
    .filter((a) => a.status === "CONFIRMED" || a.status === "COMPLETED")
    .reduce((sum, a) => sum + a.priceCents, 0);

  const noShowRate =
    last30dAppointments.length === 0
      ? 0
      : (last30dAppointments.filter((a) => a.status === "NO_SHOW").length / last30dAppointments.length) * 100;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink-900">Overview</h1>
        <p className="text-sm text-ink-500">{formatInTz(now, business.timezone, "EEEE, d MMMM yyyy")}</p>
      </div>

      <QuickActions bookingSlug={business.slug} />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Today's appointments" value={String(todayAppointments.length)} sub={`${confirmed} confirmed · ${pending} pending`} />
        <StatCard label="Estimated revenue" value={formatMoney(revenueCents, business.currency)} sub="from today's appointments" />
        <StatCard label="Customers" value={String(customerCount)} sub="on file" />
        <StatCard label="No-show rate" value={`${noShowRate.toFixed(1)}%`} sub="last 30 days" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardBody>
            <h2 className="font-display text-lg font-semibold text-ink-900">Today</h2>
            {todayAppointments.length === 0 ? (
              <p className="mt-3 text-sm text-ink-400">No appointments today.</p>
            ) : (
              <ul className="mt-3 divide-y divide-ink-100">
                {todayAppointments.map((a) => (
                  <li key={a.id} className="flex items-center justify-between py-2.5 text-sm">
                    <div>
                      <p className="font-medium text-ink-800">{a.customer.name}</p>
                      <p className="text-ink-500">
                        {formatInTz(a.startsAt, business.timezone, "HH:mm")} · {a.service.name}
                      </p>
                    </div>
                    <Badge tone={statusTone(a.status)}>{a.status.replace("_", "-")}</Badge>
                  </li>
                ))}
              </ul>
            )}
            {(cancelled > 0 || noShowToday > 0) && (
              <p className="mt-3 text-xs text-ink-400">
                {cancelled} cancelled · {noShowToday} no-show
              </p>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardBody>
            <h2 className="font-display text-lg font-semibold text-ink-900">Upcoming</h2>
            {upcoming.length === 0 ? (
              <p className="mt-3 text-sm text-ink-400">Nothing scheduled after today yet.</p>
            ) : (
              <ul className="mt-3 divide-y divide-ink-100">
                {upcoming.map((a) => (
                  <li key={a.id} className="flex items-center justify-between py-2.5 text-sm">
                    <div>
                      <p className="font-medium text-ink-800">{a.customer.name}</p>
                      <p className="text-ink-500">
                        {formatInTz(a.startsAt, business.timezone, "EEE d MMM, HH:mm")} · {a.service.name}
                      </p>
                    </div>
                    <Badge tone={statusTone(a.status)}>{a.status}</Badge>
                  </li>
                ))}
              </ul>
            )}
            <Link href="/dashboard/calendar" className="mt-3 inline-block text-sm font-medium text-pine-700 hover:underline">
              View full calendar →
            </Link>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="rounded-xl border border-ink-100 bg-white p-5 shadow-card">
      <p className="text-xs font-medium uppercase tracking-wide text-ink-400">{label}</p>
      <p className="mt-2 font-display text-3xl font-semibold text-ink-900">{value}</p>
      <p className="mt-1 text-xs text-ink-500">{sub}</p>
    </div>
  );
}
