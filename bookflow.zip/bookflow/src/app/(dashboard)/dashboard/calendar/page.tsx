"use client";

import { useEffect, useMemo, useState } from "react";
import { addDays, startOfWeek, format } from "date-fns";
import { Button } from "@/components/ui/Button";
import { Badge, statusTone } from "@/components/ui/Badge";
import { NewAppointmentModal } from "@/components/dashboard/NewAppointmentModal";
import { AppointmentDetailModal, type AppointmentSummary } from "@/components/dashboard/AppointmentDetailModal";
import { formatInTz } from "@/lib/format";

function toDateParam(d: Date) {
  return format(d, "yyyy-MM-dd");
}

export default function CalendarPage() {
  const [view, setView] = useState<"day" | "week">("day");
  const [anchor, setAnchor] = useState(new Date());
  const [appointments, setAppointments] = useState<AppointmentSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [selected, setSelected] = useState<AppointmentSummary | null>(null);
  const [meta, setMeta] = useState<{ timezone: string; currency: string }>({ timezone: "UTC", currency: "USD" });

  const rangeStart = useMemo(() => (view === "day" ? anchor : startOfWeek(anchor, { weekStartsOn: 1 })), [anchor, view]);
  const rangeEnd = useMemo(() => addDays(rangeStart, view === "day" ? 1 : 7), [rangeStart, view]);

  useEffect(() => {
    fetch("/api/business")
      .then((r) => r.json())
      .then((d) => d.business && setMeta({ timezone: d.business.timezone, currency: d.business.currency }));
  }, []);

  useEffect(() => {
    setLoading(true);
    const qs = new URLSearchParams({ from: rangeStart.toISOString(), to: rangeEnd.toISOString() });
    fetch(`/api/appointments?${qs}`)
      .then((r) => r.json())
      .then((d) => setAppointments(d.appointments ?? []))
      .finally(() => setLoading(false));
  }, [rangeStart, rangeEnd, showNew, selected]);

  const days = view === "day" ? [rangeStart] : Array.from({ length: 7 }, (_, i) => addDays(rangeStart, i));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink-900">Calendar</h1>
          <p className="text-sm text-ink-500">{formatInTz(rangeStart, meta.timezone, view === "day" ? "EEEE, d MMMM" : "'Week of' d MMMM")}</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-lg border border-ink-200 bg-white p-0.5">
            <button
              onClick={() => setView("day")}
              className={`rounded-md px-3 py-1.5 text-sm font-medium ${view === "day" ? "bg-pine-700 text-white" : "text-ink-600"}`}
            >
              Day
            </button>
            <button
              onClick={() => setView("week")}
              className={`rounded-md px-3 py-1.5 text-sm font-medium ${view === "week" ? "bg-pine-700 text-white" : "text-ink-600"}`}
            >
              Week
            </button>
          </div>
          <Button variant="secondary" size="sm" onClick={() => setAnchor(addDays(anchor, view === "day" ? -1 : -7))}>
            ←
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setAnchor(new Date())}>
            Today
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setAnchor(addDays(anchor, view === "day" ? 1 : 7))}>
            →
          </Button>
          <Button size="sm" onClick={() => setShowNew(true)}>
            New appointment
          </Button>
        </div>
      </div>

      {loading ? (
        <p className="text-sm text-ink-400">Loading appointments…</p>
      ) : (
        <div className={`grid gap-4 ${view === "week" ? "lg:grid-cols-7" : "grid-cols-1"}`}>
          {days.map((day) => {
            const dayStr = toDateParam(day);
            const dayAppointments = appointments
              .filter((a) => formatInTz(a.startsAt, meta.timezone, "yyyy-MM-dd") === dayStr)
              .sort((a, b) => a.startsAt.localeCompare(b.startsAt));

            return (
              <div key={dayStr} className="rounded-xl border border-ink-100 bg-white p-4 shadow-card">
                {view === "week" && (
                  <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-ink-400">
                    {formatInTz(day, meta.timezone, "EEE d MMM")}
                  </p>
                )}
                {dayAppointments.length === 0 ? (
                  <p className="text-sm text-ink-300">No appointments</p>
                ) : (
                  <ul className="space-y-2">
                    {dayAppointments.map((a) => (
                      <li key={a.id}>
                        <button
                          onClick={() => setSelected(a)}
                          className="w-full rounded-lg border border-ink-100 bg-paper-50 px-3 py-2 text-left hover:border-pine-300"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-xs text-ink-500">{formatInTz(a.startsAt, meta.timezone, "HH:mm")}</span>
                            <Badge tone={statusTone(a.status)}>{a.status.replace("_", "-")}</Badge>
                          </div>
                          <p className="mt-1 text-sm font-medium text-ink-800">{a.customer.name}</p>
                          <p className="text-xs text-ink-500">
                            {a.service.name}
                            {a.employee ? ` · ${a.employee.name}` : ""}
                          </p>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            );
          })}
        </div>
      )}

      <NewAppointmentModal open={showNew} onClose={() => setShowNew(false)} defaultDate={toDateParam(anchor)} />
      <AppointmentDetailModal appointment={selected} timezone={meta.timezone} currency={meta.currency} onClose={() => setSelected(null)} />
    </div>
  );
}
