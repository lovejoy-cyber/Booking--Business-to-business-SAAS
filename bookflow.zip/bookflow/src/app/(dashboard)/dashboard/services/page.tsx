"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { Input, Label, ErrorText, Textarea } from "@/components/ui/Field";
import { Badge } from "@/components/ui/Badge";
import { formatMoney, formatDuration } from "@/lib/format";

interface Service {
  id: string;
  name: string;
  description: string | null;
  priceCents: number;
  durationMinutes: number;
  isActive: boolean;
}

const emptyForm = { name: "", description: "", price: "", duration: "30" };

export default function ServicesPage() {
  const router = useRouter();
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Service | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  function refresh() {
    setLoading(true);
    fetch("/api/services")
      .then((r) => r.json())
      .then((d) => setServices(d.services ?? []))
      .finally(() => setLoading(false));
  }

  useEffect(refresh, []);

  function openNew() {
    setEditing(null);
    setForm(emptyForm);
    setError(null);
    setShowForm(true);
  }

  function openEdit(s: Service) {
    setEditing(s);
    setForm({
      name: s.name,
      description: s.description ?? "",
      price: (s.priceCents / 100).toString(),
      duration: s.durationMinutes.toString(),
    });
    setError(null);
    setShowForm(true);
  }

  async function onSave() {
    setError(null);
    const priceCents = Math.round(parseFloat(form.price) * 100);
    const durationMinutes = parseInt(form.duration, 10);

    if (!form.name.trim()) return setError("Give the service a name.");
    if (!Number.isFinite(priceCents) || priceCents < 0) return setError("Enter a valid price.");
    if (!Number.isFinite(durationMinutes) || durationMinutes < 5) return setError("Duration must be at least 5 minutes.");

    setSaving(true);
    try {
      const payload = { name: form.name, description: form.description || null, priceCents, durationMinutes };
      const res = await fetch(editing ? `/api/services/${editing.id}` : "/api/services", {
        method: editing ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not save the service.");
      setShowForm(false);
      refresh();
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save the service.");
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive(s: Service) {
    if (s.isActive) {
      await fetch(`/api/services/${s.id}`, { method: "DELETE" });
    } else {
      await fetch(`/api/services/${s.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: true }),
      });
    }
    refresh();
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink-900">Services</h1>
          <p className="text-sm text-ink-500">These appear on your public booking page in this order.</p>
        </div>
        <Button size="sm" onClick={openNew}>
          Add service
        </Button>
      </div>

      <div className="overflow-hidden rounded-xl border border-ink-100 bg-white shadow-card">
        {loading ? (
          <p className="px-5 py-6 text-sm text-ink-400">Loading…</p>
        ) : services.length === 0 ? (
          <p className="px-5 py-6 text-sm text-ink-400">No services yet. Add your first one to start taking bookings.</p>
        ) : (
          <ul className="divide-y divide-ink-100">
            {services.map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-4 px-5 py-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-ink-900">{s.name}</p>
                    {!s.isActive && <Badge tone="ink">Inactive</Badge>}
                  </div>
                  {s.description && <p className="mt-0.5 truncate text-sm text-ink-500">{s.description}</p>}
                  <p className="mt-1 text-sm text-ink-600">
                    {formatMoney(s.priceCents)} · {formatDuration(s.durationMinutes)}
                  </p>
                </div>
                <div className="flex shrink-0 gap-2">
                  <Button variant="secondary" size="sm" onClick={() => openEdit(s)}>
                    Edit
                  </Button>
                  <Button variant={s.isActive ? "danger" : "secondary"} size="sm" onClick={() => toggleActive(s)}>
                    {s.isActive ? "Deactivate" : "Activate"}
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/50 px-4" role="dialog" aria-modal>
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-floating">
            <h2 className="mb-5 font-display text-xl font-semibold text-ink-900">{editing ? "Edit service" : "Add service"}</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="svc-name">Name</Label>
                <Input id="svc-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Haircut" />
              </div>
              <div>
                <Label hint="optional">Description</Label>
                <Textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  rows={2}
                  placeholder="Classic scissor cut and finish."
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="svc-price">Price</Label>
                  <Input id="svc-price" type="number" min="0" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="10.00" />
                </div>
                <div>
                  <Label htmlFor="svc-duration">Duration (min)</Label>
                  <Input id="svc-duration" type="number" min="5" step="5" value={form.duration} onChange={(e) => setForm({ ...form, duration: e.target.value })} />
                </div>
              </div>
              <ErrorText>{error}</ErrorText>
              <div className="flex justify-end gap-3 pt-2">
                <Button variant="secondary" onClick={() => setShowForm(false)} type="button">
                  Cancel
                </Button>
                <Button onClick={onSave} loading={saving} type="button">
                  {editing ? "Save changes" : "Add service"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
