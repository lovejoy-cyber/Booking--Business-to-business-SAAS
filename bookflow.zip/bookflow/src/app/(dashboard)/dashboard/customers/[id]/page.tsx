import Link from "next/link";
import { notFound } from "next/navigation";
import { requireCurrentBusiness } from "@/lib/tenant";
import { db } from "@/lib/db";
import { Card, CardBody } from "@/components/ui/Card";
import { Badge, statusTone } from "@/components/ui/Badge";
import { formatMoney, formatInTz, initials } from "@/lib/format";

export default async function CustomerDetailPage({ params }: { params: { id: string } }) {
  const { business } = await requireCurrentBusiness();

  const customer = await db.customer.findFirst({
    where: { id: params.id, businessId: business.id },
    include: {
      appointments: {
        orderBy: { startsAt: "desc" },
        include: { service: true, employee: true },
      },
    },
  });
  if (!customer) notFound();

  const completed = customer.appointments.filter((a) => a.status === "COMPLETED");
  const cancelled = customer.appointments.filter((a) => a.status === "CANCELLED");
  const noShows = customer.appointments.filter((a) => a.status === "NO_SHOW");
  const estimatedValueCents = completed.reduce((sum, a) => sum + a.priceCents, 0);

  return (
    <div className="space-y-6">
      <Link href="/dashboard/customers" className="text-sm font-medium text-ink-500 hover:text-ink-700">
        ← All customers
      </Link>

      <div className="flex items-center gap-4">
        <span className="flex h-14 w-14 items-center justify-center rounded-full bg-pine-100 text-lg font-semibold text-pine-800">
          {initials(customer.name)}
        </span>
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink-900">{customer.name}</h1>
          <p className="text-sm text-ink-500">{customer.whatsappE164}</p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Total appointments" value={String(customer.appointments.length)} />
        <Stat label="Completed" value={String(completed.length)} />
        <Stat label="Cancelled / no-show" value={`${cancelled.length} / ${noShows.length}`} />
        <Stat label="Estimated value" value={formatMoney(estimatedValueCents, business.currency)} />
      </div>

      {customer.notes && (
        <Card>
          <CardBody>
            <h2 className="mb-1 font-display text-lg font-semibold text-ink-900">Notes</h2>
            <p className="whitespace-pre-wrap text-sm text-ink-600">{customer.notes}</p>
          </CardBody>
        </Card>
      )}

      <Card>
        <CardBody>
          <h2 className="mb-3 font-display text-lg font-semibold text-ink-900">Appointment history</h2>
          {customer.appointments.length === 0 ? (
            <p className="text-sm text-ink-400">No appointments yet.</p>
          ) : (
            <ul className="divide-y divide-ink-100">
              {customer.appointments.map((a) => (
                <li key={a.id} className="flex items-center justify-between py-3 text-sm">
                  <div>
                    <p className="font-medium text-ink-800">{a.service.name}</p>
                    <p className="text-ink-500">
                      {formatInTz(a.startsAt, business.timezone, "EEE d MMM yyyy, HH:mm")}
                      {a.employee ? ` · ${a.employee.name}` : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs text-ink-400">{formatMoney(a.priceCents, business.currency)}</span>
                    <Badge tone={statusTone(a.status)}>{a.status.replace("_", "-")}</Badge>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-ink-100 bg-white p-5 shadow-card">
      <p className="text-xs font-medium uppercase tracking-wide text-ink-400">{label}</p>
      <p className="mt-2 font-display text-2xl font-semibold text-ink-900">{value}</p>
    </div>
  );
}
