"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Input } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";
import { NewCustomerModal } from "@/components/dashboard/NewCustomerModal";
import { initials } from "@/lib/format";

interface CustomerRow {
  id: string;
  name: string;
  whatsappE164: string;
  createdAt: string;
  _count: { appointments: number };
}

export default function CustomersPage() {
  const [q, setQ] = useState("");
  const [customers, setCustomers] = useState<CustomerRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);

  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => {
      const qs = new URLSearchParams(q ? { q } : {});
      fetch(`/api/customers?${qs}`)
        .then((r) => r.json())
        .then((d) => setCustomers(d.customers ?? []))
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(t);
  }, [q, showNew]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-2xl font-semibold text-ink-900">Customers</h1>
        <Button size="sm" onClick={() => setShowNew(true)}>
          Add customer
        </Button>
      </div>

      <Input placeholder="Search by name or phone…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-sm" />

      <div className="overflow-hidden rounded-xl border border-ink-100 bg-white shadow-card">
        {loading ? (
          <p className="px-5 py-6 text-sm text-ink-400">Loading…</p>
        ) : customers.length === 0 ? (
          <p className="px-5 py-6 text-sm text-ink-400">No customers yet. They'll appear here after their first booking.</p>
        ) : (
          <ul className="divide-y divide-ink-100">
            {customers.map((c) => (
              <li key={c.id}>
                <Link href={`/dashboard/customers/${c.id}`} className="flex items-center gap-4 px-5 py-3.5 hover:bg-paper-50">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-pine-100 text-sm font-semibold text-pine-800">
                    {initials(c.name)}
                  </span>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-ink-900">{c.name}</p>
                    <p className="text-xs text-ink-500">{c.whatsappE164}</p>
                  </div>
                  <p className="text-xs text-ink-400">{c._count.appointments} appointment{c._count.appointments === 1 ? "" : "s"}</p>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>

      <NewCustomerModal open={showNew} onClose={() => setShowNew(false)} />
    </div>
  );
}
