import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";
import { db } from "@/lib/db";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { DemoModeBanner } from "@/components/dashboard/DemoModeBanner";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const membership = await db.businessMember.findFirst({
    where: { userId: user.id },
    include: { business: true },
  });
  if (!membership) redirect("/register");

  return (
    <div className="flex h-screen bg-paper-100">
      <Sidebar businessName={membership.business.name} bookingSlug={membership.business.slug} />
      <div className="flex-1 overflow-y-auto">
        {membership.business.isDemoMode && <DemoModeBanner />}
        <div className="mx-auto max-w-6xl px-6 py-8">{children}</div>
      </div>
    </div>
  );
}
