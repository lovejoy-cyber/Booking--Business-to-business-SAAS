import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { workingHourSchema } from "@/lib/validation";
import { AppError, handleApiError } from "@/lib/errors";
import { writeAuditLog } from "@/lib/audit";

export async function GET() {
  try {
    const { business } = await requireCurrentBusiness();
    const hours = await db.workingHour.findMany({
      where: { businessId: business.id },
      orderBy: [{ employeeId: "asc" }, { dayOfWeek: "asc" }],
    });
    return NextResponse.json({ workingHours: hours });
  } catch (err) {
    return handleApiError(err);
  }
}

// Upserts one day's hours (business default when employeeId is omitted).
export async function PUT(req: NextRequest) {
  try {
    const { user, business } = await requireCurrentBusiness("MANAGER");
    const input = workingHourSchema.parse(await req.json());

    if (input.employeeId) {
      const employee = await db.employee.findFirst({ where: { id: input.employeeId, businessId: business.id } });
      if (!employee) throw AppError.notFound("Employee not found.");
    }

    if (input.startTime >= input.endTime && !input.isClosed) {
      throw AppError.badRequest("Start time must be before end time.");
    }

    const existing = await db.workingHour.findFirst({
      where: { businessId: business.id, employeeId: input.employeeId ?? null, dayOfWeek: input.dayOfWeek },
    });

    const hour = existing
      ? await db.workingHour.update({ where: { id: existing.id }, data: input })
      : await db.workingHour.create({ data: { ...input, businessId: business.id } });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "working_hours.update",
      entityType: "WorkingHour",
      entityId: hour.id,
    });

    return NextResponse.json({ workingHour: hour });
  } catch (err) {
    return handleApiError(err);
  }
}
