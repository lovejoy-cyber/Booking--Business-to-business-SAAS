import { NextRequest, NextResponse } from "next/server";
import { verifyWebhookChallenge, verifyWebhookSignature } from "@/lib/whatsapp/client";
import { markDeliveredByProviderId } from "@/lib/whatsapp/service";

/**
 * Meta calls GET once, at setup time, to verify you control this URL.
 * WHATSAPP_WEBHOOK_VERIFY_TOKEN must match the value you enter in the
 * Meta Business Manager webhook configuration screen.
 */
export async function GET(req: NextRequest) {
  const mode = req.nextUrl.searchParams.get("hub.mode");
  const token = req.nextUrl.searchParams.get("hub.verify_token");
  const challenge = req.nextUrl.searchParams.get("hub.challenge");

  const expected = process.env.WHATSAPP_WEBHOOK_VERIFY_TOKEN ?? "";
  if (verifyWebhookChallenge(mode, token, expected)) {
    return new NextResponse(challenge ?? "", { status: 200 });
  }
  return new NextResponse("Forbidden", { status: 403 });
}

/**
 * Delivery-status callbacks ("sent" -> "delivered" -> "read") arrive here.
 * We only act on "delivered" to flip our own DELIVERED status; every other
 * event type is acknowledged (200) and ignored, which is what Meta expects.
 *
 * The request signature is verified against the Meta App Secret before any
 * of the payload is trusted — this is the only thing standing between this
 * public endpoint and a forged "delivered" status from an attacker.
 */
export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get("x-hub-signature-256");
  const appSecret = process.env.WHATSAPP_APP_SECRET;

  if (appSecret) {
    const valid = await verifyWebhookSignature(rawBody, signature, appSecret);
    if (!valid) return new NextResponse("Invalid signature", { status: 401 });
  }

  try {
    const payload = JSON.parse(rawBody);
    const statuses =
      payload?.entry?.flatMap((e: any) => e?.changes?.flatMap((c: any) => c?.value?.statuses ?? []) ?? []) ?? [];

    for (const status of statuses) {
      if (status?.status === "delivered" && status?.id) {
        await markDeliveredByProviderId(status.id);
      }
    }
  } catch (err) {
    console.error("[whatsapp_webhook_parse_error]", err);
    // Still acknowledge — Meta will retry on non-2xx, which we don't want for a malformed payload we can't parse anyway.
  }

  return NextResponse.json({ received: true });
}
