import { NextRequest, NextResponse } from "next/server";
import { getStripe } from "@/lib/billing/stripe";
import { syncSubscriptionFromStripe, markSubscriptionCancelled } from "@/lib/billing/subscription";
import { db } from "@/lib/db";
import { writeAuditLog } from "@/lib/audit";
import type Stripe from "stripe";

/**
 * Stripe requires the exact raw request body (before any JSON parsing) to
 * verify `Stripe-Signature` — this is why this route reads `req.text()`
 * rather than `req.json()`, and why it must run on the Node runtime, not
 * the Edge runtime (Stripe's SDK needs Node's crypto).
 */
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get("stripe-signature");
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!signature || !webhookSecret) {
    return new NextResponse("Webhook not configured", { status: 400 });
  }

  let event: Stripe.Event;
  try {
    event = getStripe().webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch (err) {
    console.error("[stripe_webhook_signature_invalid]", err);
    return new NextResponse("Invalid signature", { status: 400 });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const businessId = session.client_reference_id ?? session.metadata?.businessId;
        if (businessId && session.subscription) {
          const stripeSub = await getStripe().subscriptions.retrieve(session.subscription as string);
          await syncSubscriptionFromStripe(businessId, stripeSub);
          await writeAuditLog({ businessId, action: "billing.subscription_started", metadata: { plan: session.metadata?.plan } });
        }
        break;
      }

      case "customer.subscription.updated": {
        const stripeSub = event.data.object as Stripe.Subscription;
        const businessId = stripeSub.metadata?.businessId ?? (await findBusinessIdByCustomer(stripeSub.customer));
        if (businessId) {
          await syncSubscriptionFromStripe(businessId, stripeSub);
          await writeAuditLog({ businessId, action: "billing.subscription_updated", metadata: { status: stripeSub.status } });
        }
        break;
      }

      case "customer.subscription.deleted": {
        const stripeSub = event.data.object as Stripe.Subscription;
        const businessId = stripeSub.metadata?.businessId ?? (await findBusinessIdByCustomer(stripeSub.customer));
        if (businessId) {
          await markSubscriptionCancelled(businessId);
          await writeAuditLog({ businessId, action: "billing.subscription_cancelled" });
        }
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        const businessId = await findBusinessIdByCustomer(invoice.customer);
        if (businessId) {
          await db.subscription.update({ where: { businessId }, data: { status: "PAST_DUE" } }).catch(() => {});
          await writeAuditLog({ businessId, action: "billing.payment_failed" });
        }
        break;
      }

      default:
        // Unhandled event types are acknowledged, not treated as errors.
        break;
    }
  } catch (err) {
    // Log and still return 200 where possible is tempting, but a processing
    // failure should make Stripe retry — return 500 so it does.
    console.error("[stripe_webhook_processing_error]", event.type, err);
    return new NextResponse("Webhook handler error", { status: 500 });
  }

  return NextResponse.json({ received: true });
}

async function findBusinessIdByCustomer(customer: string | Stripe.Customer | Stripe.DeletedCustomer | null): Promise<string | null> {
  const customerId = typeof customer === "string" ? customer : customer?.id;
  if (!customerId) return null;
  const subscription = await db.subscription.findFirst({ where: { stripeCustomerId: customerId } });
  return subscription?.businessId ?? null;
}
