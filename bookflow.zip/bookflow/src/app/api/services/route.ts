import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { serviceSchema } from "@/lib/validation";
import { handleApiError } from "@/lib/errors";
import { writeAuditLog } from "@/lib/audit";

export async function GET() {
  try {
    const { business } = await requireCurrentBusiness();
    const services = await db.service.findMany({
      where: { businessId: business.id },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    });
    return NextResponse.json({ services });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const { user, business, role } = await requireCurrentBusiness("MANAGER");
    const input = serviceSchema.parse(await req.json());

    const service = await db.service.create({
      data: { ...input, businessId: business.id },
    });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "service.create",
      entityType: "Service",
      entityId: service.id,
    });

    return NextResponse.json({ service }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
