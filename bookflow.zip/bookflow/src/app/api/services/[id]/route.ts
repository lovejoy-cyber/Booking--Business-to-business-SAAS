import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { serviceSchema } from "@/lib/validation";
import { AppError, handleApiError } from "@/lib/errors";
import { writeAuditLog } from "@/lib/audit";

async function loadOwnedService(businessId: string, id: string) {
  const service = await db.service.findFirst({ where: { id, businessId } });
  if (!service) throw AppError.notFound("Service not found.");
  return service;
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user, business } = await requireCurrentBusiness("MANAGER");
    await loadOwnedService(business.id, params.id);
    const input = serviceSchema.partial().parse(await req.json());

    const service = await db.service.update({ where: { id: params.id }, data: input });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "service.update",
      entityType: "Service",
      entityId: params.id,
    });

    return NextResponse.json({ service });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user, business } = await requireCurrentBusiness("MANAGER");
    await loadOwnedService(business.id, params.id);

    // Soft-delete via isActive rather than a hard delete, so historical
    // appointments that reference this service keep valid data.
    const service = await db.service.update({ where: { id: params.id }, data: { isActive: false } });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "service.deactivate",
      entityType: "Service",
      entityId: params.id,
    });

    return NextResponse.json({ service });
  } catch (err) {
    return handleApiError(err);
  }
}
