import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword, createSessionToken, setSessionCookie } from "@/lib/auth";
import { registerSchema } from "@/lib/validation";
import { AppError, handleApiError } from "@/lib/errors";
import { checkRateLimit } from "@/lib/rateLimit";
import { clientIp, writeAuditLog } from "@/lib/audit";
import { PLANS } from "@/lib/billing/plans";

function slugify(name: string): string {
  return (
    name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)+/g, "") || "business"
  );
}

const DEFAULT_HOURS = [
  { dayOfWeek: 0, isClosed: true, startTime: "09:00", endTime: "18:00" }, // Sunday
  { dayOfWeek: 1, isClosed: false, startTime: "09:00", endTime: "18:00" },
  { dayOfWeek: 2, isClosed: false, startTime: "09:00", endTime: "18:00" },
  { dayOfWeek: 3, isClosed: false, startTime: "09:00", endTime: "18:00" },
  { dayOfWeek: 4, isClosed: false, startTime: "09:00", endTime: "18:00" },
  { dayOfWeek: 5, isClosed: false, startTime: "09:00", endTime: "18:00" },
  { dayOfWeek: 6, isClosed: false, startTime: "09:00", endTime: "14:00" },
];

export async function POST(req: NextRequest) {
  try {
    const ip = clientIp(req.headers) ?? "unknown";
    checkRateLimit(`register:${ip}`, 5, 15 * 60 * 1000);

    const body = await req.json();
    const input = registerSchema.parse(body);

    const existing = await db.user.findUnique({ where: { email: input.email.toLowerCase() } });
    if (existing) {
      throw AppError.conflict("An account with that email already exists.");
    }

    const passwordHash = await hashPassword(input.password);

    // Ensure a unique slug for the public booking URL.
    const base = slugify(input.businessName);
    let slug = base;
    let n = 1;
    while (await db.business.findUnique({ where: { slug } })) {
      slug = `${base}-${++n}`;
    }

    const result = await db.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: { name: input.name, email: input.email.toLowerCase(), passwordHash },
      });

      const business = await tx.business.create({
        data: {
          name: input.businessName,
          slug,
          type: input.businessType,
          isDemoMode: true,
        },
      });

      await tx.businessMember.create({
        data: { businessId: business.id, userId: user.id, role: "OWNER" },
      });

      await tx.workingHour.createMany({
        data: DEFAULT_HOURS.map((h) => ({ ...h, businessId: business.id, employeeId: null })),
      });

      await tx.whatsAppConfiguration.create({
        data: { businessId: business.id, isConfigured: false },
      });

      await tx.subscription.create({
        data: {
          businessId: business.id,
          plan: "FREE_TRIAL",
          status: "TRIALING",
          appointmentLimit: PLANS.FREE_TRIAL.appointmentLimit,
          staffLimit: PLANS.FREE_TRIAL.staffLimit,
          trialEndsAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
        },
      });

      return { user, business };
    });

    const token = await createSessionToken({ userId: result.user.id });
    await setSessionCookie(token);

    await writeAuditLog({
      businessId: result.business.id,
      userId: result.user.id,
      action: "auth.register",
      ipAddress: ip,
    });

    return NextResponse.json({
      user: { id: result.user.id, name: result.user.name, email: result.user.email },
      business: { id: result.business.id, slug: result.business.slug, name: result.business.name },
    });
  } catch (err) {
    return handleApiError(err);
  }
}
