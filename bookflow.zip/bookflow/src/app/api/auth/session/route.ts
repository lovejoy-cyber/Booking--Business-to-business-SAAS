import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/session";
import { db } from "@/lib/db";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ user: null, business: null });

  const membership = await db.businessMember.findFirst({
    where: { userId: user.id },
    include: { business: { select: { id: true, name: true, slug: true, isDemoMode: true } } },
  });

  return NextResponse.json({
    user: { id: user.id, name: user.name, email: user.email },
    business: membership?.business ?? null,
    role: membership?.role ?? null,
  });
}
