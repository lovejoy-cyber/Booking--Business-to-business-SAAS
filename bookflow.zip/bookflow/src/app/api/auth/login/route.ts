import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword, createSessionToken, setSessionCookie } from "@/lib/auth";
import { loginSchema } from "@/lib/validation";
import { AppError, handleApiError } from "@/lib/errors";
import { checkRateLimit } from "@/lib/rateLimit";
import { clientIp, writeAuditLog } from "@/lib/audit";

export async function POST(req: NextRequest) {
  try {
    const ip = clientIp(req.headers) ?? "unknown";
    // Rate limit by IP AND by email so one bad actor can't lock out a real user
    // by IP alone, while still throttling brute-force attempts per account.
    checkRateLimit(`login:ip:${ip}`, 20, 15 * 60 * 1000);

    const body = await req.json();
    const { email, password } = loginSchema.parse(body);
    checkRateLimit(`login:email:${email.toLowerCase()}`, 8, 15 * 60 * 1000);

    const user = await db.user.findUnique({ where: { email: email.toLowerCase() } });
    // Constant response shape whether the email exists or not — never reveal
    // which part of the credential pair was wrong.
    const genericError = () => AppError.badRequest("Invalid email or password.");

    if (!user) throw genericError();
    const valid = await verifyPassword(password, user.passwordHash);
    if (!valid) throw genericError();

    const token = await createSessionToken({ userId: user.id });
    await setSessionCookie(token);

    await writeAuditLog({ userId: user.id, action: "auth.login", ipAddress: ip });

    return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email } });
  } catch (err) {
    return handleApiError(err);
  }
}
