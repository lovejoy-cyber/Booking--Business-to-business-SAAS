import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSuperAdmin } from "@/lib/session";
import { handleApiError } from "@/lib/errors";

// Admin never sees password hashes or WhatsApp access tokens — selects are explicit allow-lists.
export async function GET() {
  try {
    await requireSuperAdmin();

    const businesses = await db.business.findMany({
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        name: true,
        slug: true,
        type: true,
        isDemoMode: true,
        createdAt: true,
        members: { select: { user: { select: { name: true, email: true } }, role: true } },
        subscription: { select: { plan: true, status: true } },
        _count: { select: { appointments: true, customers: true } },
        whatsappConfig: { select: { isConfigured: true } },
      },
    });

    return NextResponse.json({ businesses });
  } catch (err) {
    return handleApiError(err);
  }
}
