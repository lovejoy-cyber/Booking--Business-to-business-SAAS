import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSuperAdmin } from "@/lib/session";
import { handleApiError } from "@/lib/errors";

export async function GET() {
  try {
    await requireSuperAdmin();

    const [businessCount, userCount, appointmentCount, activeTrials, notificationFailures, last30dAppointments] =
      await Promise.all([
        db.business.count(),
        db.user.count(),
        db.appointment.count(),
        db.subscription.count({ where: { status: "TRIALING" } }),
        db.notification.count({ where: { status: "FAILED" } }),
        db.appointment.count({ where: { createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) } } }),
      ]);

    return NextResponse.json({
      businessCount,
      userCount,
      appointmentCount,
      activeTrials,
      notificationFailures,
      last30dAppointments,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
