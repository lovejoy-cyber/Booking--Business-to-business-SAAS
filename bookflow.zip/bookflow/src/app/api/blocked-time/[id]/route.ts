import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { AppError, handleApiError } from "@/lib/errors";
import { writeAuditLog } from "@/lib/audit";

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user, business } = await requireCurrentBusiness("MANAGER");
    const block = await db.blockedTime.findFirst({ where: { id: params.id, businessId: business.id } });
    if (!block) throw AppError.notFound("Blocked time not found.");

    await db.blockedTime.delete({ where: { id: params.id } });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "blocked_time.delete",
      entityType: "BlockedTime",
      entityId: params.id,
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
