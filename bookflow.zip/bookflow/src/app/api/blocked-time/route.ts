import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { blockedTimeSchema } from "@/lib/validation";
import { AppError, handleApiError } from "@/lib/errors";
import { writeAuditLog } from "@/lib/audit";

export async function GET(req: NextRequest) {
  try {
    const { business } = await requireCurrentBusiness();
    const from = req.nextUrl.searchParams.get("from");
    const to = req.nextUrl.searchParams.get("to");

    const blocks = await db.blockedTime.findMany({
      where: {
        businessId: business.id,
        ...(from && to ? { startsAt: { lt: new Date(to) }, endsAt: { gt: new Date(from) } } : {}),
      },
      orderBy: { startsAt: "asc" },
    });
    return NextResponse.json({ blockedTimes: blocks });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const { user, business } = await requireCurrentBusiness("MANAGER");
    const input = blockedTimeSchema.parse(await req.json());

    const startsAt = new Date(input.startsAt);
    const endsAt = new Date(input.endsAt);
    if (startsAt >= endsAt) throw AppError.badRequest("End time must be after start time.");

    const block = await db.blockedTime.create({
      data: { businessId: business.id, employeeId: input.employeeId ?? null, startsAt, endsAt, reason: input.reason },
    });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "blocked_time.create",
      entityType: "BlockedTime",
      entityId: block.id,
    });

    return NextResponse.json({ blockedTime: block }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
