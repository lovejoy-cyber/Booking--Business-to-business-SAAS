import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { handleApiError } from "@/lib/errors";

// Business-scoped notification log — powers the dashboard's Notifications page.
export async function GET(req: NextRequest) {
  try {
    const { business } = await requireCurrentBusiness();
    const status = req.nextUrl.searchParams.get("status");

    const notifications = await db.notification.findMany({
      where: { businessId: business.id, ...(status ? { status: status as any } : {}) },
      orderBy: { createdAt: "desc" },
      take: 100,
      include: { appointment: { include: { customer: true } } },
    });

    const failureCount = await db.notification.count({ where: { businessId: business.id, status: "FAILED" } });

    return NextResponse.json({ notifications, failureCount });
  } catch (err) {
    return handleApiError(err);
  }
}
