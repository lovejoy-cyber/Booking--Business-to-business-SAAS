import { NextRequest, NextResponse } from "next/server";
import { processPendingNotifications } from "@/lib/whatsapp/service";
import { AppError, handleApiError } from "@/lib/errors";

/**
 * Drains the notification queue. Intended to be invoked by a scheduled job
 * (cron, Vercel Cron, GitHub Actions schedule, etc.) every 1-2 minutes — see
 * README § Deployment. Protected by a shared secret rather than a user
 * session since the caller is a machine, not a signed-in person.
 */
export async function POST(req: NextRequest) {
  try {
    const secret = req.headers.get("x-cron-secret");
    const expected = process.env.CRON_SECRET;
    if (!expected || secret !== expected) {
      throw AppError.unauthorized("Invalid or missing cron secret.");
    }

    const result = await processPendingNotifications(50);
    return NextResponse.json(result);
  } catch (err) {
    return handleApiError(err);
  }
}
