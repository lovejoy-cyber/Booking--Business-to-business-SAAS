import { NextRequest, NextResponse } from "next/server";
import { requireCurrentBusiness } from "@/lib/tenant";
import { getAvailableSlots, parseLocalDateParam } from "@/lib/booking/availability";
import { AppError, handleApiError } from "@/lib/errors";

// Authenticated equivalent of /api/public/[slug]/availability, used by the
// dashboard's "New appointment" modal when staff book on a customer's behalf.
export async function GET(req: NextRequest) {
  try {
    const { business } = await requireCurrentBusiness();

    const serviceId = req.nextUrl.searchParams.get("serviceId");
    const employeeId = req.nextUrl.searchParams.get("employeeId");
    const date = req.nextUrl.searchParams.get("date");
    if (!serviceId || !date) throw AppError.badRequest("serviceId and date are required.");
    parseLocalDateParam(date);

    const slots = await getAvailableSlots({ businessId: business.id, serviceId, employeeId: employeeId || undefined, date });
    return NextResponse.json({ slots, timezone: business.timezone });
  } catch (err) {
    return handleApiError(err);
  }
}
