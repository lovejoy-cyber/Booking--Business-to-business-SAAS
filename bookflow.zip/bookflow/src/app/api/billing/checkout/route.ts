import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { AppError, handleApiError } from "@/lib/errors";
import { getStripe } from "@/lib/billing/stripe";
import { PLANS } from "@/lib/billing/plans";
import { writeAuditLog } from "@/lib/audit";

const bodySchema = z.object({ plan: z.enum(["STARTER", "PROFESSIONAL", "BUSINESS"]) });

/**
 * Creates a Stripe Checkout Session for the requested paid plan and returns
 * its URL for the client to redirect to. The actual plan/status change on
 * our side only happens once Stripe confirms payment via the webhook
 * (src/app/api/webhooks/stripe/route.ts) — never on this request, since the
 * checkout might be abandoned.
 */
export async function POST(req: NextRequest) {
  try {
    const { user, business } = await requireCurrentBusiness("OWNER");
    const { plan } = bodySchema.parse(await req.json());

    const planDef = PLANS[plan];
    if (!planDef.priceId) {
      throw AppError.badRequest(`Billing isn't fully configured for the ${planDef.name} plan yet. Set its Stripe price ID in the environment.`);
    }

    const subscription = await db.subscription.findUnique({ where: { businessId: business.id } });
    const stripe = getStripe();
    const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? req.nextUrl.origin;

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer: subscription?.stripeCustomerId ?? undefined,
      customer_email: subscription?.stripeCustomerId ? undefined : user.email,
      client_reference_id: business.id,
      line_items: [{ price: planDef.priceId, quantity: 1 }],
      subscription_data: { metadata: { businessId: business.id } },
      success_url: `${appUrl}/dashboard/settings?billing=success`,
      cancel_url: `${appUrl}/dashboard/settings?billing=cancelled`,
      metadata: { businessId: business.id, plan },
    });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "billing.checkout_started",
      metadata: { plan },
    });

    return NextResponse.json({ url: session.url });
  } catch (err) {
    return handleApiError(err);
  }
}
