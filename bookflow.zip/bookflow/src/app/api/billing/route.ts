import { NextResponse } from "next/server";
import { requireCurrentBusiness } from "@/lib/tenant";
import { getUsageSummary } from "@/lib/billing/subscription";
import { PLANS } from "@/lib/billing/plans";
import { handleApiError } from "@/lib/errors";

export async function GET() {
  try {
    const { business } = await requireCurrentBusiness();
    const summary = await getUsageSummary(business.id);
    return NextResponse.json({ ...summary, plans: PLANS });
  } catch (err) {
    return handleApiError(err);
  }
}
