import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { AppError, handleApiError } from "@/lib/errors";
import { getStripe } from "@/lib/billing/stripe";

/**
 * Creates a Stripe Billing Portal session so an owner can update their card,
 * view invoices, or cancel — without BookFlow needing to build any of that
 * UI itself. Requires the business to already have a Stripe customer, i.e.
 * to have completed checkout at least once.
 */
export async function POST(req: NextRequest) {
  try {
    const { business } = await requireCurrentBusiness("OWNER");
    const subscription = await db.subscription.findUnique({ where: { businessId: business.id } });

    if (!subscription?.stripeCustomerId) {
      throw AppError.badRequest("No billing account yet — subscribe to a paid plan first.");
    }

    const stripe = getStripe();
    const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? req.nextUrl.origin;

    const session = await stripe.billingPortal.sessions.create({
      customer: subscription.stripeCustomerId,
      return_url: `${appUrl}/dashboard/settings`,
    });

    return NextResponse.json({ url: session.url });
  } catch (err) {
    return handleApiError(err);
  }
}
