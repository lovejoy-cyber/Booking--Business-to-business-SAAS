import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { publicBookingSchema } from "@/lib/validation";
import { AppError, handleApiError } from "@/lib/errors";
import { createAppointment } from "@/lib/booking/appointments";
import { checkRateLimit } from "@/lib/rateLimit";
import { clientIp } from "@/lib/audit";

export async function POST(req: NextRequest, { params }: { params: { slug: string } }) {
  try {
    const ip = clientIp(req.headers) ?? "unknown";
    // Generous enough for a genuine customer double-checking times, tight
    // enough to blunt scripted booking spam against a public endpoint.
    checkRateLimit(`book:${ip}`, 10, 10 * 60 * 1000);

    const business = await db.business.findUnique({ where: { slug: params.slug } });
    if (!business) throw AppError.notFound("Business not found.");

    const input = publicBookingSchema.parse(await req.json());
    checkRateLimit(`book:phone:${input.whatsappE164}`, 5, 10 * 60 * 1000);

    const appointment = await createAppointment({
      business,
      serviceId: input.serviceId,
      employeeId: input.employeeId,
      startsAt: new Date(input.startsAt),
      notes: input.notes,
      customer: { name: input.customerName, whatsappE164: input.whatsappE164 },
    });

    const service = await db.service.findUnique({ where: { id: input.serviceId } });

    return NextResponse.json(
      {
        appointment: {
          id: appointment.id,
          startsAt: appointment.startsAt,
          endsAt: appointment.endsAt,
          status: appointment.status,
        },
        service: service ? { name: service.name, priceCents: service.priceCents } : null,
        business: { name: business.name, timezone: business.timezone, currency: business.currency },
      },
      { status: 201 }
    );
  } catch (err) {
    return handleApiError(err);
  }
}
