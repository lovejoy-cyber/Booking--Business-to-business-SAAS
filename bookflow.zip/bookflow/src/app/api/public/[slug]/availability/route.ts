import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAvailableSlots, parseLocalDateParam } from "@/lib/booking/availability";
import { AppError, handleApiError } from "@/lib/errors";
import { checkRateLimit } from "@/lib/rateLimit";
import { clientIp } from "@/lib/audit";

export async function GET(req: NextRequest, { params }: { params: { slug: string } }) {
  try {
    const ip = clientIp(req.headers) ?? "unknown";
    checkRateLimit(`availability:${ip}`, 120, 60 * 1000);

    const business = await db.business.findUnique({ where: { slug: params.slug } });
    if (!business) throw AppError.notFound("Business not found.");

    const serviceId = req.nextUrl.searchParams.get("serviceId");
    const employeeId = req.nextUrl.searchParams.get("employeeId");
    const date = req.nextUrl.searchParams.get("date");

    if (!serviceId || !date) throw AppError.badRequest("serviceId and date are required.");
    parseLocalDateParam(date);

    const slots = await getAvailableSlots({
      businessId: business.id,
      serviceId,
      employeeId: employeeId || undefined,
      date,
    });

    return NextResponse.json({ slots, timezone: business.timezone });
  } catch (err) {
    return handleApiError(err);
  }
}
