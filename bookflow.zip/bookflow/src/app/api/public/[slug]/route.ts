import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { AppError, handleApiError } from "@/lib/errors";

// Public, unauthenticated: everything a customer needs to see a booking page.
export async function GET(_req: NextRequest, { params }: { params: { slug: string } }) {
  try {
    const business = await db.business.findUnique({
      where: { slug: params.slug },
      select: {
        id: true,
        name: true,
        slug: true,
        description: true,
        logoUrl: true,
        address: true,
        currency: true,
        timezone: true,
        type: true,
        cancellationPolicy: true,
        services: {
          where: { isActive: true },
          orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
        },
        employees: {
          where: { isActive: true },
          select: { id: true, name: true },
        },
      },
    });

    if (!business) throw AppError.notFound("We couldn't find that business.");

    return NextResponse.json({ business });
  } catch (err) {
    return handleApiError(err);
  }
}
