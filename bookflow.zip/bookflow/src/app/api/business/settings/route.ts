import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { businessSettingsSchema } from "@/lib/validation";
import { handleApiError } from "@/lib/errors";
import { writeAuditLog } from "@/lib/audit";

export async function PATCH(req: NextRequest) {
  try {
    const { user, business } = await requireCurrentBusiness("MANAGER");
    const input = businessSettingsSchema.parse(await req.json());

    const updated = await db.business.update({
      where: { id: business.id },
      data: input,
    });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "business.settings_update",
      entityType: "Business",
      entityId: business.id,
      metadata: input as Record<string, unknown>,
    });

    return NextResponse.json({ business: updated });
  } catch (err) {
    return handleApiError(err);
  }
}
