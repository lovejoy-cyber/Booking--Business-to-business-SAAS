import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { whatsappConfigSchema } from "@/lib/validation";
import { handleApiError } from "@/lib/errors";
import { encryptSecret } from "@/lib/crypto";
import { writeAuditLog } from "@/lib/audit";

// Returns configuration status only — the access token itself is never sent
// to the frontend, not even in masked form.
export async function GET() {
  try {
    const { business } = await requireCurrentBusiness();
    const config = await db.whatsAppConfiguration.findUnique({ where: { businessId: business.id } });
    return NextResponse.json({
      isConfigured: config?.isConfigured ?? false,
      isDemoMode: business.isDemoMode,
      phoneNumberId: config?.phoneNumberId ?? null,
      wabaId: config?.wabaId ?? null,
    });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function PUT(req: NextRequest) {
  try {
    const { user, business } = await requireCurrentBusiness("OWNER");
    const input = whatsappConfigSchema.parse(await req.json());

    const accessTokenCiphertext = encryptSecret(input.accessToken);

    await db.whatsAppConfiguration.upsert({
      where: { businessId: business.id },
      update: {
        phoneNumberId: input.phoneNumberId,
        wabaId: input.wabaId,
        accessTokenCiphertext,
        isConfigured: true,
      },
      create: {
        businessId: business.id,
        phoneNumberId: input.phoneNumberId,
        wabaId: input.wabaId,
        accessTokenCiphertext,
        isConfigured: true,
      },
    });

    // Configuring real credentials is what allows a business to leave demo mode.
    await db.business.update({ where: { id: business.id }, data: { isDemoMode: false } });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "whatsapp_config.update",
      entityType: "WhatsAppConfiguration",
      // Never log the token itself, even in audit metadata.
      metadata: { phoneNumberId: input.phoneNumberId, wabaId: input.wabaId },
    });

    return NextResponse.json({ ok: true, isDemoMode: false });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE() {
  try {
    const { user, business } = await requireCurrentBusiness("OWNER");
    await db.whatsAppConfiguration.update({
      where: { businessId: business.id },
      data: { isConfigured: false, phoneNumberId: null, wabaId: null, accessTokenCiphertext: null },
    });
    await db.business.update({ where: { id: business.id }, data: { isDemoMode: true } });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "whatsapp_config.disconnect",
      entityType: "WhatsAppConfiguration",
    });

    return NextResponse.json({ ok: true, isDemoMode: true });
  } catch (err) {
    return handleApiError(err);
  }
}
