import { NextResponse } from "next/server";
import { requireCurrentBusiness } from "@/lib/tenant";
import { handleApiError } from "@/lib/errors";

export async function GET() {
  try {
    const { business, role } = await requireCurrentBusiness();
    return NextResponse.json({ business, role });
  } catch (err) {
    return handleApiError(err);
  }
}
