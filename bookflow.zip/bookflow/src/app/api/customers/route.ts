import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { customerSchema } from "@/lib/validation";
import { AppError, handleApiError } from "@/lib/errors";
import { writeAuditLog } from "@/lib/audit";

export async function GET(req: NextRequest) {
  try {
    const { business } = await requireCurrentBusiness();
    const q = req.nextUrl.searchParams.get("q")?.trim();

    const customers = await db.customer.findMany({
      where: {
        businessId: business.id,
        ...(q
          ? { OR: [{ name: { contains: q, mode: "insensitive" } }, { whatsappE164: { contains: q } }] }
          : {}),
      },
      orderBy: { createdAt: "desc" },
      include: {
        _count: { select: { appointments: true } },
      },
      take: 100,
    });

    return NextResponse.json({ customers });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const { user, business } = await requireCurrentBusiness("EMPLOYEE");
    const input = customerSchema.parse(await req.json());

    const existing = await db.customer.findUnique({
      where: { businessId_whatsappE164: { businessId: business.id, whatsappE164: input.whatsappE164 } },
    });
    if (existing) throw AppError.conflict("A customer with that WhatsApp number already exists.");

    const customer = await db.customer.create({ data: { ...input, businessId: business.id } });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "customer.create",
      entityType: "Customer",
      entityId: customer.id,
    });

    return NextResponse.json({ customer }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
