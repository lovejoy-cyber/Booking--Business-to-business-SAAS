import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { customerSchema } from "@/lib/validation";
import { AppError, handleApiError } from "@/lib/errors";
import { writeAuditLog } from "@/lib/audit";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { business } = await requireCurrentBusiness();
    const customer = await db.customer.findFirst({
      where: { id: params.id, businessId: business.id },
      include: {
        appointments: {
          orderBy: { startsAt: "desc" },
          include: { service: true, employee: true },
          take: 50,
        },
      },
    });
    if (!customer) throw AppError.notFound("Customer not found.");

    const completed = customer.appointments.filter((a) => a.status === "COMPLETED");
    const cancelled = customer.appointments.filter((a) => a.status === "CANCELLED");
    const noShows = customer.appointments.filter((a) => a.status === "NO_SHOW");
    const estimatedValueCents = completed.reduce((sum, a) => sum + a.priceCents, 0);

    return NextResponse.json({
      customer,
      stats: {
        totalAppointments: customer.appointments.length,
        completed: completed.length,
        cancelled: cancelled.length,
        noShows: noShows.length,
        estimatedValueCents,
      },
    });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user, business } = await requireCurrentBusiness("EMPLOYEE");
    const existing = await db.customer.findFirst({ where: { id: params.id, businessId: business.id } });
    if (!existing) throw AppError.notFound("Customer not found.");

    const input = customerSchema.partial().parse(await req.json());
    const customer = await db.customer.update({ where: { id: params.id }, data: input });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "customer.update",
      entityType: "Customer",
      entityId: params.id,
    });

    return NextResponse.json({ customer });
  } catch (err) {
    return handleApiError(err);
  }
}
