import { NextRequest, NextResponse } from "next/server";
import { requireCurrentBusiness } from "@/lib/tenant";
import { handleApiError } from "@/lib/errors";
import { markAppointmentStatus } from "@/lib/booking/appointments";

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user, business } = await requireCurrentBusiness("EMPLOYEE");
    const appointment = await markAppointmentStatus({
      business,
      appointmentId: params.id,
      status: "COMPLETED",
      actorUserId: user.id,
    });
    return NextResponse.json({ appointment });
  } catch (err) {
    return handleApiError(err);
  }
}
