import { NextRequest, NextResponse } from "next/server";
import { requireCurrentBusiness } from "@/lib/tenant";
import { rescheduleSchema } from "@/lib/validation";
import { handleApiError } from "@/lib/errors";
import { rescheduleAppointment } from "@/lib/booking/appointments";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user, business } = await requireCurrentBusiness("EMPLOYEE");
    const input = rescheduleSchema.parse(await req.json());

    const appointment = await rescheduleAppointment({
      business,
      appointmentId: params.id,
      startsAt: new Date(input.startsAt),
      employeeId: input.employeeId,
      actorUserId: user.id,
    });

    return NextResponse.json({ appointment });
  } catch (err) {
    return handleApiError(err);
  }
}
