import { NextRequest, NextResponse } from "next/server";
import { requireCurrentBusiness } from "@/lib/tenant";
import { cancelSchema } from "@/lib/validation";
import { handleApiError } from "@/lib/errors";
import { cancelAppointment } from "@/lib/booking/appointments";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user, business } = await requireCurrentBusiness("EMPLOYEE");
    const input = cancelSchema.parse(await req.json().catch(() => ({})));

    const appointment = await cancelAppointment({
      business,
      appointmentId: params.id,
      reason: input.reason,
      actorUserId: user.id,
    });

    return NextResponse.json({ appointment });
  } catch (err) {
    return handleApiError(err);
  }
}
