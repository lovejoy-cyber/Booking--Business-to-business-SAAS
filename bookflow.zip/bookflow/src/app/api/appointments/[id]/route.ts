import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { AppError, handleApiError } from "@/lib/errors";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { business } = await requireCurrentBusiness();
    const appointment = await db.appointment.findFirst({
      where: { id: params.id, businessId: business.id },
      include: { customer: true, service: true, employee: true, notifications: true },
    });
    if (!appointment) throw AppError.notFound("Appointment not found.");
    return NextResponse.json({ appointment });
  } catch (err) {
    return handleApiError(err);
  }
}
