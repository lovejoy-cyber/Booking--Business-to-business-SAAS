import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { createAppointmentSchema } from "@/lib/validation";
import { AppError, handleApiError } from "@/lib/errors";
import { createAppointment } from "@/lib/booking/appointments";

// GET /api/appointments?from=ISO&to=ISO&status=CONFIRMED — powers the calendar & dashboard.
export async function GET(req: NextRequest) {
  try {
    const { business } = await requireCurrentBusiness();
    const from = req.nextUrl.searchParams.get("from");
    const to = req.nextUrl.searchParams.get("to");
    const status = req.nextUrl.searchParams.get("status");

    const appointments = await db.appointment.findMany({
      where: {
        businessId: business.id,
        ...(from && to ? { startsAt: { gte: new Date(from) }, endsAt: { lte: new Date(to) } } : {}),
        ...(status ? { status: status as any } : {}),
      },
      include: { customer: true, service: true, employee: true },
      orderBy: { startsAt: "asc" },
    });

    return NextResponse.json({ appointments });
  } catch (err) {
    return handleApiError(err);
  }
}

// POST — manual booking created from the dashboard (owner booking on a customer's behalf).
export async function POST(req: NextRequest) {
  try {
    const { user, business } = await requireCurrentBusiness("EMPLOYEE");
    const input = createAppointmentSchema.parse(await req.json());

    if (!input.customerId && !input.customer) {
      throw AppError.badRequest("Provide either customerId or new customer details.");
    }

    const appointment = await createAppointment({
      business,
      serviceId: input.serviceId,
      employeeId: input.employeeId,
      startsAt: new Date(input.startsAt),
      notes: input.notes,
      customer: input.customerId ? { id: input.customerId } : input.customer!,
      actorUserId: user.id,
    });

    return NextResponse.json({ appointment }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
