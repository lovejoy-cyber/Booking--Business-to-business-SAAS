import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { handleApiError } from "@/lib/errors";
import { writeAuditLog } from "@/lib/audit";
import { enforceStaffLimit } from "@/lib/billing/subscription";

const employeeSchema = z.object({ name: z.string().trim().min(1).max(150) });

export async function GET() {
  try {
    const { business } = await requireCurrentBusiness();
    const employees = await db.employee.findMany({
      where: { businessId: business.id },
      orderBy: { createdAt: "asc" },
    });
    return NextResponse.json({ employees });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const { user, business } = await requireCurrentBusiness("MANAGER");
    const input = employeeSchema.parse(await req.json());

    await enforceStaffLimit(business.id);

    const employee = await db.employee.create({ data: { ...input, businessId: business.id } });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "employee.create",
      entityType: "Employee",
      entityId: employee.id,
    });

    return NextResponse.json({ employee }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
