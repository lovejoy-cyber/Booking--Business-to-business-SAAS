import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireCurrentBusiness } from "@/lib/tenant";
import { AppError, handleApiError } from "@/lib/errors";
import { writeAuditLog } from "@/lib/audit";

const updateSchema = z.object({ name: z.string().trim().min(1).max(150).optional(), isActive: z.boolean().optional() });

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { user, business } = await requireCurrentBusiness("MANAGER");
    const existing = await db.employee.findFirst({ where: { id: params.id, businessId: business.id } });
    if (!existing) throw AppError.notFound("Staff member not found.");

    const input = updateSchema.parse(await req.json());
    const employee = await db.employee.update({ where: { id: params.id }, data: input });

    await writeAuditLog({
      businessId: business.id,
      userId: user.id,
      action: "employee.update",
      entityType: "Employee",
      entityId: params.id,
    });

    return NextResponse.json({ employee });
  } catch (err) {
    return handleApiError(err);
  }
}
