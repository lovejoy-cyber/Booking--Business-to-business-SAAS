import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { Ticket } from "@/components/ui/Ticket";
import { HeroTicket } from "@/components/landing/HeroTicket";
import { FaqAccordion } from "@/components/landing/FaqAccordion";

const FEATURES = [
  {
    title: "Online booking",
    body: "A booking page you can text or DM to any customer. They pick a service, a date, a time — no account, no app to download.",
  },
  {
    title: "Customer management",
    body: "Every customer's history in one place: visits, no-shows, notes, and what they've spent — so regulars feel remembered.",
  },
  {
    title: "WhatsApp reminders",
    body: "Confirmation the moment they book, a reminder the day before, and again the morning of. Automatically, every time.",
  },
  {
    title: "Business calendar",
    body: "Day and week views built for a shop floor: who's in the chair, who's next, and what's still open this afternoon.",
  },
  {
    title: "No-show tracking",
    body: "See your no-show rate at a glance, and know exactly which customers to follow up with before it becomes a habit.",
  },
  {
    title: "Simple analytics",
    body: "Today's revenue, this week's bookings, your busiest hours — the numbers that actually change what you do next.",
  },
];

const MESSAGES = [
  { label: "Booking confirmation", text: "Your appointment with Elite Cuts is confirmed for Saturday, 22 August at 14:30." },
  { label: "Reminder — the day before", text: "Reminder: you have an appointment with Elite Cuts tomorrow at 14:30." },
  { label: "Reminder — same day", text: "Reminder: your appointment with Elite Cuts is today at 14:30." },
  { label: "Cancellation", text: "Your appointment with Elite Cuts on Saturday, 22 August at 14:30 has been cancelled." },
];

const PLANS = [
  {
    name: "Free Trial",
    price: "$0",
    period: "14 days",
    blurb: "Everything switched on, capped low, so you can run real bookings before you pay for anything.",
    bullets: ["Up to 30 appointments", "1 staff member", "WhatsApp reminders (demo mode)", "Booking page included"],
    cta: "Start Free",
  },
  {
    name: "Starter",
    price: "$19",
    period: "/month",
    blurb: "For a single-chair shop that's outgrown a paper book and a group chat.",
    bullets: ["Up to 100 appointments/mo", "1 staff member", "Live WhatsApp reminders", "Customer history & notes"],
    cta: "Start Free",
  },
  {
    name: "Professional",
    price: "$39",
    period: "/month",
    blurb: "For a busy shop that wants no-show tracking and reminders doing real work.",
    bullets: ["Up to 400 appointments/mo", "Up to 3 staff members", "No-show & analytics dashboard", "Priority support"],
    cta: "Start Free",
    featured: true,
  },
  {
    name: "Business",
    price: "$79",
    period: "/month",
    blurb: "For multiple chairs or multiple locations run from one account.",
    bullets: ["Unlimited appointments", "Unlimited staff", "Multiple locations", "Dedicated onboarding"],
    cta: "Talk to us",
  },
];

const FAQS = [
  {
    q: "Do my customers need to install anything?",
    a: "No. They open your booking page in any browser and book in under a minute. Reminders arrive on WhatsApp, which they already have.",
  },
  {
    q: "What if I don't have WhatsApp Business set up yet?",
    a: "Start in demo mode — bookings, reminders, and your dashboard all work exactly the same, just simulated, so you can show customers and staff how it works before connecting a real WhatsApp number.",
  },
  {
    q: "Can more than one barber use the same account?",
    a: "Yes. Add each staff member's working hours, and BookFlow keeps their calendars, breaks, and bookings separate automatically.",
  },
  {
    q: "Is my customer list visible to other businesses on BookFlow?",
    a: "No. Every business's customers, appointments, and settings are fully isolated at the database level — there's no view, export, or admin action that crosses between businesses.",
  },
  {
    q: "What happens if two customers try to book the same slot?",
    a: "The second booking is rejected before it's confirmed and the customer is asked to pick another time — BookFlow checks availability again at the moment of booking, not just when the page first loaded.",
  },
];

export default function LandingPage() {
  return (
    <main className="bg-paper-100">
      {/* ── Hero ─────────────────────────────────────────────── */}
      <section className="relative overflow-hidden border-b border-ink-200 bg-ink-950">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)",
            backgroundSize: "28px 28px",
          }}
          aria-hidden
        />
        <nav className="relative mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
          <span className="font-display text-xl font-semibold text-paper-50">BookFlow</span>
          <div className="flex items-center gap-3">
            <Link href="/login" className="text-sm font-medium text-paper-200 hover:text-white">
              Log in
            </Link>
            <Link href="/register">
              <Button size="sm">Start Free</Button>
            </Link>
          </div>
        </nav>

        <div className="relative mx-auto grid max-w-6xl gap-12 px-6 pb-20 pt-8 sm:pb-28 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
          <div>
            <p className="mb-4 inline-flex items-center rounded-full border border-white/15 px-3 py-1 text-xs font-medium uppercase tracking-[0.14em] text-pine-300">
              Built for barbershops first
            </p>
            <h1 className="font-display text-4xl font-semibold leading-[1.08] text-white sm:text-5xl lg:text-[3.4rem]">
              Stop losing customers to forgotten appointments.
            </h1>
            <p className="mt-5 max-w-lg text-lg text-ink-200">
              BookFlow gives your business online booking and automatic WhatsApp reminders in one simple system.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Link href="/register">
                <Button size="lg">Start Free</Button>
              </Link>
              <Link href="/book/elite-cuts" className="text-sm font-medium text-paper-100 underline decoration-white/30 underline-offset-4 hover:text-white">
                See a live booking page →
              </Link>
            </div>
            <p className="mt-6 text-sm text-ink-400">No card required. Runs in demo mode until you're ready to go live.</p>
          </div>
          <div className="animate-fade-in lg:justify-self-end">
            <HeroTicket />
          </div>
        </div>
      </section>

      {/* ── How it works ────────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-6 py-20 sm:py-28">
        <h2 className="font-display text-3xl font-semibold text-ink-900 sm:text-4xl">How it works</h2>
        <div className="mt-12 grid gap-10 md:grid-cols-3">
          {[
            { label: "Set up once", body: "Add your services, prices, and working hours. BookFlow builds your booking page automatically." },
            { label: "Customers book themselves", body: "Share your link. They pick a service, date, and time — no back-and-forth texting." },
            { label: "Reminders send themselves", body: "Confirmation on booking, a reminder the day before, and again the morning of. You just show up." },
          ].map((step, i) => (
            <div key={step.label} className="relative pl-6">
              <div className="absolute left-0 top-1.5 h-full w-px bg-ink-200 last:hidden" aria-hidden />
              <div className="absolute -left-[5px] top-1 h-3 w-3 rounded-full border-2 border-pine-600 bg-paper-100" aria-hidden />
              <p className="text-sm font-semibold uppercase tracking-wide text-pine-700">{step.label}</p>
              <p className="mt-2 text-ink-600">{step.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Features ─────────────────────────────────────────── */}
      <section className="border-y border-ink-200 bg-white py-20 sm:py-28">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="font-display text-3xl font-semibold text-ink-900 sm:text-4xl">
            Everything a shop needs. Nothing it doesn't.
          </h2>
          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div key={f.title}>
                <h3 className="font-display text-lg font-semibold text-ink-900">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-600">{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WhatsApp reminders ───────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-6 py-20 sm:py-28">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <div>
            <h2 className="font-display text-3xl font-semibold text-ink-900 sm:text-4xl">
              The reminder is the whole product.
            </h2>
            <p className="mt-4 max-w-md text-ink-600">
              Every message goes out on the official WhatsApp Business Platform — the same inbox your customers
              already check, not another app they have to remember to open.
            </p>
          </div>
          <div className="space-y-3">
            {MESSAGES.map((m) => (
              <div key={m.label} className="rounded-xl bg-ink-900 p-4">
                <p className="mb-1.5 text-xs font-medium uppercase tracking-wide text-ink-400">{m.label}</p>
                <p className="rounded-lg bg-pine-700 px-3.5 py-2.5 text-sm text-white">{m.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Dashboard preview ────────────────────────────────── */}
      <section className="border-y border-ink-200 bg-white py-20 sm:py-28">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="font-display text-3xl font-semibold text-ink-900 sm:text-4xl">Your whole day, on one screen.</h2>
          <div className="mt-10 grid gap-4 rounded-2xl border border-ink-200 bg-paper-50 p-6 sm:grid-cols-4">
            {[
              { label: "Today's appointments", value: "11", sub: "9 confirmed · 2 pending" },
              { label: "Estimated revenue", value: "$165", sub: "from today's bookings" },
              { label: "Customers", value: "284", sub: "on file" },
              { label: "No-show rate", value: "4.2%", sub: "last 30 days" },
            ].map((stat) => (
              <div key={stat.label} className="rounded-xl bg-white p-5 shadow-card">
                <p className="text-xs font-medium uppercase tracking-wide text-ink-400">{stat.label}</p>
                <p className="mt-2 font-display text-3xl font-semibold text-ink-900">{stat.value}</p>
                <p className="mt-1 text-xs text-ink-500">{stat.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pricing ──────────────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-6 py-20 sm:py-28" id="pricing">
        <h2 className="font-display text-3xl font-semibold text-ink-900 sm:text-4xl">Pricing that grows with your chair count.</h2>
        <div className="mt-12 grid gap-6 lg:grid-cols-4">
          {PLANS.map((plan) => (
            <Ticket
              key={plan.name}
              tone={plan.featured ? "ink" : "paper"}
              eyebrow={plan.name}
              title={
                <span className="flex items-baseline gap-1">
                  {plan.price}
                  <span className="font-sans text-sm font-normal opacity-60">{plan.period}</span>
                </span>
              }
              footer={
                <Link href="/register">
                  <Button variant={plan.featured ? "primary" : "secondary"} className="w-full">
                    {plan.cta}
                  </Button>
                </Link>
              }
            >
              <p className={plan.featured ? "text-sm text-paper-200" : "text-sm text-ink-600"}>{plan.blurb}</p>
              <ul className="mt-4 space-y-2 text-sm">
                {plan.bullets.map((b) => (
                  <li key={b} className="flex items-start gap-2">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="mt-0.5 shrink-0 text-pine-500">
                      <path d="M5 12l4 4 10-10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    <span className={plan.featured ? "text-paper-100" : "text-ink-700"}>{b}</span>
                  </li>
                ))}
              </ul>
            </Ticket>
          ))}
        </div>
      </section>

      {/* ── FAQ ──────────────────────────────────────────────── */}
      <section className="border-t border-ink-200 bg-white py-20 sm:py-28">
        <div className="mx-auto max-w-3xl px-6">
          <h2 className="font-display text-3xl font-semibold text-ink-900 sm:text-4xl">Questions, answered</h2>
          <div className="mt-8">
            <FaqAccordion items={FAQS} />
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────── */}
      <section className="bg-ink-950 py-20 text-center sm:py-28">
        <div className="mx-auto max-w-2xl px-6">
          <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
            Your next customer is one missed text away from forgetting.
          </h2>
          <p className="mt-4 text-ink-300">Set up your booking page in under ten minutes. No card required.</p>
          <Link href="/register" className="mt-8 inline-block">
            <Button size="lg">Start Free</Button>
          </Link>
        </div>
      </section>

      <footer className="border-t border-ink-800 bg-ink-950 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-6 text-sm text-ink-500 sm:flex-row">
          <span>© {new Date().getFullYear()} BookFlow</span>
          <span>Built on the official WhatsApp Business Platform</span>
        </div>
      </footer>
    </main>
  );
}
