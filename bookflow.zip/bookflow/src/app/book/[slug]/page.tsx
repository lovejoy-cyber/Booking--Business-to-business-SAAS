"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { Input, Label, ErrorText, Textarea } from "@/components/ui/Field";
import { Ticket } from "@/components/ui/Ticket";
import { formatMoney, formatDuration, initials } from "@/lib/format";

interface Service {
  id: string;
  name: string;
  description: string | null;
  priceCents: number;
  durationMinutes: number;
}
interface Employee {
  id: string;
  name: string;
}
interface BusinessInfo {
  id: string;
  name: string;
  description: string | null;
  address: string | null;
  currency: string;
  timezone: string;
  cancellationPolicy: string | null;
  services: Service[];
  employees: Employee[];
}

type Step = "service" | "time" | "details" | "confirmed";

export default function PublicBookingPage() {
  const { slug } = useParams<{ slug: string }>();
  const [business, setBusiness] = useState<BusinessInfo | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [step, setStep] = useState<Step>("service");

  const [serviceId, setServiceId] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [slots, setSlots] = useState<string[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState("");

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [confirmedAt, setConfirmedAt] = useState<string | null>(null);

  useEffect(() => {
    fetch(`/api/public/${slug}`)
      .then((r) => {
        if (!r.ok) throw new Error("not found");
        return r.json();
      })
      .then((d) => setBusiness(d.business))
      .catch(() => setNotFound(true));
  }, [slug]);

  useEffect(() => {
    if (!serviceId || step !== "time") return;
    setSlotsLoading(true);
    setSelectedSlot("");
    const qs = new URLSearchParams({ serviceId, date, ...(employeeId ? { employeeId } : {}) });
    fetch(`/api/public/${slug}/availability?${qs}`)
      .then((r) => r.json())
      .then((d) => setSlots(d.slots ?? []))
      .finally(() => setSlotsLoading(false));
  }, [serviceId, employeeId, date, step, slug]);

  if (notFound) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-paper-100 px-6 text-center">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink-900">We couldn't find that business</h1>
          <p className="mt-2 text-ink-500">Double check the link your barber shared with you.</p>
        </div>
      </main>
    );
  }

  if (!business) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-paper-100">
        <p className="text-ink-400">Loading…</p>
      </main>
    );
  }

  const selectedService = business.services.find((s) => s.id === serviceId);

  async function submitBooking() {
    setError(null);
    if (!name.trim() || !phone.trim()) {
      setError("Enter your name and WhatsApp number.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch(`/api/public/${slug}/book`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          serviceId,
          employeeId: employeeId || undefined,
          startsAt: selectedSlot,
          customerName: name,
          whatsappE164: phone,
          notes: notes || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "We couldn't confirm that booking.");
      setConfirmedAt(data.appointment.startsAt);
      setStep("confirmed");
    } catch (err) {
      setError(err instanceof Error ? err.message : "We couldn't confirm that booking.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen bg-paper-100 pb-16">
      <header className="border-b border-ink-200 bg-white">
        <div className="mx-auto flex max-w-2xl items-center gap-4 px-6 py-6">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-pine-100 font-display text-lg font-semibold text-pine-800">
            {initials(business.name)}
          </span>
          <div>
            <h1 className="font-display text-xl font-semibold text-ink-900">{business.name}</h1>
            {business.address && <p className="text-sm text-ink-500">{business.address}</p>}
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-2xl px-6 py-8">
        {step !== "confirmed" && (
          <ol className="mb-8 flex items-center gap-2 text-xs font-medium text-ink-400">
            {(["service", "time", "details"] as Step[]).map((s, i) => (
              <li key={s} className={`flex items-center gap-2 ${step === s ? "text-pine-700" : ""}`}>
                {i > 0 && <span className="text-ink-200">—</span>}
                <span className="capitalize">{s === "time" ? "Date & time" : s}</span>
              </li>
            ))}
          </ol>
        )}

        {step === "service" && (
          <div className="space-y-3">
            <h2 className="font-display text-2xl font-semibold text-ink-900">Choose a service</h2>
            {business.services.map((s) => (
              <button
                key={s.id}
                onClick={() => {
                  setServiceId(s.id);
                  setStep("time");
                }}
                className="flex w-full items-center justify-between rounded-xl border border-ink-200 bg-white p-4 text-left shadow-card transition-colors hover:border-pine-400"
              >
                <div>
                  <p className="font-display text-lg font-medium text-ink-900">{s.name}</p>
                  {s.description && <p className="mt-0.5 text-sm text-ink-500">{s.description}</p>}
                  <p className="mt-1 text-xs text-ink-400">{formatDuration(s.durationMinutes)}</p>
                </div>
                <span className="shrink-0 font-mono text-lg text-ink-800">{formatMoney(s.priceCents, business.currency)}</span>
              </button>
            ))}
          </div>
        )}

        {step === "time" && selectedService && (
          <div className="space-y-5">
            <button onClick={() => setStep("service")} className="text-sm font-medium text-ink-500 hover:text-ink-700">
              ← Change service
            </button>
            <h2 className="font-display text-2xl font-semibold text-ink-900">Pick a date & time</h2>

            {business.employees.length > 0 && (
              <div>
                <Label hint="optional">Staff member</Label>
                <select
                  value={employeeId}
                  onChange={(e) => setEmployeeId(e.target.value)}
                  className="w-full rounded-lg border border-ink-200 bg-white px-3 py-2 text-sm"
                >
                  <option value="">Any available</option>
                  {business.employees.map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <Label htmlFor="date">Date</Label>
              <Input id="date" type="date" value={date} min={new Date().toISOString().slice(0, 10)} onChange={(e) => setDate(e.target.value)} />
            </div>

            <div>
              <Label>Available times</Label>
              {slotsLoading ? (
                <p className="text-sm text-ink-400">Checking availability…</p>
              ) : slots.length === 0 ? (
                <p className="text-sm text-ink-400">No times available this day — try another date.</p>
              ) : (
                <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
                  {slots.map((slot) => {
                    const label = new Intl.DateTimeFormat("en-US", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: business.timezone }).format(
                      new Date(slot)
                    );
                    return (
                      <button
                        key={slot}
                        onClick={() => setSelectedSlot(slot)}
                        className={`rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
                          selectedSlot === slot ? "border-pine-700 bg-pine-700 text-white" : "border-ink-200 bg-white text-ink-700 hover:border-pine-300"
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <Button className="w-full" disabled={!selectedSlot} onClick={() => setStep("details")}>
              Continue
            </Button>
          </div>
        )}

        {step === "details" && selectedService && (
          <div className="space-y-4">
            <button onClick={() => setStep("time")} className="text-sm font-medium text-ink-500 hover:text-ink-700">
              ← Change time
            </button>
            <h2 className="font-display text-2xl font-semibold text-ink-900">Your details</h2>

            <div>
              <Label htmlFor="name">Name</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" />
            </div>
            <div>
              <Label htmlFor="phone" hint="for your WhatsApp confirmation & reminder">
                WhatsApp number
              </Label>
              <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+15551234567" />
            </div>
            <div>
              <Label hint="optional">Notes for the business</Label>
              <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
            </div>

            <ErrorText>{error}</ErrorText>

            <Button className="w-full" onClick={submitBooking} loading={submitting}>
              Confirm booking
            </Button>
            {business.cancellationPolicy && <p className="text-xs text-ink-400">{business.cancellationPolicy}</p>}
          </div>
        )}

        {step === "confirmed" && selectedService && confirmedAt && (
          <div className="space-y-5">
            <div className="text-center">
              <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-pine-100 text-pine-700">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <path d="M5 12l4 4 10-10" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <h2 className="font-display text-2xl font-semibold text-ink-900">You're booked!</h2>
              <p className="mt-1 text-sm text-ink-500">We've sent a confirmation to your WhatsApp.</p>
            </div>

            <Ticket
              eyebrow={business.name}
              title={selectedService.name}
              code={`#${business.name.slice(0, 2).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`}
              footer={
                <div className="flex items-center justify-between text-sm">
                  <span className="text-ink-500">{name}</span>
                  <span className="font-mono text-ink-700">{formatMoney(selectedService.priceCents, business.currency)}</span>
                </div>
              }
            >
              <p className="font-display text-lg text-ink-900">
                {new Intl.DateTimeFormat("en-US", { weekday: "long", day: "numeric", month: "long", timeZone: business.timezone }).format(new Date(confirmedAt))}
              </p>
              <p className="text-ink-600">
                {new Intl.DateTimeFormat("en-US", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: business.timezone }).format(new Date(confirmedAt))}
              </p>
            </Ticket>
          </div>
        )}
      </div>
    </main>
  );
}
