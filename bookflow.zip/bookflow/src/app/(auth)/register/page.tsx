"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { Input, Label, Select, ErrorText } from "@/components/ui/Field";

const BUSINESS_TYPES: { value: string; label: string }[] = [
  { value: "BARBER", label: "Barbershop" },
  { value: "SALON", label: "Salon" },
  { value: "TUTOR", label: "Tutoring" },
  { value: "MECHANIC", label: "Mechanic / auto shop" },
  { value: "PHOTOGRAPHER", label: "Photographer" },
  { value: "REPAIR", label: "Repair shop" },
  { value: "OTHER", label: "Other" },
];

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    businessName: "",
    businessType: "BARBER",
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Something went wrong.");
      router.push("/dashboard");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-paper-100 px-6 py-12">
      <div className="w-full max-w-md">
        <Link href="/" className="font-display text-xl font-semibold text-ink-900">
          BookFlow
        </Link>
        <h1 className="mt-6 font-display text-2xl font-semibold text-ink-900">Create your business account</h1>
        <p className="mt-1 text-sm text-ink-500">Free for 30 appointments — no card required.</p>

        <form onSubmit={onSubmit} className="mt-8 space-y-4 rounded-2xl border border-ink-200 bg-white p-6 shadow-card">
          <div>
            <Label htmlFor="name">Your name</Label>
            <Input id="name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Marcus Diallo" />
          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              required
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="you@example.com"
            />
          </div>
          <div>
            <Label htmlFor="password" hint="min. 8 characters">
              Password
            </Label>
            <Input
              id="password"
              type="password"
              required
              minLength={8}
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="businessName">Business name</Label>
            <Input
              id="businessName"
              required
              value={form.businessName}
              onChange={(e) => setForm({ ...form, businessName: e.target.value })}
              placeholder="Elite Cuts"
            />
          </div>
          <div>
            <Label htmlFor="businessType">Business type</Label>
            <Select
              id="businessType"
              value={form.businessType}
              onChange={(e) => setForm({ ...form, businessType: e.target.value })}
            >
              {BUSINESS_TYPES.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </Select>
          </div>

          <ErrorText>{error}</ErrorText>

          <Button type="submit" loading={loading} className="w-full">
            Create account
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-ink-500">
          Already have an account?{" "}
          <Link href="/login" className="font-medium text-pine-700 hover:underline">
            Log in
          </Link>
        </p>
      </div>
    </main>
  );
}
