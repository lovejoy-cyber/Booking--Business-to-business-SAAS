"use client";

import { useEffect, useState } from "react";
import { Ticket } from "@/components/ui/Ticket";

/**
 * The hero's one orchestrated motion moment: a confirmation ticket "prints",
 * then its WhatsApp reminder ticks from sent to delivered — echoing the
 * exact lifecycle a barber sees on their own dashboard. Skips straight to
 * the settled state under prefers-reduced-motion.
 */
export function HeroTicket() {
  const [phase, setPhase] = useState<0 | 1 | 2>(0);

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setPhase(2);
      return;
    }
    const t1 = setTimeout(() => setPhase(1), 500);
    const t2 = setTimeout(() => setPhase(2), 1400);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  return (
    <Ticket
      eyebrow="Elite Cuts"
      code="#EC-2451"
      title="Haircut + Beard"
      footer={
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-ink-500">Saturday, 22 August · 14:30</p>
            <p className="text-sm font-medium text-ink-800">Marcus D. · +1 555 0134</p>
          </div>
          <span className="font-mono text-sm text-ink-500">$15</span>
        </div>
      }
    >
      <div
        className={`flex items-start gap-2 rounded-xl bg-pine-700 px-3.5 py-2.5 text-sm text-white transition-all duration-500 ${
          phase >= 1 ? "translate-y-0 opacity-100" : "translate-y-2 opacity-0"
        }`}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" className="mt-0.5 shrink-0" aria-hidden>
          <path d="M17.5 3.5A9.9 9.9 0 0012 2C6.5 2 2 6.5 2 12c0 1.8.5 3.5 1.3 5L2 22l5.2-1.3c1.5.8 3.1 1.2 4.8 1.2 5.5 0 10-4.5 10-10 0-2.7-1-5.2-2.5-8.4zM12 20.2c-1.5 0-3-.4-4.3-1.2l-.3-.2-3 .8.8-3-.2-.3A8.2 8.2 0 013.8 12c0-4.5 3.7-8.2 8.2-8.2 2.2 0 4.3.9 5.8 2.4a8.2 8.2 0 012.4 5.8c0 4.5-3.7 8.2-8.2 8.2z" />
        </svg>
        <div className="flex-1">
          <p>Your appointment with Elite Cuts is confirmed for Sat 22 Aug at 14:30.</p>
          <div className="mt-1 flex items-center justify-end gap-1 text-[11px] text-pine-100">
            <span>14:29</span>
            <svg
              width="14"
              height="14"
              viewBox="0 0 16 16"
              fill="none"
              className={`transition-colors duration-300 ${phase >= 2 ? "text-signal-400" : "text-pine-200/70"}`}
              aria-hidden
            >
              <path d="M1 8l3 3 5-6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M6 8l3 3 6-7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
      </div>
    </Ticket>
  );
}
