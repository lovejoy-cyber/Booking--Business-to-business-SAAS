import { clsx } from "clsx";
import type { ReactNode } from "react";

type Tone = "pine" | "brass" | "ink" | "red" | "signal";

const TONE_CLASSES: Record<Tone, string> = {
  pine: "bg-pine-100 text-pine-800",
  brass: "bg-brass-100 text-brass-800",
  ink: "bg-ink-100 text-ink-700",
  red: "bg-red-100 text-red-700",
  signal: "bg-signal-400/20 text-pine-800",
};

export function Badge({ tone = "ink", children }: { tone?: Tone; children: ReactNode }) {
  return (
    <span className={clsx("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium", TONE_CLASSES[tone])}>
      {children}
    </span>
  );
}

export function statusTone(status: string): Tone {
  switch (status) {
    case "CONFIRMED":
      return "pine";
    case "PENDING":
      return "brass";
    case "CANCELLED":
      return "red";
    case "NO_SHOW":
      return "red";
    case "COMPLETED":
      return "signal";
    default:
      return "ink";
  }
}
