import type { ReactNode } from "react";
import { clsx } from "clsx";

/**
 * The Ticket — BookFlow's one signature element (see README § Design).
 * Modeled on the paper queue ticket a barbershop customer takes and the
 * receipt-like confirmation a WhatsApp message delivers: perforated edge,
 * a dashed tear line, a monospace ticket code. Reused for the booking
 * confirmation screen, dashboard appointment cards, and landing-page pricing
 * — everywhere the product turns "you have an appointment" into a tangible
 * object.
 */
interface TicketProps {
  code?: string;
  eyebrow?: string;
  title: ReactNode;
  children?: ReactNode;
  footer?: ReactNode;
  tone?: "paper" | "ink";
  className?: string;
}

export function Ticket({ code, eyebrow, title, children, footer, tone = "paper", className }: TicketProps) {
  const dark = tone === "ink";
  return (
    <div
      className={clsx(
        "relative overflow-hidden rounded-2xl shadow-floating",
        dark ? "bg-ink-900 text-paper-50" : "bg-paper-50 text-ink-900",
        className
      )}
    >
      <div className={clsx("h-3 w-full", dark ? "ticket-perforation-dark" : "ticket-perforation", "bg-transparent")} />
      <div className="px-6 pb-5 pt-3 sm:px-8">
        <div className="flex items-start justify-between gap-4">
          <div>
            {eyebrow && (
              <p className={clsx("text-xs font-semibold uppercase tracking-[0.16em]", dark ? "text-pine-300" : "text-pine-700")}>
                {eyebrow}
              </p>
            )}
            <div className="mt-1 font-display text-2xl font-semibold leading-snug sm:text-[28px]">{title}</div>
          </div>
          {code && (
            <span
              className={clsx(
                "shrink-0 rounded-md px-2 py-1 font-mono text-xs tracking-wide",
                dark ? "bg-white/10 text-paper-100" : "bg-ink-900/[0.05] text-ink-600"
              )}
            >
              {code}
            </span>
          )}
        </div>
        {children && <div className="mt-4">{children}</div>}
      </div>
      {footer && (
        <div
          className={clsx(
            "border-t border-dashed px-6 py-4 sm:px-8",
            dark ? "border-white/15" : "border-ink-900/15"
          )}
        >
          {footer}
        </div>
      )}
      <div className={clsx("h-3 w-full", dark ? "ticket-perforation-dark" : "ticket-perforation", "rotate-180")} />
    </div>
  );
}

export function DeliveryStatusDot({ status }: { status: "PENDING" | "SENT" | "DELIVERED" | "FAILED" }) {
  const map = {
    PENDING: { color: "bg-ink-300", label: "Queued" },
    SENT: { color: "bg-brass-400", label: "Sent" },
    DELIVERED: { color: "bg-signal-500", label: "Delivered" },
    FAILED: { color: "bg-red-500", label: "Failed" },
  } as const;
  const { color, label } = map[status];
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-ink-500">
      <span className={clsx("h-1.5 w-1.5 rounded-full", color)} aria-hidden />
      {label}
    </span>
  );
}
