"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { clsx } from "clsx";

const LINKS = [
  { href: "/dashboard", label: "Overview", icon: "grid" },
  { href: "/dashboard/calendar", label: "Calendar", icon: "calendar" },
  { href: "/dashboard/customers", label: "Customers", icon: "users" },
  { href: "/dashboard/services", label: "Services", icon: "tag" },
  { href: "/dashboard/notifications", label: "Notifications", icon: "bell" },
  { href: "/dashboard/settings", label: "Settings", icon: "gear" },
];

const ICONS: Record<string, JSX.Element> = {
  grid: (
    <path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z" stroke="currentColor" strokeWidth="1.6" fill="none" />
  ),
  calendar: (
    <path
      d="M7 3v3M17 3v3M4 8h16M5 6h14a1 1 0 011 1v12a1 1 0 01-1 1H5a1 1 0 01-1-1V7a1 1 0 011-1z"
      stroke="currentColor"
      strokeWidth="1.6"
      fill="none"
      strokeLinecap="round"
    />
  ),
  users: (
    <path
      d="M8 11a3 3 0 100-6 3 3 0 000 6zM2 20c0-3.3 2.7-6 6-6s6 2.7 6 6M16 8a2.5 2.5 0 110 5M17 14c2.3.3 4 2.3 4 4.6"
      stroke="currentColor"
      strokeWidth="1.6"
      fill="none"
      strokeLinecap="round"
    />
  ),
  tag: (
    <path
      d="M11.5 3H5a2 2 0 00-2 2v6.5a2 2 0 00.6 1.4l8 8a2 2 0 002.8 0l6.1-6.1a2 2 0 000-2.8l-8-8a2 2 0 00-1-.5z"
      stroke="currentColor"
      strokeWidth="1.6"
      fill="none"
      strokeLinejoin="round"
    />
  ),
  bell: (
    <path
      d="M12 3a5 5 0 00-5 5v3.4c0 .5-.2 1-.5 1.4L5 15h14l-1.5-2.2a2.3 2.3 0 01-.5-1.4V8a5 5 0 00-5-5zM9.5 18a2.5 2.5 0 005 0"
      stroke="currentColor"
      strokeWidth="1.6"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  ),
  gear: (
    <path
      d="M12 15a3 3 0 100-6 3 3 0 000 6z M19.4 13a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.9 2.9l-.1-.1a1.7 1.7 0 00-1.9-.3 1.7 1.7 0 00-1 1.5v.2a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1-1.6 1.7 1.7 0 00-1.9.3l-.1.1a2 2 0 11-2.9-2.9l.1-.1a1.7 1.7 0 00.3-1.9 1.7 1.7 0 00-1.5-1H4a2 2 0 110-4h.1a1.7 1.7 0 001.5-1 1.7 1.7 0 00-.3-1.9l-.1-.1a2 2 0 112.9-2.9l.1.1a1.7 1.7 0 001.9.3H10a1.7 1.7 0 001-1.5V4a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.9-.3l.1-.1a2 2 0 112.9 2.9l-.1.1a1.7 1.7 0 00-.3 1.9V10c.4.4.9.7 1.5.7H20a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"
      stroke="currentColor"
      strokeWidth="1.3"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  ),
};

export function Sidebar({ businessName, bookingSlug }: { businessName: string; bookingSlug: string }) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-ink-200 bg-white">
      <div className="border-b border-ink-100 px-5 py-5">
        <p className="font-display text-lg font-semibold text-ink-900">BookFlow</p>
        <p className="mt-0.5 truncate text-xs text-ink-400">{businessName}</p>
      </div>
      <nav className="flex-1 space-y-0.5 px-3 py-4">
        {LINKS.map((link) => {
          const active = link.href === "/dashboard" ? pathname === link.href : pathname?.startsWith(link.href);
          return (
            <Link
              key={link.href}
              href={link.href}
              className={clsx(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                active ? "bg-pine-50 text-pine-800" : "text-ink-600 hover:bg-paper-100"
              )}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden>
                {ICONS[link.icon]}
              </svg>
              {link.label}
            </Link>
          );
        })}
      </nav>
      <div className="space-y-2 border-t border-ink-100 p-4">
        <a
          href={`/book/${bookingSlug}`}
          target="_blank"
          rel="noreferrer"
          className="flex items-center justify-center gap-2 rounded-lg border border-ink-200 px-3 py-2 text-sm font-medium text-ink-700 hover:bg-paper-100"
        >
          Open booking page ↗
        </a>
        <button onClick={logout} className="w-full rounded-lg px-3 py-2 text-left text-sm font-medium text-ink-500 hover:bg-paper-100">
          Log out
        </button>
      </div>
    </aside>
  );
}
