"use client";

import { useState } from "react";
import Link from "next/link";
import { NewAppointmentModal } from "@/components/dashboard/NewAppointmentModal";
import { NewCustomerModal } from "@/components/dashboard/NewCustomerModal";

export function QuickActions({ bookingSlug }: { bookingSlug: string }) {
  const [modal, setModal] = useState<"appointment" | "customer" | null>(null);

  const actions = [
    { label: "New appointment", onClick: () => setModal("appointment"), icon: "＋" },
    { label: "Add customer", onClick: () => setModal("customer"), icon: "＋" },
    { label: "Add service", href: "/dashboard/services", icon: "→" },
    { label: "Open booking page", href: `/book/${bookingSlug}`, external: true, icon: "↗" },
    { label: "Business settings", href: "/dashboard/settings", icon: "→" },
  ];

  return (
    <>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {actions.map((a) =>
          a.href ? (
            <Link
              key={a.label}
              href={a.href}
              target={a.external ? "_blank" : undefined}
              rel={a.external ? "noreferrer" : undefined}
              className="flex items-center justify-between rounded-xl border border-ink-200 bg-white px-4 py-3 text-sm font-medium text-ink-700 shadow-card hover:border-pine-300"
            >
              {a.label} <span className="text-ink-400">{a.icon}</span>
            </Link>
          ) : (
            <button
              key={a.label}
              onClick={a.onClick}
              className="flex items-center justify-between rounded-xl border border-ink-200 bg-white px-4 py-3 text-left text-sm font-medium text-ink-700 shadow-card hover:border-pine-300"
            >
              {a.label} <span className="text-ink-400">{a.icon}</span>
            </button>
          )
        )}
      </div>
      <NewAppointmentModal open={modal === "appointment"} onClose={() => setModal(null)} />
      <NewCustomerModal open={modal === "customer"} onClose={() => setModal(null)} />
    </>
  );
}
