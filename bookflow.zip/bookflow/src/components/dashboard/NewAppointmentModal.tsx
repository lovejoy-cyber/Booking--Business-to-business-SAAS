"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { Input, Label, Select, ErrorText, Textarea } from "@/components/ui/Field";
import { formatMoney, formatDuration } from "@/lib/format";

interface Service {
  id: string;
  name: string;
  priceCents: number;
  durationMinutes: number;
}
interface Employee {
  id: string;
  name: string;
}
interface CustomerOption {
  id: string;
  name: string;
  whatsappE164: string;
}

export function NewAppointmentModal({
  open,
  onClose,
  defaultDate,
}: {
  open: boolean;
  onClose: () => void;
  defaultDate?: string;
}) {
  const router = useRouter();
  const [services, setServices] = useState<Service[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [customers, setCustomers] = useState<CustomerOption[]>([]);

  const [customerMode, setCustomerMode] = useState<"existing" | "new">("new");
  const [customerId, setCustomerId] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [serviceId, setServiceId] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [date, setDate] = useState(defaultDate ?? new Date().toISOString().slice(0, 10));
  const [slots, setSlots] = useState<string[]>([]);
  const [selectedSlot, setSelectedSlot] = useState("");
  const [notes, setNotes] = useState("");
  const [timezone, setTimezone] = useState("UTC");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [slotsLoading, setSlotsLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    fetch("/api/services").then((r) => r.json()).then((d) => setServices(d.services ?? []));
    fetch("/api/employees").then((r) => r.json()).then((d) => setEmployees(d.employees ?? []));
    fetch("/api/customers").then((r) => r.json()).then((d) => setCustomers(d.customers ?? []));
  }, [open]);

  useEffect(() => {
    if (!serviceId || !date) return;
    setSlotsLoading(true);
    setSelectedSlot("");
    const qs = new URLSearchParams({ serviceId, date, ...(employeeId ? { employeeId } : {}) });
    fetch(`/api/availability?${qs}`)
      .then((r) => r.json())
      .then((d) => {
        setSlots(d.slots ?? []);
        setTimezone(d.timezone ?? "UTC");
      })
      .finally(() => setSlotsLoading(false));
  }, [serviceId, employeeId, date]);

  if (!open) return null;

  async function onSubmit() {
    setError(null);
    if (!serviceId || !selectedSlot) {
      setError("Choose a service and a time slot.");
      return;
    }
    if (customerMode === "existing" && !customerId) {
      setError("Choose a customer, or switch to 'New customer'.");
      return;
    }
    if (customerMode === "new" && (!customerName || !customerPhone)) {
      setError("Enter the customer's name and WhatsApp number.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          serviceId,
          employeeId: employeeId || undefined,
          startsAt: selectedSlot,
          notes: notes || undefined,
          ...(customerMode === "existing"
            ? { customerId }
            : { customer: { name: customerName, whatsappE164: customerPhone } }),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not create the appointment.");
      router.refresh();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create the appointment.");
    } finally {
      setLoading(false);
    }
  }

  const selectedService = services.find((s) => s.id === serviceId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/50 px-4" role="dialog" aria-modal>
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-floating">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold text-ink-900">New appointment</h2>
          <button onClick={onClose} aria-label="Close" className="rounded-full p-1 text-ink-400 hover:bg-paper-100">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <Label>Customer</Label>
            <div className="mb-2 flex gap-2">
              <button
                type="button"
                onClick={() => setCustomerMode("new")}
                className={`rounded-full px-3 py-1 text-xs font-medium ${customerMode === "new" ? "bg-pine-700 text-white" : "bg-paper-100 text-ink-600"}`}
              >
                New customer
              </button>
              <button
                type="button"
                onClick={() => setCustomerMode("existing")}
                className={`rounded-full px-3 py-1 text-xs font-medium ${customerMode === "existing" ? "bg-pine-700 text-white" : "bg-paper-100 text-ink-600"}`}
              >
                Existing customer
              </button>
            </div>
            {customerMode === "new" ? (
              <div className="grid grid-cols-2 gap-3">
                <Input placeholder="Name" value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
                <Input placeholder="+15551234567" value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} />
              </div>
            ) : (
              <Select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
                <option value="">Select a customer…</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} · {c.whatsappE164}
                  </option>
                ))}
              </Select>
            )}
          </div>

          <div>
            <Label>Service</Label>
            <Select value={serviceId} onChange={(e) => setServiceId(e.target.value)}>
              <option value="">Select a service…</option>
              {services.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} — {formatMoney(s.priceCents)} · {formatDuration(s.durationMinutes)}
                </option>
              ))}
            </Select>
          </div>

          {employees.length > 0 && (
            <div>
              <Label hint="optional">Staff member</Label>
              <Select value={employeeId} onChange={(e) => setEmployeeId(e.target.value)}>
                <option value="">Any available</option>
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name}
                  </option>
                ))}
              </Select>
            </div>
          )}

          <div>
            <Label>Date</Label>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>

          {serviceId && (
            <div>
              <Label>Time</Label>
              {slotsLoading ? (
                <p className="text-sm text-ink-400">Loading available times…</p>
              ) : slots.length === 0 ? (
                <p className="text-sm text-ink-400">No available times on this date.</p>
              ) : (
                <div className="grid grid-cols-4 gap-2">
                  {slots.map((slot) => {
                    const label = new Intl.DateTimeFormat("en-US", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: timezone }).format(new Date(slot));
                    return (
                      <button
                        key={slot}
                        type="button"
                        onClick={() => setSelectedSlot(slot)}
                        className={`rounded-lg border px-2 py-1.5 text-sm ${
                          selectedSlot === slot ? "border-pine-700 bg-pine-700 text-white" : "border-ink-200 text-ink-700 hover:border-pine-300"
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          <div>
            <Label hint="optional">Notes</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
          </div>

          {selectedService && (
            <p className="text-xs text-ink-400">
              {selectedService.name} · {formatDuration(selectedService.durationMinutes)} · {formatMoney(selectedService.priceCents)}
            </p>
          )}

          <ErrorText>{error}</ErrorText>

          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={onClose} type="button">
              Cancel
            </Button>
            <Button onClick={onSubmit} loading={loading} type="button">
              Book appointment
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
