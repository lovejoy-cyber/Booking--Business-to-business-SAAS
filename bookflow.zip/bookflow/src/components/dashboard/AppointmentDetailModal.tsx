"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { Input, Label, ErrorText, Textarea } from "@/components/ui/Field";
import { Badge, statusTone } from "@/components/ui/Badge";
import { formatMoney, formatInTz, formatDuration } from "@/lib/format";

export interface AppointmentSummary {
  id: string;
  startsAt: string;
  endsAt: string;
  status: string;
  priceCents: number;
  notes: string | null;
  customer: { id: string; name: string; whatsappE164: string };
  service: { id: string; name: string; durationMinutes: number };
  employee: { id: string; name: string } | null;
}

export function AppointmentDetailModal({
  appointment,
  timezone,
  currency,
  onClose,
}: {
  appointment: AppointmentSummary | null;
  timezone: string;
  currency: string;
  onClose: () => void;
}) {
  const router = useRouter();
  const [mode, setMode] = useState<"view" | "reschedule" | "cancel">("view");
  const [newDate, setNewDate] = useState("");
  const [newTime, setNewTime] = useState("");
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setMode("view");
    setError(null);
    if (appointment) {
      setNewDate(appointment.startsAt.slice(0, 10));
      setNewTime(formatInTz(appointment.startsAt, timezone, "HH:mm"));
    }
  }, [appointment, timezone]);

  if (!appointment) return null;

  async function callAction(path: string, body?: Record<string, unknown>) {
    setError(null);
    setLoading(true);
    try {
      const res = await fetch(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body ?? {}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Action failed.");
      router.refresh();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Action failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/50 px-4" role="dialog" aria-modal>
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-floating">
        <div className="mb-4 flex items-start justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-ink-400">
              {formatInTz(appointment.startsAt, timezone, "EEEE, d MMMM · HH:mm")}
            </p>
            <h2 className="font-display text-xl font-semibold text-ink-900">{appointment.customer.name}</h2>
          </div>
          <Badge tone={statusTone(appointment.status)}>{appointment.status.replace("_", "-")}</Badge>
        </div>

        {mode === "view" && (
          <div className="space-y-3 text-sm">
            <Row label="Service" value={`${appointment.service.name} · ${formatDuration(appointment.service.durationMinutes)}`} />
            <Row label="Price" value={formatMoney(appointment.priceCents, currency)} />
            {appointment.employee && <Row label="Staff" value={appointment.employee.name} />}
            <Row label="WhatsApp" value={appointment.customer.whatsappE164} />
            {appointment.notes && <Row label="Notes" value={appointment.notes} />}

            <ErrorText>{error}</ErrorText>

            {(appointment.status === "CONFIRMED" || appointment.status === "PENDING") && (
              <div className="grid grid-cols-2 gap-2 pt-3">
                <Button variant="secondary" size="sm" onClick={() => setMode("reschedule")} type="button">
                  Reschedule
                </Button>
                <Button variant="secondary" size="sm" onClick={() => setMode("cancel")} type="button">
                  Cancel
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  loading={loading}
                  onClick={() => callAction(`/api/appointments/${appointment.id}/complete`)}
                  type="button"
                >
                  Mark completed
                </Button>
                <Button
                  variant="danger"
                  size="sm"
                  loading={loading}
                  onClick={() => callAction(`/api/appointments/${appointment.id}/no-show`)}
                  type="button"
                >
                  Mark no-show
                </Button>
              </div>
            )}
          </div>
        )}

        {mode === "reschedule" && (
          <div className="space-y-3">
            <div>
              <Label htmlFor="r-date">New date</Label>
              <Input id="r-date" type="date" value={newDate} onChange={(e) => setNewDate(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="r-time">New time</Label>
              <Input id="r-time" type="time" value={newTime} onChange={(e) => setNewTime(e.target.value)} />
            </div>
            <ErrorText>{error}</ErrorText>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="secondary" size="sm" onClick={() => setMode("view")} type="button">
                Back
              </Button>
              <Button
                size="sm"
                loading={loading}
                type="button"
                onClick={() => {
                  const iso = new Date(`${newDate}T${newTime}:00`).toISOString();
                  callAction(`/api/appointments/${appointment.id}/reschedule`, { startsAt: iso });
                }}
              >
                Confirm new time
              </Button>
            </div>
          </div>
        )}

        {mode === "cancel" && (
          <div className="space-y-3">
            <div>
              <Label hint="optional">Reason</Label>
              <Textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={2} placeholder="Customer requested to cancel…" />
            </div>
            <ErrorText>{error}</ErrorText>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="secondary" size="sm" onClick={() => setMode("view")} type="button">
                Back
              </Button>
              <Button
                variant="danger"
                size="sm"
                loading={loading}
                type="button"
                onClick={() => callAction(`/api/appointments/${appointment.id}/cancel`, { reason: reason || undefined })}
              >
                Confirm cancellation
              </Button>
            </div>
          </div>
        )}

        <button onClick={onClose} className="mt-5 w-full text-center text-sm text-ink-400 hover:text-ink-600">
          Close
        </button>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-ink-100 pb-2">
      <span className="text-ink-400">{label}</span>
      <span className="font-medium text-ink-800">{value}</span>
    </div>
  );
}
