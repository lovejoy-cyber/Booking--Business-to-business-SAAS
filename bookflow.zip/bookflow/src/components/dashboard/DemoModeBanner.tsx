import Link from "next/link";

export function DemoModeBanner() {
  return (
    <div className="flex items-center justify-center gap-3 border-b border-brass-200 bg-brass-50 px-4 py-2 text-sm text-brass-800">
      <span className="h-1.5 w-1.5 rounded-full bg-brass-400" aria-hidden />
      <span>
        You're in demo mode — WhatsApp messages are simulated, not sent.{" "}
        <Link href="/dashboard/settings#whatsapp" className="font-medium underline underline-offset-2">
          Connect WhatsApp
        </Link>{" "}
        to go live.
      </span>
    </div>
  );
}
