import { format } from "date-fns";
import { utcToZonedTime } from "date-fns-tz";
import type { NotificationType } from "@prisma/client";

interface TemplateContext {
  businessName: string;
  timezone: string;
  startsAt: Date;
  /** Only used for RESCHEDULE messages. */
  previousStartsAt?: Date;
}

function fmtDate(d: Date, tz: string) {
  return format(utcToZonedTime(d, tz), "EEEE, d MMMM");
}
function fmtTime(d: Date, tz: string) {
  return format(utcToZonedTime(d, tz), "HH:mm");
}

/**
 * Renders the exact copy specified in the product brief. In production these
 * map 1:1 to pre-approved WhatsApp message templates (Cloud API requires
 * approved templates for business-initiated messages outside the 24h
 * customer-service window) — see WHATSAPP_TEMPLATE_NAMES below and the
 * README's WhatsApp Configuration section.
 */
export function renderMessage(type: NotificationType, ctx: TemplateContext): string {
  const date = fmtDate(ctx.startsAt, ctx.timezone);
  const time = fmtTime(ctx.startsAt, ctx.timezone);

  switch (type) {
    case "BOOKING_CONFIRMATION":
      return `Your appointment with ${ctx.businessName} is confirmed for ${date} at ${time}.`;
    case "REMINDER_24H":
      return `Reminder: you have an appointment with ${ctx.businessName} tomorrow at ${time}.`;
    case "REMINDER_SAME_DAY":
      return `Reminder: your appointment with ${ctx.businessName} is today at ${time}.`;
    case "CANCELLATION":
      return `Your appointment with ${ctx.businessName} on ${date} at ${time} has been cancelled.`;
    case "RESCHEDULE":
      return `Your appointment has been moved to ${date} at ${time}.`;
    default:
      return `You have an update from ${ctx.businessName}.`;
  }
}

/**
 * Names of the pre-approved WhatsApp message templates a business must create
 * in Meta Business Manager before going live in production mode. The Cloud
 * API client (client.ts) references these when isDemoMode is false.
 */
export const WHATSAPP_TEMPLATE_NAMES: Record<NotificationType, string> = {
  BOOKING_CONFIRMATION: "bookflow_booking_confirmation",
  REMINDER_24H: "bookflow_reminder_24h",
  REMINDER_SAME_DAY: "bookflow_reminder_same_day",
  CANCELLATION: "bookflow_cancellation",
  RESCHEDULE: "bookflow_reschedule",
};

/**
 * Body variables ({{1}}, {{2}}, ...) each approved template expects, in
 * order. Keep this in sync with the templates you actually submit to Meta —
 * these are the parameters the Cloud API client substitutes at send time.
 */
export function getTemplateParams(type: NotificationType, ctx: TemplateContext): string[] {
  const date = fmtDate(ctx.startsAt, ctx.timezone);
  const time = fmtTime(ctx.startsAt, ctx.timezone);

  switch (type) {
    case "BOOKING_CONFIRMATION":
      return [ctx.businessName, date, time];
    case "REMINDER_24H":
      return [ctx.businessName, time];
    case "REMINDER_SAME_DAY":
      return [ctx.businessName, time];
    case "CANCELLATION":
      return [ctx.businessName, date, time];
    case "RESCHEDULE":
      return [date, time];
    default:
      return [ctx.businessName];
  }
}
