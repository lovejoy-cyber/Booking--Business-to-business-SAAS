import { db } from "@/lib/db";
import { renderMessage, getTemplateParams, WHATSAPP_TEMPLATE_NAMES } from "@/lib/whatsapp/templates";
import { sendWhatsAppTemplateMessage } from "@/lib/whatsapp/client";
import { simulateSend } from "@/lib/whatsapp/demo";
import { decryptSecret } from "@/lib/crypto";
import type { Appointment, Business, Customer, NotificationType } from "@prisma/client";

/**
 * Creates a queued Notification row. Nothing is sent synchronously here —
 * a temporary WhatsApp API outage must never be able to fail (or roll back)
 * an appointment booking. `processPendingNotifications` (below) is invoked
 * by the /api/notifications/process endpoint, which in production should be
 * hit by a scheduled job every 1-2 minutes (see README § Deployment).
 */
export async function enqueueNotification(params: {
  business: Business;
  appointment: Appointment;
  customer: Customer;
  type: NotificationType;
  scheduledFor?: Date;
  previousStartsAt?: Date;
}) {
  const { business, appointment, customer, type, scheduledFor, previousStartsAt } = params;

  const message = renderMessage(type, {
    businessName: business.name,
    timezone: business.timezone,
    startsAt: appointment.startsAt,
    previousStartsAt,
  });

  return db.notification.create({
    data: {
      businessId: business.id,
      appointmentId: appointment.id,
      type,
      recipientPhone: customer.whatsappE164,
      message,
      isDemo: business.isDemoMode,
      scheduledFor: scheduledFor ?? new Date(),
      status: "PENDING",
    },
  });
}

interface ProcessResult {
  processed: number;
  sent: number;
  failed: number;
}

/**
 * Drains up to `limit` due notifications. Safe to call repeatedly/concurrently
 * — each notification is claimed via a status transition before sending, and
 * `attempts` is tracked so a persistently-failing send doesn't loop forever.
 */
export async function processPendingNotifications(limit = 25): Promise<ProcessResult> {
  const due = await db.notification.findMany({
    where: { status: "PENDING", scheduledFor: { lte: new Date() }, attempts: { lt: 5 } },
    orderBy: { scheduledFor: "asc" },
    take: limit,
    include: { business: { include: { whatsappConfig: true } } },
  });

  let sent = 0;
  let failed = 0;

  for (const notification of due) {
    const { business } = notification;

    try {
      if (business.isDemoMode || !business.whatsappConfig?.isConfigured) {
        const result = simulateSend();
        await db.notification.update({
          where: { id: notification.id },
          data: {
            status: "DELIVERED", // demo mode simulates instant delivery
            isDemo: true,
            providerMessageId: result.providerMessageId,
            sentAt: new Date(),
            deliveredAt: new Date(),
            attempts: { increment: 1 },
          },
        });
        sent++;
        continue;
      }

      const config = business.whatsappConfig;
      if (!config?.phoneNumberId || !config.accessTokenCiphertext) {
        throw new Error("WhatsApp is not fully configured for this business.");
      }

      const appointment = notification.appointmentId
        ? await db.appointment.findUnique({ where: { id: notification.appointmentId } })
        : null;

      const bodyParams = appointment
        ? getTemplateParams(notification.type, {
            businessName: business.name,
            timezone: business.timezone,
            startsAt: appointment.startsAt,
          })
        : [business.name];

      const accessToken = decryptSecret(config.accessTokenCiphertext);
      const result = await sendWhatsAppTemplateMessage({
        phoneNumberId: config.phoneNumberId,
        accessToken,
        to: notification.recipientPhone,
        templateName: WHATSAPP_TEMPLATE_NAMES[notification.type],
        bodyParams,
      });

      if (result.success) {
        await db.notification.update({
          where: { id: notification.id },
          data: {
            status: "SENT",
            providerMessageId: result.providerMessageId,
            sentAt: new Date(),
            attempts: { increment: 1 },
          },
        });
        sent++;
      } else {
        await db.notification.update({
          where: { id: notification.id },
          data: {
            status: "FAILED",
            errorMessage: result.errorMessage?.slice(0, 500),
            attempts: { increment: 1 },
          },
        });
        failed++;
      }
    } catch (err) {
      await db.notification.update({
        where: { id: notification.id },
        data: {
          status: "FAILED",
          errorMessage: (err instanceof Error ? err.message : "Unknown error").slice(0, 500),
          attempts: { increment: 1 },
        },
      });
      failed++;
    }
  }

  return { processed: due.length, sent, failed };
}

/** Called by the WhatsApp webhook when a delivery-status update arrives. */
export async function markDeliveredByProviderId(providerMessageId: string) {
  await db.notification.updateMany({
    where: { providerMessageId, status: "SENT" },
    data: { status: "DELIVERED", deliveredAt: new Date() },
  });
}
