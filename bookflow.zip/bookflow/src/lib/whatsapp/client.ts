/**
 * Thin wrapper around the official WhatsApp Business Cloud API
 * (Meta Graph API `/{phone-number-id}/messages`). This file is the ONLY
 * place that should ever see a raw WhatsApp access token — it is read from
 * an environment variable / decrypted config server-side and is never sent
 * to the frontend, logged, or stored in plaintext.
 *
 * Deliberately NOT implemented: WhatsApp Web automation, headless browser
 * QR-code login, or any unofficial/reverse-engineered API. Those violate
 * WhatsApp's Terms of Service and are out of scope for this product.
 */

export interface SendTemplateMessageParams {
  phoneNumberId: string;
  accessToken: string;
  to: string; // E.164
  templateName: string;
  bodyParams: string[];
  languageCode?: string;
}

export interface WhatsAppSendResult {
  success: boolean;
  providerMessageId?: string;
  errorMessage?: string;
}

const GRAPH_API_VERSION = "v20.0";

export async function sendWhatsAppTemplateMessage(
  params: SendTemplateMessageParams
): Promise<WhatsAppSendResult> {
  const { phoneNumberId, accessToken, to, templateName, bodyParams, languageCode = "en_US" } = params;

  const url = `https://graph.facebook.com/${GRAPH_API_VERSION}/${phoneNumberId}/messages`;

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "template",
        template: {
          name: templateName,
          language: { code: languageCode },
          components: [
            {
              type: "body",
              parameters: bodyParams.map((text) => ({ type: "text", text })),
            },
          ],
        },
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      return {
        success: false,
        errorMessage: data?.error?.message ?? `WhatsApp API error (HTTP ${res.status})`,
      };
    }

    const providerMessageId: string | undefined = data?.messages?.[0]?.id;
    return { success: true, providerMessageId };
  } catch (err) {
    return {
      success: false,
      errorMessage: err instanceof Error ? err.message : "Unknown network error contacting WhatsApp API.",
    };
  }
}

/** Verifies the `hub.verify_token` handshake WhatsApp performs when a
 *  business first configures its webhook URL in Meta's dashboard. */
export function verifyWebhookChallenge(
  mode: string | null,
  token: string | null,
  expectedToken: string
): boolean {
  return mode === "subscribe" && token === expectedToken;
}

/**
 * Verifies the X-Hub-Signature-256 header WhatsApp attaches to every webhook
 * delivery, using the Meta App Secret. Prevents forged delivery-status/inbound
 * webhooks from being trusted.
 */
export async function verifyWebhookSignature(
  rawBody: string,
  signatureHeader: string | null,
  appSecret: string
): Promise<boolean> {
  if (!signatureHeader?.startsWith("sha256=")) return false;
  const expectedHex = signatureHeader.slice("sha256=".length);

  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(appSecret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const mac = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(rawBody));
  const computedHex = Array.from(new Uint8Array(mac))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  // Constant-time-ish comparison.
  if (computedHex.length !== expectedHex.length) return false;
  let diff = 0;
  for (let i = 0; i < computedHex.length; i++) diff |= computedHex.charCodeAt(i) ^ expectedHex.charCodeAt(i);
  return diff === 0;
}
