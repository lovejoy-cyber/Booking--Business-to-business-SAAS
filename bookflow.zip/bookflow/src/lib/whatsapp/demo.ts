/**
 * Demo-mode notification "sender". Used whenever a business has no live
 * WhatsApp credentials configured (isDemoMode = true, the default for new
 * businesses). Nothing here ever contacts a real API — it simulates a
 * realistic send/deliver lifecycle so the product can be demoed to a
 * prospective customer end-to-end before they've set up Meta's Cloud API.
 *
 * Production sends must NEVER go through this path — src/lib/whatsapp/service.ts
 * branches strictly on `business.isDemoMode`, and turning it off requires a
 * business to have completed real WhatsApp Cloud API configuration.
 */
export interface DemoSendResult {
  success: true;
  providerMessageId: string;
}

export function simulateSend(): DemoSendResult {
  return { success: true, providerMessageId: `demo_${Math.random().toString(36).slice(2, 12)}` };
}
