import { z } from "zod";

// E.164: +[country code][number], 8-15 digits total after the plus sign.
export const e164Phone = z
  .string()
  .trim()
  .regex(/^\+[1-9]\d{7,14}$/, "Enter a valid WhatsApp number in international format, e.g. +15551234567");

export const registerSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(200),
  password: z.string().min(8, "Password must be at least 8 characters").max(200),
  businessName: z.string().trim().min(2).max(150),
  businessType: z.enum(["BARBER", "SALON", "TUTOR", "MECHANIC", "PHOTOGRAPHER", "REPAIR", "OTHER"]),
});

export const loginSchema = z.object({
  email: z.string().trim().email(),
  password: z.string().min(1),
});

export const serviceSchema = z.object({
  name: z.string().trim().min(1).max(150),
  description: z.string().trim().max(1000).optional().nullable(),
  priceCents: z.number().int().min(0).max(100_000_00),
  durationMinutes: z.number().int().min(5).max(60 * 8),
  isActive: z.boolean().optional(),
});

export const workingHourSchema = z.object({
  employeeId: z.string().optional().nullable(),
  dayOfWeek: z.number().int().min(0).max(6),
  startTime: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/),
  endTime: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/),
  isClosed: z.boolean().optional(),
});

export const blockedTimeSchema = z.object({
  employeeId: z.string().optional().nullable(),
  startsAt: z.string().datetime(),
  endsAt: z.string().datetime(),
  reason: z.string().trim().max(300).optional().nullable(),
});

export const customerSchema = z.object({
  name: z.string().trim().min(1).max(150),
  whatsappE164: e164Phone,
  notes: z.string().trim().max(2000).optional().nullable(),
});

export const createAppointmentSchema = z.object({
  customerId: z.string().optional(), // existing customer
  customer: z
    .object({ name: z.string().trim().min(1).max(150), whatsappE164: e164Phone })
    .optional(), // or inline new-customer details (public booking flow)
  serviceId: z.string(),
  employeeId: z.string().optional().nullable(),
  startsAt: z.string().datetime(),
  notes: z.string().trim().max(1000).optional().nullable(),
});

export const publicBookingSchema = z.object({
  serviceId: z.string(),
  employeeId: z.string().optional().nullable(),
  startsAt: z.string().datetime(),
  customerName: z.string().trim().min(1).max(150),
  whatsappE164: e164Phone,
  notes: z.string().trim().max(500).optional().nullable(),
});

export const rescheduleSchema = z.object({
  startsAt: z.string().datetime(),
  employeeId: z.string().optional().nullable(),
});

export const cancelSchema = z.object({
  reason: z.string().trim().max(300).optional().nullable(),
});

export const businessSettingsSchema = z.object({
  name: z.string().trim().min(2).max(150).optional(),
  description: z.string().trim().max(1000).optional().nullable(),
  logoUrl: z.string().url().max(500).optional().nullable(),
  address: z.string().trim().max(300).optional().nullable(),
  phone: z.string().trim().max(30).optional().nullable(),
  currency: z.string().trim().length(3).optional(),
  timezone: z.string().trim().max(80).optional(),
  slotIntervalMinutes: z.number().int().min(5).max(120).optional(),
  minLeadTimeMinutes: z.number().int().min(0).max(1440).optional(),
  maxAdvanceBookingDays: z.number().int().min(1).max(365).optional(),
  cancellationPolicy: z.string().trim().max(2000).optional().nullable(),
});

export const whatsappConfigSchema = z.object({
  phoneNumberId: z.string().trim().min(1).max(200),
  wabaId: z.string().trim().min(1).max(200),
  accessToken: z.string().trim().min(1).max(2000),
});
