import { format } from "date-fns";
import { utcToZonedTime } from "date-fns-tz";

export function formatMoney(cents: number, currency = "USD"): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency, minimumFractionDigits: 0 }).format(cents / 100);
}

export function formatInTz(date: Date | string, timezone: string, pattern: string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return format(utcToZonedTime(d, timezone), pattern);
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m ? `${h}h ${m}m` : `${h}h`;
}

export function initials(name: string): string {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}
