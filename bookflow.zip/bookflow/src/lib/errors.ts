import { NextResponse } from "next/server";
import { ZodError } from "zod";

/**
 * AppError is the only error type allowed to leak a message to the client.
 * Anything else (Prisma errors, TypeErrors, etc.) is logged server-side and
 * replaced with a generic message — we never return stack traces or raw
 * driver errors to the browser.
 */
export class AppError extends Error {
  status: number;
  code: string;

  constructor(message: string, status = 400, code = "BAD_REQUEST") {
    super(message);
    this.status = status;
    this.code = code;
  }

  static badRequest(message: string) {
    return new AppError(message, 400, "BAD_REQUEST");
  }
  static unauthorized(message = "You must be signed in.") {
    return new AppError(message, 401, "UNAUTHORIZED");
  }
  static forbidden(message = "You don't have access to this resource.") {
    return new AppError(message, 403, "FORBIDDEN");
  }
  static notFound(message = "Not found.") {
    return new AppError(message, 404, "NOT_FOUND");
  }
  static conflict(message: string) {
    return new AppError(message, 409, "CONFLICT");
  }
  static tooMany(message = "Too many requests. Please slow down.") {
    return new AppError(message, 429, "RATE_LIMITED");
  }
}

/** Wrap a route handler body so every thrown error becomes a safe JSON response. */
export function handleApiError(err: unknown): NextResponse {
  if (err instanceof AppError) {
    return NextResponse.json({ error: err.message, code: err.code }, { status: err.status });
  }
  if (err instanceof ZodError) {
    return NextResponse.json(
      { error: err.errors[0]?.message ?? "Invalid input.", code: "VALIDATION_ERROR" },
      { status: 400 }
    );
  }
  // Unexpected error: log full detail server-side, return only a generic message.
  console.error("[unhandled_api_error]", err);
  return NextResponse.json(
    { error: "Something went wrong. Please try again.", code: "INTERNAL_ERROR" },
    { status: 500 }
  );
}
