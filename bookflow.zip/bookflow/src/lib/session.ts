import { cache } from "react";
import { db } from "@/lib/db";
import { getSessionFromCookies } from "@/lib/auth";
import { AppError } from "@/lib/errors";

/**
 * Resolves the current signed-in user from the session cookie, memoized per
 * request via React `cache` so multiple server components/route calls in the
 * same request don't hit the database repeatedly.
 */
export const getCurrentUser = cache(async () => {
  const session = await getSessionFromCookies();
  if (!session) return null;

  const user = await db.user.findUnique({
    where: { id: session.userId },
    select: { id: true, email: true, name: true, platformRole: true, createdAt: true },
  });
  return user;
});

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw AppError.unauthorized();
  return user;
}

export async function requireSuperAdmin() {
  const user = await requireUser();
  if (user.platformRole !== "SUPER_ADMIN") throw AppError.forbidden("Admin access required.");
  return user;
}
