import { AppError } from "@/lib/errors";

/**
 * Minimal in-memory sliding-window rate limiter.
 *
 * This is intentionally simple and good enough for a single-instance MVP
 * demo. It resets on deploy/restart and does not coordinate across multiple
 * server instances — for a horizontally-scaled production deployment, swap
 * this module for a shared store (e.g. Upstash Redis) behind the same
 * `checkRateLimit` function signature.
 */
const buckets = new Map<string, { count: number; resetAt: number }>();

export function checkRateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const bucket = buckets.get(key);

  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }

  if (bucket.count >= limit) {
    throw AppError.tooMany();
  }

  bucket.count += 1;
}

/** Periodically evict stale buckets so the map doesn't grow unbounded. */
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of buckets.entries()) {
    if (bucket.resetAt < now) buckets.delete(key);
  }
}, 60_000).unref?.();
