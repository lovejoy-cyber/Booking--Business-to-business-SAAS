import type { SubscriptionPlan } from "@prisma/client";

/**
 * Plan catalog. `priceId` maps each paid plan to a Stripe Price object —
 * create these in the Stripe dashboard (or via `stripe prices create`) and
 * set the env vars below. FREE_TRIAL has no Stripe price; it's assigned
 * automatically at registration and never touches Stripe until the business
 * upgrades.
 *
 * `appointmentLimit`/`staffLimit` of -1 means unlimited. Limits are enforced
 * in src/lib/billing/subscription.ts, called from the booking and staff
 * creation code paths — never trust a plan name from the client, only the
 * business's own Subscription row.
 */
export interface PlanDefinition {
  key: SubscriptionPlan;
  name: string;
  priceCents: number; // 0 for FREE_TRIAL
  appointmentLimit: number;
  staffLimit: number;
  priceId: string | null;
}

export const PLANS: Record<SubscriptionPlan, PlanDefinition> = {
  FREE_TRIAL: {
    key: "FREE_TRIAL",
    name: "Free Trial",
    priceCents: 0,
    appointmentLimit: 30,
    staffLimit: 1,
    priceId: null,
  },
  STARTER: {
    key: "STARTER",
    name: "Starter",
    priceCents: 1900,
    appointmentLimit: 100,
    staffLimit: 1,
    priceId: process.env.STRIPE_PRICE_STARTER ?? null,
  },
  PROFESSIONAL: {
    key: "PROFESSIONAL",
    name: "Professional",
    priceCents: 3900,
    appointmentLimit: 400,
    staffLimit: 3,
    priceId: process.env.STRIPE_PRICE_PROFESSIONAL ?? null,
  },
  BUSINESS: {
    key: "BUSINESS",
    name: "Business",
    priceCents: 7900,
    appointmentLimit: -1,
    staffLimit: -1,
    priceId: process.env.STRIPE_PRICE_BUSINESS ?? null,
  },
};

export function planByPriceId(priceId: string): PlanDefinition | null {
  return Object.values(PLANS).find((p) => p.priceId === priceId) ?? null;
}
