import { db } from "@/lib/db";
import { AppError } from "@/lib/errors";
import { PLANS, planByPriceId } from "@/lib/billing/plans";
import type { Business, Subscription } from "@prisma/client";
import type Stripe from "stripe";

/** Appointments created within the current billing period count against the
 *  plan's limit — regardless of later status — because each one occupied a
 *  real slot on the calendar and cost the business a WhatsApp send. */
export async function getAppointmentUsage(businessId: string, subscription: Subscription): Promise<number> {
  return db.appointment.count({
    where: { businessId, createdAt: { gte: subscription.currentPeriodStartsAt } },
  });
}

export async function getUsageSummary(businessId: string) {
  const subscription = await db.subscription.findUnique({ where: { businessId } });
  if (!subscription) throw AppError.notFound("No subscription found for this business.");

  const used = await getAppointmentUsage(businessId, subscription);
  const plan = PLANS[subscription.plan];

  return {
    subscription,
    plan,
    appointmentsUsed: used,
    appointmentsRemaining: plan.appointmentLimit === -1 ? null : Math.max(0, plan.appointmentLimit - used),
    isOverLimit: plan.appointmentLimit !== -1 && used >= plan.appointmentLimit,
  };
}

/** Called from createAppointment() before a new booking is written. Throws
 *  a clear, actionable error rather than silently allowing unlimited overage. */
export async function enforceAppointmentLimit(business: Business): Promise<void> {
  const subscription = await db.subscription.findUnique({ where: { businessId: business.id } });
  if (!subscription) return; // no subscription row (shouldn't happen post-registration) — fail open rather than blocking bookings

  if (subscription.status === "CANCELLED") {
    throw AppError.forbidden("This business's subscription has been cancelled. Reactivate billing to keep taking bookings.");
  }

  const plan = PLANS[subscription.plan];
  if (plan.appointmentLimit === -1) return;

  const used = await getAppointmentUsage(business.id, subscription);
  if (used >= plan.appointmentLimit) {
    throw AppError.forbidden(
      `This business has reached its ${plan.name} plan limit of ${plan.appointmentLimit} appointments this period. Upgrade in Settings → Billing to keep taking bookings.`
    );
  }
}

/** Called from the employees.create route. */
export async function enforceStaffLimit(businessId: string): Promise<void> {
  const subscription = await db.subscription.findUnique({ where: { businessId } });
  if (!subscription) return;

  const plan = PLANS[subscription.plan];
  if (plan.staffLimit === -1) return;

  const count = await db.employee.count({ where: { businessId, isActive: true } });
  if (count >= plan.staffLimit) {
    throw AppError.forbidden(
      `This business's ${plan.name} plan allows up to ${plan.staffLimit} staff member${plan.staffLimit === 1 ? "" : "s"}. Upgrade in Settings → Billing to add more.`
    );
  }
}

/**
 * Applies a Stripe subscription object to our own Subscription row. Called
 * from the checkout-completion and subscription-updated webhook handlers —
 * this is the ONLY place plan/status transitions happen from Stripe data, so
 * webhook handling and manual reconciliation can't drift apart.
 */
export async function syncSubscriptionFromStripe(businessId: string, stripeSub: Stripe.Subscription) {
  const priceId = stripeSub.items.data[0]?.price.id;
  const matchedPlan = priceId ? planByPriceId(priceId) : null;

  const statusMap: Record<Stripe.Subscription.Status, "ACTIVE" | "PAST_DUE" | "CANCELLED" | "TRIALING"> = {
    active: "ACTIVE",
    trialing: "TRIALING",
    past_due: "PAST_DUE",
    unpaid: "PAST_DUE",
    canceled: "CANCELLED",
    incomplete: "PAST_DUE",
    incomplete_expired: "CANCELLED",
    paused: "CANCELLED",
  };

  const currentPeriodEnd = (stripeSub as any).current_period_end as number | undefined;
  const currentPeriodStart = (stripeSub as any).current_period_start as number | undefined;

  await db.subscription.update({
    where: { businessId },
    data: {
      stripeSubscriptionId: stripeSub.id,
      stripeCustomerId: typeof stripeSub.customer === "string" ? stripeSub.customer : stripeSub.customer.id,
      stripePriceId: priceId ?? undefined,
      plan: matchedPlan?.key ?? undefined,
      status: statusMap[stripeSub.status] ?? "ACTIVE",
      appointmentLimit: matchedPlan?.appointmentLimit,
      staffLimit: matchedPlan?.staffLimit,
      currentPeriodStartsAt: currentPeriodStart ? new Date(currentPeriodStart * 1000) : undefined,
      currentPeriodEndsAt: currentPeriodEnd ? new Date(currentPeriodEnd * 1000) : undefined,
      cancelAtPeriodEnd: stripeSub.cancel_at_period_end,
    },
  });
}

export async function markSubscriptionCancelled(businessId: string) {
  await db.subscription.update({
    where: { businessId },
    data: { status: "CANCELLED", plan: "FREE_TRIAL", appointmentLimit: PLANS.FREE_TRIAL.appointmentLimit, staffLimit: PLANS.FREE_TRIAL.staffLimit },
  });
}
