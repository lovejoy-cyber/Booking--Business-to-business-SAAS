import Stripe from "stripe";

/**
 * Single Stripe client, lazily constructed so the app can still boot (in
 * demo/dev environments) without STRIPE_SECRET_KEY set — it only throws the
 * moment billing is actually used, not on every cold start.
 */
let client: Stripe | null = null;

export function getStripe(): Stripe {
  if (client) return client;
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    throw new Error("STRIPE_SECRET_KEY is not set. Add it to your environment to enable billing.");
  }
  client = new Stripe(key, { apiVersion: "2024-06-20" });
  return client;
}
