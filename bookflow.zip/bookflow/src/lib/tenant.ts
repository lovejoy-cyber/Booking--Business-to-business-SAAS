import { db } from "@/lib/db";
import { requireUser } from "@/lib/session";
import { AppError } from "@/lib/errors";
import type { MemberRole } from "@prisma/client";

/**
 * Tenant isolation is the single most important security property of this
 * app: a business must NEVER be able to read or write another business's
 * data. We enforce it here, at the data-access layer, rather than trusting
 * any frontend check — every API route that touches business-scoped data
 * must call `requireBusinessAccess` (or `requireBusinessAccessBySlug`)
 * before running a query, and every subsequent query must filter by the
 * returned `businessId`.
 */
export interface BusinessContext {
  userId: string;
  businessId: string;
  role: MemberRole;
}

const ROLE_RANK: Record<MemberRole, number> = { EMPLOYEE: 0, MANAGER: 1, OWNER: 2 };

/**
 * The actual authorization check, factored out from session lookup so it can
 * be exercised directly in tests without mocking cookies/`next/headers`.
 * `requireBusinessAccess` (below) is the version every API route should call.
 */
export async function checkBusinessAccess(
  userId: string,
  businessId: string,
  minRole: MemberRole = "EMPLOYEE"
): Promise<BusinessContext> {
  const membership = await db.businessMember.findUnique({
    where: { businessId_userId: { businessId, userId } },
  });

  if (!membership) {
    throw AppError.forbidden("You don't have access to this business.");
  }
  if (ROLE_RANK[membership.role] < ROLE_RANK[minRole]) {
    throw AppError.forbidden("Your role does not permit this action.");
  }

  return { userId, businessId, role: membership.role };
}

export async function requireBusinessAccess(
  businessId: string,
  minRole: MemberRole = "EMPLOYEE"
): Promise<BusinessContext> {
  const user = await requireUser();
  return checkBusinessAccess(user.id, businessId, minRole);
}

/** Convenience for dashboard pages: the business owned/staffed by the current user.
 *  MVP assumption: one business per user (matches the "creates a business profile"
 *  onboarding flow). The schema supports multiple memberships if that changes later. */
export async function requireCurrentBusiness(minRole: MemberRole = "EMPLOYEE") {
  const user = await requireUser();

  const membership = await db.businessMember.findFirst({
    where: { userId: user.id },
    orderBy: { createdAt: "asc" },
    include: { business: true },
  });

  if (!membership) {
    throw AppError.notFound("No business found for this account yet.");
  }
  if (ROLE_RANK[membership.role] < ROLE_RANK[minRole]) {
    throw AppError.forbidden("Your role does not permit this action.");
  }

  return { user, business: membership.business, role: membership.role };
}
