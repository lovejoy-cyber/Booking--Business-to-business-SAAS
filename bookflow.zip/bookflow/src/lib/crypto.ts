import { randomBytes, createCipheriv, createDecipheriv, scryptSync } from "crypto";

/**
 * Envelope encryption for the one genuinely sensitive secret we store at
 * rest: a business's WhatsApp Cloud API access token. AES-256-GCM with a key
 * derived from WHATSAPP_TOKEN_ENCRYPTION_KEY (set this to a long random
 * string in production — see .env.example). Never log or return the
 * plaintext token to the frontend.
 */
function getKey(): Buffer {
  const secret = process.env.WHATSAPP_TOKEN_ENCRYPTION_KEY;
  if (!secret || secret.length < 16) {
    throw new Error(
      "WHATSAPP_TOKEN_ENCRYPTION_KEY is missing or too short. Set a long random value in your environment."
    );
  }
  return scryptSync(secret, "bookflow-whatsapp-token-salt", 32);
}

export function encryptSecret(plaintext: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", getKey(), iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return [iv.toString("base64"), authTag.toString("base64"), encrypted.toString("base64")].join(".");
}

export function decryptSecret(ciphertext: string): string {
  const [ivB64, tagB64, dataB64] = ciphertext.split(".");
  if (!ivB64 || !tagB64 || !dataB64) throw new Error("Malformed ciphertext.");
  const decipher = createDecipheriv("aes-256-gcm", getKey(), Buffer.from(ivB64, "base64"));
  decipher.setAuthTag(Buffer.from(tagB64, "base64"));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(dataB64, "base64")),
    decipher.final(),
  ]);
  return decrypted.toString("utf8");
}
