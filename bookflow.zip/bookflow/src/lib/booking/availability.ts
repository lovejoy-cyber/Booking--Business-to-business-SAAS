import { db } from "@/lib/db";
import { zonedTimeToUtc, utcToZonedTime } from "date-fns-tz";
import { addMinutes, addDays, format, isBefore, isAfter, startOfDay } from "date-fns";
import { AppError } from "@/lib/errors";

/**
 * Core availability engine.
 *
 * All business hours are stored as local wall-clock strings ("09:00") in the
 * business's IANA timezone. All appointments are stored as absolute UTC
 * instants. This module is the single place that crosses that boundary —
 * every other part of the app should deal in UTC Dates or ISO strings and
 * never re-derive "business local time" itself.
 *
 * A "resource" is whatever can only do one thing at a time: a specific
 * employee, or — for a solo business with no employees configured — the
 * business as a whole. `resourceKeyOf` below is the single definition of
 * that concept; availability and conflict-checking both use it so they can
 * never disagree with each other.
 */

export interface Interval {
  start: Date;
  end: Date;
}

export function overlaps(a: Interval, b: Interval): boolean {
  return isBefore(a.start, b.end) && isBefore(b.start, a.end);
}

export function resourceFilter(businessId: string, employeeId: string | null | undefined) {
  return employeeId ? { employeeId } : { businessId, employeeId: null };
}

interface GetSlotsParams {
  businessId: string;
  serviceId: string;
  employeeId?: string | null;
  /** Calendar date, "YYYY-MM-DD", interpreted in the business's timezone. */
  date: string;
}

export async function getAvailableSlots({
  businessId,
  serviceId,
  employeeId,
  date,
}: GetSlotsParams): Promise<string[]> {
  const business = await db.business.findUnique({ where: { id: businessId } });
  if (!business) throw AppError.notFound("Business not found.");

  const service = await db.service.findFirst({
    where: { id: serviceId, businessId, isActive: true },
  });
  if (!service) throw AppError.notFound("Service not found or unavailable.");

  if (employeeId) {
    const employee = await db.employee.findFirst({
      where: { id: employeeId, businessId, isActive: true },
    });
    if (!employee) throw AppError.notFound("Employee not found or unavailable.");
  }

  const tz = business.timezone;
  const dayStartLocal = `${date}T00:00:00`;
  const dayStartUtc = zonedTimeToUtc(dayStartLocal, tz);
  const dayOfWeek = Number(format(utcToZonedTime(dayStartUtc, tz), "i")) % 7; // date-fns "i" = 1(Mon)-7(Sun); normalize to 0=Sun

  // Reject dates too far in the past/future up front.
  const now = new Date();
  const maxDate = addDays(startOfDay(now), business.maxAdvanceBookingDays);
  if (isAfter(dayStartUtc, maxDate)) return [];

  // Working hours: an employee-specific row overrides the business default for that day.
  const hourRows = await db.workingHour.findMany({
    where: {
      businessId,
      dayOfWeek,
      OR: employeeId ? [{ employeeId }, { employeeId: null }] : [{ employeeId: null }],
    },
  });
  const specific = hourRows.find((h) => h.employeeId === employeeId);
  const fallback = hourRows.find((h) => h.employeeId === null);
  const hours = specific ?? fallback;

  if (!hours || hours.isClosed) return [];

  const windowStart = zonedTimeToUtc(`${date}T${hours.startTime}:00`, tz);
  const windowEnd = zonedTimeToUtc(`${date}T${hours.endTime}:00`, tz);
  if (!isBefore(windowStart, windowEnd)) return [];

  // Blocked time (business-wide + employee-specific), for this calendar day.
  const blocks = await db.blockedTime.findMany({
    where: {
      businessId,
      OR: employeeId ? [{ employeeId }, { employeeId: null }] : [{ employeeId: null }],
      startsAt: { lt: windowEnd },
      endsAt: { gt: windowStart },
    },
  });

  // Existing active appointments for this exact resource, same day window.
  const appointments = await db.appointment.findMany({
    where: {
      ...resourceFilter(businessId, employeeId),
      status: { in: ["PENDING", "CONFIRMED"] },
      startsAt: { lt: windowEnd },
      endsAt: { gt: windowStart },
    },
    select: { startsAt: true, endsAt: true },
  });

  const busy: Interval[] = [
    ...blocks.map((b) => ({ start: b.startsAt, end: b.endsAt })),
    ...appointments.map((a) => ({ start: a.startsAt, end: a.endsAt })),
  ];

  const duration = service.durationMinutes;
  const step = business.slotIntervalMinutes;
  const earliestBookable = addMinutes(now, business.minLeadTimeMinutes);

  const slots: string[] = [];
  for (let cursor = windowStart; isBefore(cursor, windowEnd); cursor = addMinutes(cursor, step)) {
    const slotEnd = addMinutes(cursor, duration);
    if (isAfter(slotEnd, windowEnd)) break; // doesn't fit before closing
    if (isBefore(cursor, earliestBookable)) continue; // too soon
    const candidate: Interval = { start: cursor, end: slotEnd };
    if (busy.some((b) => overlaps(candidate, b))) continue;
    slots.push(cursor.toISOString());
  }

  return slots;
}

/** Re-validated at write time — never trust that a previously-listed slot is still free. */
export async function assertSlotStillAvailable(params: {
  businessId: string;
  serviceId: string;
  employeeId?: string | null;
  startsAt: Date;
  endsAt: Date;
  excludeAppointmentId?: string;
}) {
  const { businessId, employeeId, startsAt, endsAt, excludeAppointmentId } = params;

  const conflict = await db.appointment.findFirst({
    where: {
      ...resourceFilter(businessId, employeeId),
      status: { in: ["PENDING", "CONFIRMED"] },
      id: excludeAppointmentId ? { not: excludeAppointmentId } : undefined,
      startsAt: { lt: endsAt },
      endsAt: { gt: startsAt },
    },
  });
  if (conflict) {
    throw AppError.conflict("That time was just booked by someone else. Please pick another slot.");
  }

  const blocked = await db.blockedTime.findFirst({
    where: {
      businessId,
      OR: employeeId ? [{ employeeId }, { employeeId: null }] : [{ employeeId: null }],
      startsAt: { lt: endsAt },
      endsAt: { gt: startsAt },
    },
  });
  if (blocked) {
    throw AppError.conflict("That time is blocked off. Please pick another slot.");
  }
}

export function parseLocalDateParam(date: string): void {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw AppError.badRequest("date must be in YYYY-MM-DD format.");
  }
}
