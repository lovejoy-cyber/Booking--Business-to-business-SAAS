import { db } from "@/lib/db";
import { addMinutes, subHours, isBefore, isAfter, format } from "date-fns";
import { zonedTimeToUtc, utcToZonedTime } from "date-fns-tz";
import { AppError } from "@/lib/errors";
import { assertSlotStillAvailable, resourceFilter } from "@/lib/booking/availability";
import { enqueueNotification } from "@/lib/whatsapp/service";
import { writeAuditLog } from "@/lib/audit";
import { enforceAppointmentLimit } from "@/lib/billing/subscription";
import type { Business } from "@prisma/client";

function computeReminderTimes(startsAt: Date, timezone: string) {
  const in24h = subHours(startsAt, 24);
  const localDay = format(utcToZonedTime(startsAt, timezone), "yyyy-MM-dd");
  const localEightAm = zonedTimeToUtc(`${localDay}T08:00:00`, timezone);
  const sameDay = isBefore(localEightAm, startsAt) ? localEightAm : subHours(startsAt, 2);
  return { in24h, sameDay };
}

async function scheduleReminders(business: Business, appointment: { id: string; startsAt: Date }) {
  const now = new Date();
  const { in24h, sameDay } = computeReminderTimes(appointment.startsAt, business.timezone);
  const full = await db.appointment.findUniqueOrThrow({ where: { id: appointment.id }, include: { customer: true } });

  if (isAfter(in24h, now)) {
    await enqueueNotification({
      business,
      appointment: full,
      customer: full.customer,
      type: "REMINDER_24H",
      scheduledFor: in24h,
    });
  }
  if (isAfter(sameDay, now) && isBefore(sameDay, appointment.startsAt)) {
    await enqueueNotification({
      business,
      appointment: full,
      customer: full.customer,
      type: "REMINDER_SAME_DAY",
      scheduledFor: sameDay,
    });
  }
}

async function cancelPendingRemindersFor(appointmentId: string) {
  await db.notification.updateMany({
    where: {
      appointmentId,
      status: "PENDING",
      type: { in: ["REMINDER_24H", "REMINDER_SAME_DAY"] },
    },
    data: { status: "FAILED", errorMessage: "Superseded (appointment cancelled or rescheduled)." },
  });
}

interface CreateAppointmentParams {
  business: Business;
  serviceId: string;
  employeeId?: string | null;
  startsAt: Date;
  notes?: string | null;
  customer: { id: string } | { name: string; whatsappE164: string };
  /** Who initiated the booking, for the audit log. Public bookings have no userId. */
  actorUserId?: string | null;
}

export async function createAppointment(params: CreateAppointmentParams) {
  const { business, serviceId, employeeId, startsAt, notes, customer, actorUserId } = params;

  // Checked first — no point validating a slot for a booking the business's
  // plan won't allow anyway, and it gives the clearest possible error message.
  await enforceAppointmentLimit(business);

  const service = await db.service.findFirst({
    where: { id: serviceId, businessId: business.id, isActive: true },
  });
  if (!service) throw AppError.notFound("Service not found or unavailable.");

  if (employeeId) {
    const employee = await db.employee.findFirst({
      where: { id: employeeId, businessId: business.id, isActive: true },
    });
    if (!employee) throw AppError.notFound("Selected staff member is not available.");
  }

  const now = new Date();
  const earliest = addMinutes(now, business.minLeadTimeMinutes);
  if (isBefore(startsAt, earliest)) {
    throw AppError.badRequest("That time is too soon — please choose a later slot.");
  }

  const endsAt = addMinutes(startsAt, service.durationMinutes);

  await assertSlotStillAvailable({
    businessId: business.id,
    serviceId,
    employeeId,
    startsAt,
    endsAt,
  });

  const customerId =
    "id" in customer
      ? customer.id
      : (
          await db.customer.upsert({
            where: { businessId_whatsappE164: { businessId: business.id, whatsappE164: customer.whatsappE164 } },
            update: { name: customer.name },
            create: { businessId: business.id, name: customer.name, whatsappE164: customer.whatsappE164 },
          })
        ).id;

  // Final race-condition guard: re-check availability and insert inside one
  // transaction. This narrows, but — without a Postgres EXCLUDE constraint —
  // does not perfectly eliminate, the race window between two simultaneous
  // bookings for the exact same slot. See README § Production Hardening.
  const appointment = await db.$transaction(async (tx) => {
    const conflict = await tx.appointment.findFirst({
      where: {
        ...resourceFilter(business.id, employeeId),
        status: { in: ["PENDING", "CONFIRMED"] },
        startsAt: { lt: endsAt },
        endsAt: { gt: startsAt },
      },
    });
    if (conflict) {
      throw AppError.conflict("That time was just booked. Please pick another slot.");
    }

    return tx.appointment.create({
      data: {
        businessId: business.id,
        customerId,
        serviceId,
        employeeId: employeeId ?? null,
        startsAt,
        endsAt,
        status: "CONFIRMED",
        priceCents: service.priceCents,
        notes: notes ?? null,
      },
      include: { customer: true },
    });
  });

  await enqueueNotification({
    business,
    appointment,
    customer: appointment.customer,
    type: "BOOKING_CONFIRMATION",
  });
  await scheduleReminders(business, appointment);

  await writeAuditLog({
    businessId: business.id,
    userId: actorUserId ?? null,
    action: "appointment.create",
    entityType: "Appointment",
    entityId: appointment.id,
    metadata: { serviceId, employeeId: employeeId ?? null, startsAt: startsAt.toISOString() },
  });

  return appointment;
}

export async function cancelAppointment(params: {
  business: Business;
  appointmentId: string;
  reason?: string | null;
  actorUserId?: string | null;
}) {
  const { business, appointmentId, reason, actorUserId } = params;

  const appointment = await db.appointment.findFirst({
    where: { id: appointmentId, businessId: business.id },
    include: { customer: true },
  });
  if (!appointment) throw AppError.notFound("Appointment not found.");
  if (appointment.status === "CANCELLED") throw AppError.conflict("Appointment is already cancelled.");

  const updated = await db.appointment.update({
    where: { id: appointmentId },
    data: { status: "CANCELLED", cancelReason: reason ?? null },
    include: { customer: true },
  });

  await cancelPendingRemindersFor(appointmentId);
  await enqueueNotification({
    business,
    appointment: updated,
    customer: updated.customer,
    type: "CANCELLATION",
  });

  await writeAuditLog({
    businessId: business.id,
    userId: actorUserId ?? null,
    action: "appointment.cancel",
    entityType: "Appointment",
    entityId: appointmentId,
    metadata: { reason: reason ?? null },
  });

  return updated;
}

export async function rescheduleAppointment(params: {
  business: Business;
  appointmentId: string;
  startsAt: Date;
  employeeId?: string | null;
  actorUserId?: string | null;
}) {
  const { business, appointmentId, startsAt, employeeId, actorUserId } = params;

  const appointment = await db.appointment.findFirst({
    where: { id: appointmentId, businessId: business.id },
    include: { service: true, customer: true },
  });
  if (!appointment) throw AppError.notFound("Appointment not found.");
  if (appointment.status === "CANCELLED" || appointment.status === "COMPLETED") {
    throw AppError.conflict("This appointment can no longer be rescheduled.");
  }

  const nextEmployeeId = employeeId !== undefined ? employeeId : appointment.employeeId;
  const endsAt = addMinutes(startsAt, appointment.service.durationMinutes);

  await assertSlotStillAvailable({
    businessId: business.id,
    serviceId: appointment.serviceId,
    employeeId: nextEmployeeId,
    startsAt,
    endsAt,
    excludeAppointmentId: appointmentId,
  });

  const updated = await db.appointment.update({
    where: { id: appointmentId },
    data: { startsAt, endsAt, employeeId: nextEmployeeId, status: "CONFIRMED" },
    include: { customer: true },
  });

  await cancelPendingRemindersFor(appointmentId);
  await enqueueNotification({
    business,
    appointment: updated,
    customer: updated.customer,
    type: "RESCHEDULE",
  });
  await scheduleReminders(business, updated);

  await writeAuditLog({
    businessId: business.id,
    userId: actorUserId ?? null,
    action: "appointment.reschedule",
    entityType: "Appointment",
    entityId: appointmentId,
    metadata: { startsAt: startsAt.toISOString(), employeeId: nextEmployeeId ?? null },
  });

  return updated;
}

export async function markAppointmentStatus(params: {
  business: Business;
  appointmentId: string;
  status: "COMPLETED" | "NO_SHOW";
  actorUserId?: string | null;
}) {
  const { business, appointmentId, status, actorUserId } = params;

  const appointment = await db.appointment.findFirst({ where: { id: appointmentId, businessId: business.id } });
  if (!appointment) throw AppError.notFound("Appointment not found.");
  if (appointment.status === "CANCELLED") {
    throw AppError.conflict("A cancelled appointment cannot be updated.");
  }

  const updated = await db.appointment.update({ where: { id: appointmentId }, data: { status } });

  await writeAuditLog({
    businessId: business.id,
    userId: actorUserId ?? null,
    action: status === "COMPLETED" ? "appointment.complete" : "appointment.no_show",
    entityType: "Appointment",
    entityId: appointmentId,
  });

  return updated;
}
