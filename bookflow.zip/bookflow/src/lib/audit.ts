import { db } from "@/lib/db";

interface AuditEntry {
  businessId?: string | null;
  userId?: string | null;
  action: string;
  entityType?: string;
  entityId?: string;
  metadata?: Record<string, unknown>;
  ipAddress?: string | null;
}

/** Fire-and-forget audit trail for sensitive operations (cancellations, config
 *  changes, credential updates, admin actions). Never store secrets in metadata. */
export async function writeAuditLog(entry: AuditEntry) {
  try {
    await db.auditLog.create({
      data: {
        businessId: entry.businessId ?? null,
        userId: entry.userId ?? null,
        action: entry.action,
        entityType: entry.entityType,
        entityId: entry.entityId,
        metadata: entry.metadata as any,
        ipAddress: entry.ipAddress ?? null,
      },
    });
  } catch (err) {
    // Audit logging must never break the primary operation.
    console.error("[audit_log_failed]", entry.action, err);
  }
}

export function clientIp(headers: Headers): string | null {
  return headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;
}
