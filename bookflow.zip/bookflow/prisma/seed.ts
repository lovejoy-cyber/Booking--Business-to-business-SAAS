import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { addDays, addHours, subDays, subHours } from "date-fns";

const db = new PrismaClient();

async function main() {
  console.log("Seeding BookFlow demo data…");

  const ownerPasswordHash = await bcrypt.hash("Demo1234!", 12);
  const adminPasswordHash = await bcrypt.hash("Admin1234!", 12);

  const owner = await db.user.upsert({
    where: { email: "demo@bookflow.app" },
    update: {},
    create: { name: "Marcus Diallo", email: "demo@bookflow.app", passwordHash: ownerPasswordHash },
  });

  await db.user.upsert({
    where: { email: "admin@bookflow.app" },
    update: {},
    create: { name: "BookFlow Admin", email: "admin@bookflow.app", passwordHash: adminPasswordHash, platformRole: "SUPER_ADMIN" },
  });

  const business = await db.business.upsert({
    where: { slug: "elite-cuts" },
    update: {},
    create: {
      name: "Elite Cuts",
      slug: "elite-cuts",
      type: "BARBER",
      description: "Classic cuts, hot towel shaves, and beard sculpting in the heart of downtown.",
      address: "142 Main Street",
      phone: "+15550100",
      currency: "USD",
      timezone: "America/New_York",
      isDemoMode: true,
      cancellationPolicy: "Please give at least 2 hours' notice to cancel or reschedule.",
    },
  });

  await db.businessMember.upsert({
    where: { businessId_userId: { businessId: business.id, userId: owner.id } },
    update: {},
    create: { businessId: business.id, userId: owner.id, role: "OWNER" },
  });

  await db.whatsAppConfiguration.upsert({
    where: { businessId: business.id },
    update: {},
    create: { businessId: business.id, isConfigured: false },
  });

  await db.subscription.upsert({
    where: { businessId: business.id },
    update: {},
    create: {
      businessId: business.id,
      plan: "FREE_TRIAL",
      status: "TRIALING",
      appointmentLimit: 30,
      trialEndsAt: addDays(new Date(), 14),
    },
  });

  // Working hours: Mon-Fri 9-18, Sat 9-14, Sun closed.
  const hours = [
    { dayOfWeek: 0, isClosed: true, startTime: "09:00", endTime: "18:00" },
    { dayOfWeek: 1, isClosed: false, startTime: "09:00", endTime: "18:00" },
    { dayOfWeek: 2, isClosed: false, startTime: "09:00", endTime: "18:00" },
    { dayOfWeek: 3, isClosed: false, startTime: "09:00", endTime: "18:00" },
    { dayOfWeek: 4, isClosed: false, startTime: "09:00", endTime: "18:00" },
    { dayOfWeek: 5, isClosed: false, startTime: "09:00", endTime: "18:00" },
    { dayOfWeek: 6, isClosed: false, startTime: "09:00", endTime: "14:00" },
  ];
  for (const h of hours) {
    const existing = await db.workingHour.findFirst({ where: { businessId: business.id, employeeId: null, dayOfWeek: h.dayOfWeek } });
    if (!existing) await db.workingHour.create({ data: { ...h, businessId: business.id, employeeId: null } });
  }

  const services = await Promise.all(
    [
      { name: "Haircut", description: "Classic scissor cut and finish.", priceCents: 1000, durationMinutes: 30, sortOrder: 0 },
      { name: "Haircut + Beard", description: "Haircut with beard trim and line-up.", priceCents: 1500, durationMinutes: 45, sortOrder: 1 },
      { name: "Full Service", description: "Haircut, beard, and hot towel finish.", priceCents: 2500, durationMinutes: 60, sortOrder: 2 },
    ].map((s) =>
      db.service.upsert({
        where: { id: `seed-service-${s.name.toLowerCase().replace(/\s+/g, "-")}` },
        update: {},
        create: { id: `seed-service-${s.name.toLowerCase().replace(/\s+/g, "-")}`, businessId: business.id, ...s },
      })
    )
  );

  const customerSeeds = [
    { name: "Jordan Kim", whatsappE164: "+15550101" },
    { name: "Priya Nair", whatsappE164: "+15550102" },
    { name: "Diego Alvarez", whatsappE164: "+15550103" },
    { name: "Sam Whitfield", whatsappE164: "+15550104" },
  ];
  const customers = await Promise.all(
    customerSeeds.map((c) =>
      db.customer.upsert({
        where: { businessId_whatsappE164: { businessId: business.id, whatsappE164: c.whatsappE164 } },
        update: {},
        create: { businessId: business.id, ...c },
      })
    )
  );

  const [haircut, haircutBeard, fullService] = services;
  const now = new Date();

  const appointmentSeeds = [
    { customer: customers[0], service: haircut, startsAt: subDays(now, 10), status: "COMPLETED" as const },
    { customer: customers[1], service: haircutBeard, startsAt: subDays(now, 6), status: "COMPLETED" as const },
    { customer: customers[2], service: fullService, startsAt: subDays(now, 3), status: "NO_SHOW" as const },
    { customer: customers[3], service: haircut, startsAt: subHours(now, 26), status: "CANCELLED" as const },
    { customer: customers[0], service: haircutBeard, startsAt: addHours(now, 3), status: "CONFIRMED" as const },
    { customer: customers[1], service: haircut, startsAt: addDays(now, 1), status: "CONFIRMED" as const },
    { customer: customers[2], service: fullService, startsAt: addDays(now, 2), status: "CONFIRMED" as const },
  ];

  for (const a of appointmentSeeds) {
    const endsAt = new Date(a.startsAt.getTime() + a.service.durationMinutes * 60_000);
    await db.appointment.create({
      data: {
        businessId: business.id,
        customerId: a.customer.id,
        serviceId: a.service.id,
        startsAt: a.startsAt,
        endsAt,
        status: a.status,
        priceCents: a.service.priceCents,
      },
    });
  }

  console.log("Seed complete.");
  console.log("  Owner login:  demo@bookflow.app / Demo1234!");
  console.log("  Admin login:  admin@bookflow.app / Admin1234!");
  console.log("  Booking page: /book/elite-cuts");
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
