/**
 * Local development convenience: polls the notification queue directly
 * (in-process, no HTTP/cron needed) so demo bookings actually "send" and
 * "deliver" their WhatsApp messages without wiring up a real scheduler.
 *
 * Run alongside `npm run dev`:
 *   npm run notifications:worker
 *
 * In production, call POST /api/notifications/process on a schedule instead
 * (see README § Deployment) — don't run this long-lived script on serverless
 * hosting.
 */
import "dotenv/config";
import { processPendingNotifications } from "../src/lib/whatsapp/service";

const INTERVAL_MS = 15_000;

async function tick() {
  try {
    const result = await processPendingNotifications(50);
    if (result.processed > 0) {
      console.log(`[notifications] processed=${result.processed} sent=${result.sent} failed=${result.failed}`);
    }
  } catch (err) {
    console.error("[notifications] worker tick failed:", err);
  }
}

console.log(`Notification worker running — polling every ${INTERVAL_MS / 1000}s. Ctrl+C to stop.`);
tick();
setInterval(tick, INTERVAL_MS);
